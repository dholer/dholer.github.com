//
//  AppDelegate.h
//  HRA
//
//  Created by Zhu Gang on 12-1-17.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UINavigationController      *navController;
    MainViewController          *mainViewController;
}

@property (strong, nonatomic) UIWindow *window;

-(void)showLoadingView;
-(void)hideLoadingView;

-(void)showStartView;

@end
