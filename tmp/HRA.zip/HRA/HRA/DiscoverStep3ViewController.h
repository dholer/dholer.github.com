//
//  DiscoverStep3ViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-7.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"

@interface DiscoverStep3ViewController : CommonViewController
{
    NSArray             *arrayItem;
    
    IBOutlet UIButton   *btnNext;
    
}

-(IBAction)btnNextClick:(id)sender;

@end
