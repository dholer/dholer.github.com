//
//  ThreeInOneStep1ViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-3.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CommonViewController.h"
#import "ThreeInOneStep2ViewController.h"

@interface ThreeInOneStep1ViewController : CommonViewController<UITextFieldDelegate>
{
    IBOutlet UITableView                *tableViewContent;
    
    NSMutableArray                      *arrayData;
    
    CGRect                              rcSave;
}

-(IBAction)btnPutTogetherClick:(id)sender;

@end
