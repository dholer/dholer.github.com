//
//  SuperpowerItemViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-18.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "SuperpowerItemViewController.h"

@implementation SuperpowerItemViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillShow) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillHide) name:UIKeyboardWillHideNotification object:nil];
}

- (void) keyboardWillShow
{
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
    self.view.transform = CGAffineTransformMakeTranslation(0, -155);
	[UIView commitAnimations];
    
}

- (void) keyboardWillHide
{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	self.view.transform = CGAffineTransformMakeTranslation(0, 0);
	[UIView commitAnimations];
    
    
}

-(void)setPower:(int)index
{
    powerIndex = index;
    
    NSArray *arrayData = [DataMgr getPlistData:@"Superpower.plist"];
    
    NSDictionary *dictItem = [arrayData objectAtIndex:powerIndex-1];
    
    labelTitle.text = [dictItem objectForKey:@"Title"];
    labelInfo.text = [dictItem objectForKey:@"Info"];
    imageViewPower.image = [UIImage imageNamed:[dictItem objectForKey:@"Image"]];
    
    
    if ([DataMgr hasSuperpowerData])
    {
        NSMutableDictionary *dictData = [DataMgr readSuperPowerData];
        int indexSave = [[dictData objectForKey:@"PowerIndex"]intValue];
        if (indexSave == index)
            textFieldData.text = [dictData objectForKey:@"PowerData"];
    }
}

-(IBAction)btnFinishClick:(id)sender
{
    NSMutableDictionary *dictData = [NSMutableDictionary dictionary];
    [dictData setValue:[NSNumber numberWithInt:powerIndex] forKey:@"PowerIndex"];
    [dictData setValue:textFieldData.text forKey:@"PowerData"];
    
    [DataMgr saveSuperpowerData:dictData];
    
    [self btnRootClick:sender];
}

-(IBAction)hideKeyPad:(id)sender
{
    [textFieldData resignFirstResponder];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillShowNotification
												  object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillHideNotification
												  object:nil];
    [labelTitle release];
    [labelInfo release];
    [textFieldData release];
    [imageViewPower release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
