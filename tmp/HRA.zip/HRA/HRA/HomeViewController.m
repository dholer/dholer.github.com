//
//  HomeViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-1.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "HomeViewController.h"

@implementation HomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if ([DataMgr isDiscoverActive])
    {
        [self showDiscoverDoneInfo];
    }
    else
    {
        [self btnInfoClick:nil];
    }
    
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [tableViewItem reloadData];
}

-(void)showDiscoverDoneInfo
{
    if (discoverDoneInfoViewController == nil)
        discoverDoneInfoViewController = [[DiscoverDoneInfoViewController alloc]initWithNibName:@"DiscoverDoneInfoViewController" bundle:nil];
    discoverDoneInfoViewController.view.alpha = 0.0;
    
    [self.view addSubview:discoverDoneInfoViewController.view];
    [UIView animateWithDuration:0.8 animations:^{
        discoverDoneInfoViewController.view.alpha = 1.0;
    } completion:^(BOOL finished)
     {
         
     }];
}


-(IBAction)btnInfoClick:(id)sender
{
    [tableViewItem deselectRowAtIndexPath:indexPathSelect animated:YES];
    [indexPathSelect release];
    indexPathSelect = nil;
    
    if (startViewController == nil)
        startViewController = [[HomeGetStartViewController alloc]initWithNibName:@"HomeGetStartViewController" bundle:nil];
    startViewController.view.alpha = 0.0;
    
    [self.view addSubview:startViewController.view];
    [UIView animateWithDuration:0.8 animations:^{
        startViewController.view.alpha = 1.0;
    } completion:^(BOOL finished)
     {
         
     }];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [startViewController release];
    [tableViewItem release];
    [indexPathSelect release];
    [discoverDoneInfoViewController release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return 20.0;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	UIView *viewHeader = [[[UIView alloc]init]autorelease];
	return viewHeader;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger row = [indexPath row];
    if (row == 0)
        return 113.0;
    else if (row == 1)
        return 108.0;
    else
        return 112.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	UITableViewCell *cell = nil;
    
    static NSString *FirstLevelCell= @"HomeBtnCell";
    cell = [tableView dequeueReusableCellWithIdentifier: 
            FirstLevelCell];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                       reuseIdentifier: FirstLevelCell] autorelease];
        
        {
            UIImageView *normal = [[UIImageView alloc] initWithFrame:CGRectZero];
            cell.backgroundView = normal;
            [normal release];
            
            UIImageView *select = [[UIImageView alloc] initWithFrame:CGRectZero];
            cell.selectedBackgroundView = select;
            [select release];
            
            
        }
    }
    
    UIImageView *normal = (UIImageView *)cell.backgroundView;
    UIImageView *select = (UIImageView *)cell.selectedBackgroundView;
    
    NSInteger row = [indexPath row];
    CGRect rect;
    UIImage *imageNormal = nil;
    UIImage *imageSelect = nil;
	if (row == 0)
    {
        rect = CGRectMake(0, 0, 302, 113);
        
        if ([DataMgr isDiscoverActive])
        {
            imageNormal = [UIImage imageNamed:@"step1-active.png"];
            imageSelect = nil;//[UIImage imageNamed:@"step1-on.png"];
        }
        else
        {
            imageNormal = [UIImage imageNamed:@"step1.png"];
            imageSelect = [UIImage imageNamed:@"step1-on.png"];
        }
    }
    else if (row == 1)
    {
        rect = CGRectMake(0, 0, 302, 108);
        imageNormal = [UIImage imageNamed:@"step2.png"];
        imageSelect = [UIImage imageNamed:@"step2-on.png"];;
    }
    else
    {
        rect = CGRectMake(0, 0, 302, 112);
        imageNormal = [UIImage imageNamed:@"step3.png"];
        imageSelect = [UIImage imageNamed:@"step3-on.png"];
    }
    normal.frame = rect;
    normal.image = imageNormal;
    select.frame = rect;
    select.image = imageSelect;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    if (indexPathSelect)
        [indexPathSelect release];
    indexPathSelect = [indexPath retain];
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSInteger row = [indexPath row];
    UIViewController *viewController = nil;
    if (row == 0)
    {
        DiscoverStep1ViewController *tmpViewController = [[[DiscoverStep1ViewController alloc]initWithNibName:@"DiscoverStep1ViewController" bundle:nil]autorelease];
        
        tmpViewController.homeViewController = self;
        viewController = tmpViewController;
    }
    
    
    if (viewController)
    {
        [self.navigationController pushViewController:viewController animated:YES];
    }
    
}


@end
