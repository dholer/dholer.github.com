//
//  ValueToolViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-11.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "ValueToolViewController.h"

@implementation ValueToolViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib. 
    imageViewInfo = (UIImageView*)[self.view viewWithTag:666];
    NSArray *arrayImage = [NSArray arrayWithObjects:[UIImage imageNamed:@"icon-arrow1.png"],[UIImage imageNamed:@"icon-arrow2.png"], nil];
    imageViewInfo.animationImages = arrayImage;
    imageViewInfo.animationDuration = 1;
    [imageViewInfo startAnimating];
    [self btnInfoClick:nil];
    
    [NSTimer scheduledTimerWithTimeInterval:2.0
                                     target:self
                                   selector:@selector(flashScrollBar)
                                   userInfo:nil
                                    repeats:YES];
}

-(void)flashScrollBar
{
    [tableViewContent flashScrollIndicators];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{	
    /*if (scrollView.contentOffset.y+scrollView.frame.size.height >= scrollView.contentSize.height)
    {
        [imageViewInfo stopAnimating];
        imageViewInfo.hidden = YES;
    }
    else
    {
        [imageViewInfo startAnimating];
        imageViewInfo.hidden = NO;
    }*/
}

-(void)setType:(int)toolType
{
    type = toolType;
    
    UILabel *labelTitle = (UILabel*)[self.view viewWithTag:10];
    if (type == kTypeCoreValues)
    {
        labelTitle.text = @"Core Values";
        if ([DataMgr hasCoreValuesData])
            arrayItem = [[DataMgr readCoreValuesData]retain];
    }
    else
    {
        labelTitle.text = @"Energy";
        if ([DataMgr hasEnergyData])
            arrayItem = [[DataMgr readEnergyData]retain];
    }
    
    if (arrayItem == nil)
    {
        NSArray *arrayList = [DataMgr getPlistData:@"ValueTool.plist"];
        arrayItem = [[NSMutableArray array]retain];
        for(NSDictionary *dictItem in arrayList)
        {
            NSMutableDictionary *dictAdd = [NSMutableDictionary dictionaryWithDictionary:dictItem];
            [arrayItem addObject:dictAdd];
        }
    }
    
    [tableViewContent reloadData];
}

-(IBAction)btnInfoClick:(id)sender
{
    if (infoViewController == nil)
        infoViewController = [[ValueToolInfoViewController alloc]initWithNibName:@"ValueToolInfoViewController" bundle:nil];
    infoViewController.view.alpha = 0.0;
    [infoViewController setType:type];
    [self.view addSubview:infoViewController.view];
    [UIView animateWithDuration:0.8 animations:^{
        infoViewController.view.alpha = 1.0;
    } completion:^(BOOL finished)
     {
         
     }];
}

-(void)showTipsView:(UIButton*)btn
{
    CGPoint pt = btn.frame.origin;
    CGPoint ptScreen = [btn convertPoint:pt toView:self.view];
    NSLog(@"Pos:%.1f, %.1f", ptScreen.x, ptScreen.y);
    
    
    UIView *viewInfo = [self.view viewWithTag:999];
    if (viewInfo == nil)
    {
        viewInfo = [[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 480)]autorelease];
        viewInfo.backgroundColor = [UIColor clearColor];
        viewInfo.tag = 999;
        UIButton *btnClose = [[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 320, 480)]autorelease];
        [btnClose addTarget:self action:@selector(hideTipsView) forControlEvents:UIControlEventTouchUpInside];
        [viewInfo addSubview:btnClose];
        
        UIImageView *imageViewTips = [[[UIImageView alloc]initWithFrame:CGRectMake(9, 0, 302, 88)]autorelease];
        imageViewTips.tag = 8;
        imageViewTips.image = [UIImage imageNamed:@"overlay-bg.png"];
        [viewInfo addSubview:imageViewTips];
        
        UILabel *label1 = [[[UILabel alloc]initWithFrame:CGRectMake(10, 6, 302, 32)]autorelease];
        label1.tag = 11;
        label1.backgroundColor = [UIColor clearColor];
        label1.textColor = [UIColor whiteColor];
        label1.font = [UIFont boldSystemFontOfSize:18];
        [imageViewTips addSubview:label1];
        
        UILabel *label2 = [[[UILabel alloc]initWithFrame:CGRectMake(10, 30, 282, 36)]autorelease];
        label2.tag = 12;
        label2.backgroundColor = [UIColor clearColor];
        label2.textColor = [UIColor lightGrayColor];
        label2.font = [UIFont systemFontOfSize:14];
        label2.numberOfLines = 2;
        [imageViewTips addSubview:label2];
        
        viewInfo.alpha = 0.0;
        [self.view addSubview:viewInfo];
    } 
    
    NSDictionary *dictItem = [arrayItem objectAtIndex:btn.tag-100];
    
    UIImageView *imageViewTips = (UIImageView*)[viewInfo viewWithTag:8];
    imageViewTips.center = CGPointMake(imageViewTips.center.x, ptScreen.y-45);
    UILabel *label1 = (UILabel*)[imageViewTips viewWithTag:11];
    UILabel *label2 = (UILabel*)[imageViewTips viewWithTag:12];
    
    label1.text = [NSString stringWithFormat:@"%@", [dictItem objectForKey:@"Word"]];
    label2.text = [dictItem objectForKey:@"Tips"];
    
    [UIView animateWithDuration:0.35 animations:^{
        viewInfo.alpha = 1.0;
    } completion:^(BOOL finished)
     {
         
     }];
}

-(void)hideTipsView
{
    UIView *viewInfo = [self.view viewWithTag:999];
    [UIView animateWithDuration:0.35 animations:^{
        viewInfo.alpha = 0.0;
    } completion:^(BOOL finished)
     {
         [viewInfo removeFromSuperview];
     }];
}

- (void)viewWillAppear:(BOOL)animated
{
    btnVisualize.enabled = [DataMgr hasCoreValuesData];
    [tableViewContent reloadData];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [arrayItem release];
    [btnVisualize release];
    [tableViewContent release];
    [infoViewController release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)btnVisualizeClick:(id)sender
{
    if (type == kTypeCoreValues)
        [DataMgr saveCoreValuesData:arrayItem];
    else
        [DataMgr saveEnergyData:arrayItem];
    
    VisualizeViewController *viewController = [[[VisualizeViewController alloc]initWithNibName:@"VisualizeViewController" bundle:nil]autorelease];
    viewController.homeViewController = self.homeViewController;
    viewController.backViewController = self.backViewController;
    
    [self.navigationController pushViewController:viewController animated:YES];
    [viewController visualizeWord:type];
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return [arrayItem count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	return 10;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{	
	UILabel *label = [[[UILabel alloc] init] autorelease];
	label.backgroundColor = [UIColor clearColor];
	return label;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	if (section == 0)
		return 30 + 2;
	else
		return 30;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	NSDictionary *dictItem = [arrayItem objectAtIndex:section];
    UIFont *fontText = [UIFont boldSystemFontOfSize:15];
    NSString *word = [dictItem objectForKey:@"Word"];
    CGSize szText = [word sizeWithFont:fontText constrainedToSize:CGSizeMake(320, 25)];
    
	UIView *viewHeader = [[[UIView alloc]init]autorelease];
	
	UILabel *label = [[[UILabel alloc] init] autorelease];
	label.frame = CGRectMake(13, section == 0 ? 5: 3, tableView.frame.size.width-13, 26);
	label.backgroundColor = [UIColor clearColor];
	label.textColor = RGBColor(70, 70, 70);
	label.font = fontText;
	label.text = word;
	
	[viewHeader addSubview:label];
    
    UIButton *btnQuestion = [[[UIButton alloc]initWithFrame:CGRectMake(szText.width + 20, 5, 21, 22)]autorelease];
    [btnQuestion setBackgroundImage:[UIImage imageNamed:@"icon-question.png"] forState:UIControlStateNormal];
    [btnQuestion sizeToFit];
    [btnQuestion addTarget:self action:@selector(btnQuestionClick:) forControlEvents:UIControlEventTouchUpInside];
    btnQuestion.tag = 100+section;
    [viewHeader addSubview:btnQuestion];
	
	return viewHeader;
}

-(void)btnQuestionClick:(UIButton*)btn
{
    [self showTipsView:btn];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	UITableViewCell *cell = nil;
    
    static NSString *FirstLevelCell= @"CoreValueCell";
    cell = [tableView dequeueReusableCellWithIdentifier: 
            FirstLevelCell];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                       reuseIdentifier: FirstLevelCell] autorelease];
        
        
        
        UILabel *labelLow = [[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 33, 39)]autorelease];
        labelLow.text = @"low";
        labelLow.backgroundColor = [UIColor clearColor];
        labelLow.textColor = [UIColor blackColor];
        labelLow.textAlignment = UITextAlignmentRight;
        labelLow.font = [UIFont boldSystemFontOfSize:15];
        [cell.contentView addSubview:labelLow];
        
        UISlider *slider = [[[UISlider alloc]initWithFrame:CGRectMake(40, 0, 213, 40)]autorelease];
        slider.tag = 10;
        [slider addTarget:self action:@selector(valueChanged:) forControlEvents:UIControlEventValueChanged];
        [cell.contentView addSubview:slider];
        
        UILabel *labelHight = [[[UILabel alloc]initWithFrame:CGRectMake(260, 0, 35, 39)]autorelease];
        labelHight.text = @"high";
        labelHight.backgroundColor = [UIColor clearColor];
        labelHight.textAlignment = UITextAlignmentLeft;
        labelHight.textColor = [UIColor blackColor];
        labelHight.font = [UIFont boldSystemFontOfSize:15];
        [cell.contentView addSubview:labelHight];
    }
    
    NSInteger section = [indexPath section];
    NSDictionary *dictItem = [arrayItem objectAtIndex:section];
    UISlider *slider = (UISlider*)[cell.contentView viewWithTag:10];
    slider.value = [[dictItem objectForKey:@"Value"]floatValue];
    
    cell.tag = 100+section;
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    
    return cell;
}

-(void)valueChanged:(UISlider*)slider
{
    btnVisualize.enabled = YES;
    
    UITableViewCell *cell = (UITableViewCell*)[[slider superview]superview];
    
    NSInteger section = cell.tag - 100;
    
    NSMutableDictionary *dictItem = [arrayItem objectAtIndex:section];
    [dictItem setValue:[NSNumber numberWithFloat:slider.value] forKey:@"Value"];
}

@end
