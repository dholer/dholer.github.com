//
//  ThreeInOneStep2ViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-3.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "ThreeInOneStep2ViewController.h"

@implementation ThreeInOneStep2ViewController
@synthesize arrayData;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSString *strContent = [NSString stringWithFormat:@"<div style='font-size:16px;color:0x464646'>Are you comfortable with being %@, %@, and %@?<br/><br/>Would you want to be friends with somebody who’s %@, %@, and %@?<br/><br/>How would your life change if you had your %@, %@, and %@ back?<br/><br/>Start making preparations <b>now</b> for your %@, %@, and %@.<br/><br/>Can you conquer your fear of %@, %@, and %@?<br/><br/>Take a moment to be grateful for %@, %@, and %@.</div>",
                            [[[arrayData objectAtIndex:0] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:0] objectForKey:@"Values"]objectAtIndex:1],
                            [[[arrayData objectAtIndex:0] objectForKey:@"Values"]objectAtIndex:2],
                            [[[arrayData objectAtIndex:1] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:1] objectForKey:@"Values"]objectAtIndex:1],
                            [[[arrayData objectAtIndex:1] objectForKey:@"Values"]objectAtIndex:2],
                            [[[arrayData objectAtIndex:2] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:2] objectForKey:@"Values"]objectAtIndex:1],
                            [[[arrayData objectAtIndex:2] objectForKey:@"Values"]objectAtIndex:2],
                            [[[arrayData objectAtIndex:3] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:3] objectForKey:@"Values"]objectAtIndex:1],
                            [[[arrayData objectAtIndex:3] objectForKey:@"Values"]objectAtIndex:2],
                            [[[arrayData objectAtIndex:4] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:4] objectForKey:@"Values"]objectAtIndex:1],
                            [[[arrayData objectAtIndex:4] objectForKey:@"Values"]objectAtIndex:2],
                            [[[arrayData objectAtIndex:5] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:5] objectForKey:@"Values"]objectAtIndex:1],
                            [[[arrayData objectAtIndex:5] objectForKey:@"Values"]objectAtIndex:2]
                            ];
    
    // Do any additional setup after loading the view from its nib.
    NSString *strHTML = [NSString stringWithFormat:@"<head><style>body{font-family:Helvetica;}</style></head><meta name=\"viewport\" content=\"width=290.0, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=yes\"/>%@", strContent];
	[webViewContent loadHTMLString:strHTML baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
    
    webViewContent.backgroundColor = [UIColor clearColor];
	webViewContent.opaque = NO;
	
	if ([[webViewContent subviews] count] > 0)
	{
		UIView *shadowView = [[webViewContent subviews] objectAtIndex:0];
		NSArray *array = [shadowView subviews];
		
		for(int i=0; i<[array count]-1; i++)
		{
			UIView *tmpView = [array objectAtIndex:i];
			tmpView.hidden = YES;
		}
	}
    
    [NSTimer scheduledTimerWithTimeInterval:2.0
                                     target:self
                                   selector:@selector(flashScrollBar)
                                   userInfo:nil
                                    repeats:YES];
}

-(void)flashScrollBar
{
    [webViewContent.scrollView flashScrollIndicators];
}



-(IBAction)btnFinishClick:(id)sender
{
    [DataMgr saveThreeInOneData:arrayData];
    [self btnRootClick:nil];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)dealloc
{
    [webViewContent release];
    [arrayData release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
