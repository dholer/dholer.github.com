//
//  ValueToolInfoViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-11.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "ValueToolInfoViewController.h"

@implementation ValueToolInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)setType:(int)toolType
{
    type = toolType;
    
    UILabel *labelTitle = (UILabel*)[self.view viewWithTag:10];
    UILabel *labelInfo1 = (UILabel*)[self.view viewWithTag:11];
    UILabel *labelInfo2 = (UILabel*)[self.view viewWithTag:12];
    UILabel *labelInfo3 = (UILabel*)[self.view viewWithTag:13];
    if (type == kTypeCoreValues)
    {
        labelTitle.text = @"What’s Important?";
        //labelInfo.text = @"Here’s a list of “core values” –  the words you live by from day to day. Using the sliders, rate how important each one is to you.";
        labelInfo1.hidden = NO;
        labelInfo2.hidden = YES;
        labelInfo3.hidden = YES;
    }
    else
    {
        labelTitle.text = @"Where’s Your Energy?";
        //labelInfo.text = @"The next part is a little trickier. Take another look at the list, only this time rate how much actual energy (time and effort) you regularly devote to each value. Be honest!";
        labelInfo1.hidden = YES;
        labelInfo2.hidden = NO;
        labelInfo3.hidden = NO;
    }
}


-(IBAction)btnCloseClick:(id)sender
{
    [UIView animateWithDuration:0.35 animations:^{
        self.view.alpha = 0.0;
    } completion:^(BOOL finished)
     {
         [self.view removeFromSuperview]; 
     }];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
