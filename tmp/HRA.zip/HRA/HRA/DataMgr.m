//
//  DataMgr.m
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "DataMgr.h"

@implementation NSString(Bundle)
-(NSString *)bundlePath{
    return [[NSBundle mainBundle] pathForResource:self ofType:nil];
}
@end


@implementation DataMgr

+(BOOL)isDiscoverActive
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    if ([prefs objectForKey:@"Mission_First_Draft"] == nil)
        return NO;
    
    if ([prefs objectForKey:@"Mission_Revised"] == nil)
        return NO;
    
    if ([DataMgr hasHappyHundredthData] == NO)
        return NO;
    
    if ([DataMgr hasThreeInOneData] == NO)
        return NO;
    
    if ([DataMgr hasCoreValuesData] == NO)
        return NO;
    
    if ([DataMgr hasEnergyData] == NO)
        return NO;
    
    return YES;
}

+(NSArray*)getMissionGallery
{
    NSString *path = [@"Mission.plist" bundlePath];
	
	return [NSArray arrayWithContentsOfFile:path];   
}

+(NSString*)readMissionFirstDraft
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    return [prefs objectForKey:@"Mission_First_Draft"];
}

+(void)saveMissionFirstDraft:(NSString*)text
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setValue:text forKey:@"Mission_First_Draft"];
    [prefs synchronize];
}

+(NSString*)readMissionRevised
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    return [prefs objectForKey:@"Mission_Revised"];
}

+(void)saveMissionRevised:(NSString*)text
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setValue:text forKey:@"Mission_Revised"];
    [prefs synchronize];
}

+(NSArray*)getActivities
{
    NSString *path = [@"Activities.plist" bundlePath];
	
	return [NSArray arrayWithContentsOfFile:path];
}

+(NSArray*)getPlistData:(NSString*)fileName;
{
    NSString *path = [fileName bundlePath];
	
	return [NSArray arrayWithContentsOfFile:path];
}

+(BOOL)hasHappyHundredthData
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSArray *arrayLoad = [prefs objectForKey:@"Happy_Hundredth"];
    
    return [arrayLoad count] > 0;
}

+(NSMutableArray*)readHappyHundredthData
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSArray *arrayLoad = [prefs objectForKey:@"Happy_Hundredth"];
    if (arrayLoad)
    {
        NSMutableArray *arrayRet = [NSMutableArray array];
        for(NSDictionary *dictItem in arrayLoad)
        {
            NSMutableDictionary *dictCopy = [NSMutableDictionary dictionary];
            [dictCopy setDictionary:dictItem];
            [arrayRet addObject:dictCopy];
        }
        return arrayRet;
    }
    else
        return nil;
}


+(void)saveHappyHundredthData:(NSArray*)data
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setValue:data forKey:@"Happy_Hundredth"];
    [prefs synchronize];
}

+(void)saveThreeInOneData:(NSArray*)data
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setValue:data forKey:@"Three_In_One"];
    [prefs synchronize];
}

+(NSMutableArray*)readThreeInOneData
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSArray *arrayLoad = [prefs objectForKey:@"Three_In_One"];
    if (arrayLoad)
    {
        NSMutableArray *arrayRet = [NSMutableArray array];
        for(NSDictionary *dictItem in arrayLoad)
        {
            NSMutableDictionary *dictCopy = [NSMutableDictionary dictionary];
            [dictCopy setDictionary:dictItem];
            [arrayRet addObject:dictCopy];
        }
        return arrayRet;
    }
    else
        return nil;
}

+(BOOL)hasThreeInOneData
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSArray *arrayLoad = [prefs objectForKey:@"Three_In_One"];
    
    return [arrayLoad count] > 0;
}


+(void)saveSuperpowerData:(NSDictionary*)data
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setValue:data forKey:@"Superpower"];
    [prefs synchronize];
}

+(NSMutableDictionary*)readSuperPowerData
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSDictionary *dictLoad = [prefs objectForKey:@"Superpower"];
    
    NSMutableDictionary *dictRet = [NSMutableDictionary dictionary];
    
    [dictRet setDictionary:dictLoad];
    
    return dictRet;
}


+(BOOL)hasSuperpowerData
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSDictionary *dictLoad = [prefs objectForKey:@"Superpower"];
    
    return dictLoad != nil;
}


+(void)saveCoreValuesData:(NSArray*)data
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setValue:data forKey:@"ValueTool_CoreValues"];
    [prefs synchronize];
}

+(NSMutableArray*)readCoreValuesData
{
    NSArray *arrayList = [DataMgr getPlistData:@"ValueTool.plist"];
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSArray *arrayLoad = [prefs objectForKey:@"ValueTool_CoreValues"];
    if (arrayLoad)
    {
        NSMutableArray *arrayRet = [NSMutableArray array];
        for(NSDictionary *dictItem in arrayLoad)
        {
            NSDictionary *dictInfo = [arrayList objectAtIndex:[arrayRet count]];
            NSMutableDictionary *dictCopy = [NSMutableDictionary dictionary];
            [dictCopy setDictionary:dictItem];
            [dictCopy setValue:[dictInfo objectForKey:@"Point1"] forKey:@"Point1"];
            [dictCopy setValue:[dictInfo objectForKey:@"Point2"] forKey:@"Point2"];
            
            [arrayRet addObject:dictCopy];
        }
        return arrayRet;
    }
    else
        return nil;
}

+(BOOL)hasCoreValuesData
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSArray *arrayLoad = [prefs objectForKey:@"ValueTool_CoreValues"];
    
    return [arrayLoad count] > 0;
}


+(void)saveEnergyData:(NSArray*)data
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setValue:data forKey:@"ValueTool_Energy"];
    [prefs synchronize];
}

+(NSMutableArray*)readEnergyData
{
    NSArray *arrayList = [DataMgr getPlistData:@"ValueTool.plist"];
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSArray *arrayLoad = [prefs objectForKey:@"ValueTool_Energy"];
    if (arrayLoad)
    {
        NSMutableArray *arrayRet = [NSMutableArray array];
        for(NSDictionary *dictItem in arrayLoad)
        {
            NSDictionary *dictInfo = [arrayList objectAtIndex:[arrayRet count]];
            NSMutableDictionary *dictCopy = [NSMutableDictionary dictionary];
            [dictCopy setDictionary:dictItem];
            [dictCopy setValue:[dictInfo objectForKey:@"Point1"] forKey:@"Point1"];
            [dictCopy setValue:[dictInfo objectForKey:@"Point2"] forKey:@"Point2"];
            [arrayRet addObject:dictCopy];
        }
        return arrayRet;
    }
    else
        return nil;
}

+(BOOL)hasEnergyData
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSArray *arrayLoad = [prefs objectForKey:@"ValueTool_Energy"];
    
    return [arrayLoad count] > 0;
}

@end
