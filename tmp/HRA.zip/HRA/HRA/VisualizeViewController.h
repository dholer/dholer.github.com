//
//  VisualizeViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-11.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"
#import "VisualizeInfoViewController.h"
#import "WebService.h"

@interface VisualizeViewController : CommonViewController<WebServiceDelegate>
{
    int             type;
    VisualizeInfoViewController     *infoViewController;
}

-(void)visualizeWord:(int)toolType;
-(IBAction)btnNextClick:(id)sender;

@end
