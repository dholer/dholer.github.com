//
//  WebService.h
//  HRA
//
//  Created by Zhu Gang on 12-2-17.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kServerAddress					@"http://216.91.145.97"
#define kServerPort						80


#define kAPIHeader                      @"hra/api"

#define kSuccess                        1
#define kNetworkError                   2
#define kJsonError                      3


@interface NSURLRequest (WebService_Login)

+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString*)host;

@end

@protocol WebServiceDelegate;

@interface WebService : NSObject
{
    NSMutableData           *fetchData;
    
    id<WebServiceDelegate>	delegate;
    
    int                     tag;
    
    NSTimer                 *timerInvalid;
    
    NSURLConnection         *urlConnection;
    
    NSMutableDictionary     *dictRet;
}

@property (nonatomic, assign) id<WebServiceDelegate>    delegate;
@property int tag;

-(void)setReturnCode:(int)code;
-(BOOL)postFirstDraft:(NSString*)firstDraft Revise:(NSString*)revise;
-(BOOL)postCoreValues:(NSArray*)coreValues Energy:(NSArray*)energyData;

@end


@protocol WebServiceDelegate
@optional
-(void)didFinishWebService:(WebService*)webService Ret:(NSDictionary*)dictRet;
@end