//
//  DiscoverThankViewController.h
//  HRA
//
//  Created by zhugang on 12-2-28.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscoverThankViewController : UIViewController
{
    
}


-(IBAction)btnHomeClick:(id)sender;

@end
