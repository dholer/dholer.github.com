//
//  DiscoverStep1InfoViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscoverStep1InfoViewController : UIViewController
{
    
}

-(IBAction)btnCloseClick:(id)sender;

@end
