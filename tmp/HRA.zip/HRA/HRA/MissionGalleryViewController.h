//
//  MissionGalleryViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CommonViewController.h"
#import "MissionGalleryInfoViewController.h"

@interface MissionGalleryViewController : CommonViewController
{
    NSArray                             *arrayMission;
    
    MissionGalleryInfoViewController    *infoViewController;
}

-(IBAction)btnInfoClick:(id)sender;

@end
