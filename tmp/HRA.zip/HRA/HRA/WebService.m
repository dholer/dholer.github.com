//
//  WebService.m
//  HRA
//
//  Created by Zhu Gang on 12-2-17.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "WebService.h"
#import "SBJson.h"

@implementation NSURLRequest (WebService_Login)

+ (BOOL) allowsAnyHTTPSCertificateForHost:(NSString *) host
{
	return TRUE;
}

@end


@implementation WebService
@synthesize delegate;
@synthesize tag;

-(void)dealloc
{
    [fetchData release];
    [timerInvalid release];
    [urlConnection release];
    [dictRet release];
    [super dealloc];
}

-(void)startTimer:(float)time
{
    if (timerInvalid)
    {
        [timerInvalid invalidate];
        [timerInvalid release];
        timerInvalid = nil;
    }
    
    timerInvalid = [[NSTimer scheduledTimerWithTimeInterval:time
                                                     target:self
                                                   selector:@selector(accessTimeoutTimer)
                                                   userInfo:nil
                                                    repeats:NO]retain];
}

-(void)accessTimeoutTimer
{
    NSLog(@"time out");
    [urlConnection cancel];
    [urlConnection release];
    urlConnection = nil;
    
    [self setReturnCode:kNetworkError];
    
    [timerInvalid invalidate];
    timerInvalid = nil;
    
    if (delegate)
        [delegate didFinishWebService:self Ret:dictRet];
}

-(void)stopTimer
{
    [timerInvalid invalidate];
    [timerInvalid release];
    timerInvalid = nil;
}

-(void)setReturnCode:(int)code
{
    if (dictRet==nil)
        dictRet = [[NSMutableDictionary dictionary]retain];
    
    [dictRet setObject:[NSNumber numberWithInt:code] forKey:@"ret"];
    
}

-(BOOL)postFirstDraft:(NSString*)firstDraft Revise:(NSString*)revise
{
    NSString *accessLink = [NSString stringWithFormat:@"%@:%d/%@", 
                            kServerAddress, 
                            kServerPort, 
                            kAPIHeader];
    
    
    NSMutableDictionary *dictData = [NSMutableDictionary dictionary];
    [dictData setValue:@"mission.create" forKey:@"method"];
    
    NSMutableDictionary *dictMission = [NSMutableDictionary dictionary];
    [dictMission setValue:firstDraft forKey:@"first_draft"];
    [dictMission setValue:revise forKey:@"revise"];
    
    [dictData setValue:dictMission forKey:@"params"];
    
    NSString *postString = [dictData JSONRepresentation];
    
    NSLog(@"Link:%@", accessLink);
    NSLog(@"Post:\r\n%@", postString);
    
    NSData *postData = [postString dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
	
	NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
	
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:[NSURL URLWithString:accessLink]];
	[request setHTTPMethod:@"POST"];
	[request setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request setValue:@"application/json;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
	[request setHTTPBody:postData];
	
	urlConnection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    [self startTimer:15.0];
    
    return urlConnection != nil;
}

-(BOOL)postCoreValues:(NSArray*)coreValues Energy:(NSArray*)energyData
{
    NSString *accessLink = [NSString stringWithFormat:@"%@:%d/%@", 
                            kServerAddress, 
                            kServerPort, 
                            kAPIHeader];
    
    
    NSMutableDictionary *dictData = [NSMutableDictionary dictionary];
    [dictData setValue:@"core.create" forKey:@"method"];
    
    NSMutableArray *arrayValues = [NSMutableArray array];
    
    for(NSDictionary *dictItem in coreValues)
    {
        NSMutableDictionary *dictData = [NSMutableDictionary dictionary];
        
        int value = [[dictItem objectForKey:@"Value"]floatValue]*100;
        [dictData setValue:[dictItem objectForKey:@"Word"] forKey:@"core_name"];
        [dictData setValue:[NSNumber numberWithInt:value] forKey:@"value"];
        [dictData setValue:@"importance" forKey:@"core_type"];
        
        [arrayValues addObject:dictData];
    }
    
    for(NSDictionary *dictItem in energyData)
    {
        NSMutableDictionary *dictData = [NSMutableDictionary dictionary];
        
        int value = [[dictItem objectForKey:@"Value"]floatValue]*100;
        [dictData setValue:[dictItem objectForKey:@"Word"] forKey:@"core_name"];
        [dictData setValue:[NSNumber numberWithInt:value] forKey:@"value"];
        [dictData setValue:@"energy" forKey:@"core_type"];
        
        [arrayValues addObject:dictData];
    }
    
    [dictData setValue:arrayValues forKey:@"params"];
    
    NSString *postString = [dictData JSONRepresentation];
    
    NSLog(@"Link:%@", accessLink);
    NSLog(@"Post:\r\n%@", postString);
    
    NSData *postData = [postString dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
	
	NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
	
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:[NSURL URLWithString:accessLink]];
	[request setHTTPMethod:@"POST"];
	[request setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request setValue:@"application/json;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
	[request setHTTPBody:postData];
	
	urlConnection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    [self startTimer:15.0];
    
    return urlConnection != nil;
}

#pragma mark NSURLConnection delegate methods
- (BOOL)connectionShouldUseCredentialStorage:(NSURLConnection *)connection
{
    return YES;
}

- (void)connection:(NSURLConnection *)connection willSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge
{
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust])
        //if ([trustedHosts containsObject:challenge.protectionSpace.host])
        [challenge.sender useCredential:[NSURLCredential	credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
	
	[challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];   
}

- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace 
{
	return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge 
{
	if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust])
        //if ([trustedHosts containsObject:challenge.protectionSpace.host])
        [challenge.sender useCredential:[NSURLCredential	credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
	
	[challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];
}

- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)data
{
    if (fetchData==nil)
        fetchData = [[NSMutableData alloc]init];
    
    if (dictRet == nil)
        dictRet = [[NSMutableDictionary alloc]init];
    
	[fetchData appendData:data];
	
}

- (void)connection:(NSURLConnection *)theConnection didFailWithError:(NSError *)error
{
    [self stopTimer];
    
    NSLog(@"Error:%@, code:%d", [error localizedDescription], error.code);
    
    [self setReturnCode:kNetworkError];
    
    if (delegate)
        [delegate didFinishWebService:self Ret:dictRet];
}


- (void)connectionDidFinishLoading:(NSURLConnection *)theConnection
{    
    [self stopTimer];
    
    NSString *retJson = [[[NSString alloc] initWithBytes:[fetchData bytes] length:[fetchData length] encoding:NSUTF8StringEncoding]autorelease];
    
    NSLog(@"Ret:%@", retJson);
                        
    NSDictionary *dictData = [retJson JSONValue];
           
    if (dictData && [dictData objectForKey:@"result"])
    {
        [dictRet setValue:dictData forKey:@"Data"];
        [self setReturnCode:kSuccess];
    }
    else
        [self setReturnCode:kJsonError];
    
    [fetchData release];
    fetchData = nil;
    
    if (delegate)
        [delegate didFinishWebService:self Ret:dictRet];
    
}



@end
