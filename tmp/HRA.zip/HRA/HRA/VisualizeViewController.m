//
//  VisualizeViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-11.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "VisualizeViewController.h"
#import "ValueToolViewController.h"
#import "FeedbackViewController.h"
#import "AppDelegate.h"


@implementation VisualizeViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        type = kTypeCoreValues;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
}

-(void)showInfoView
{
    if (infoViewController == nil)
        infoViewController = [[VisualizeInfoViewController alloc]initWithNibName:@"VisualizeInfoViewController" bundle:nil];
    infoViewController.view.alpha = 0.0;
    [self.view addSubview:infoViewController.view];
    [UIView animateWithDuration:0.8 animations:^{
        infoViewController.view.alpha = 1.0;
    } completion:^(BOOL finished)
     {
         
     }];

}

-(IBAction)btnNextClick:(id)sender
{
    if (type == kTypeCoreValues)
    {
        ValueToolViewController *viewController = [[[ValueToolViewController alloc]initWithNibName:@"ValueToolViewController" bundle:nil]autorelease];
        viewController.homeViewController = self.homeViewController;
        viewController.backViewController = self.backViewController;
        [viewController setType:kTypeEnergy];
        [self.navigationController pushViewController:viewController animated:YES];
        
    }
    else if (type == kTypeEnergy)
    {
        VisualizeViewController *viewController = [[[VisualizeViewController alloc]initWithNibName:@"VisualizeViewController" bundle:nil]autorelease];
        viewController.homeViewController = self.homeViewController;
        viewController.backViewController = self.backViewController;
        
        [self.navigationController pushViewController:viewController animated:YES];
        [viewController visualizeWord:kTypeAll];
    }
    else
    {
        FeedbackViewController *viewController = [[[FeedbackViewController alloc]initWithNibName:@"FeedbackViewController" bundle:nil]autorelease];
        viewController.homeViewController = self.homeViewController;
        viewController.backViewController = self.backViewController;
        
        [self.navigationController pushViewController:viewController animated:YES];
        
        /*WebService *webService = [[WebService alloc]init];
        webService.delegate = self;
        webService.tag = 200;
        NSArray *arrayCoreValue = [DataMgr readCoreValuesData];
        NSArray *arrayEnery = [DataMgr readEnergyData];
        if ([webService postCoreValues:arrayCoreValue Energy:arrayEnery] == NO)
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                            message:@"Error" 
                                                           delegate:nil cancelButtonTitle:@"Dismiss" 
                                                  otherButtonTitles:nil];
            [alert show];
            [alert release];
            [webService release];
            webService = nil;
        }
        else
        {
            [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
            [((AppDelegate*)[UIApplication sharedApplication].delegate) showLoadingView];
        }*/
        
    }
}


#pragma mark WebServiceDelegate delegate methods
-(void)didFinishWebService:(WebService*)webService Ret:(NSDictionary*)dictRet;
{   
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    
    
    [((AppDelegate*)[UIApplication sharedApplication].delegate) hideLoadingView];
    
    
    int ret = [[dictRet objectForKey:@"ret"]intValue];
    if (ret == kNetworkError)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                        message:@"Bad Network, please try it again." 
                                                       delegate:nil cancelButtonTitle:@"Dismiss" 
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    else if (ret == kJsonError)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                        message:@"Unkonw return, please try it again." 
                                                       delegate:nil cancelButtonTitle:@"Dismiss" 
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    else
    {
        NSDictionary *dictData = [dictRet objectForKey:@"Data"];
        NSDictionary *dictRestule = [dictData objectForKey:@"result"];
        NSString *msg = [dictRestule objectForKey:@"Msg"];
        int number = [[dictRestule objectForKey:@"Errno"]intValue];
        if (number == 0)
        {
            FeedbackViewController *viewController = [[[FeedbackViewController alloc]initWithNibName:@"FeedbackViewController" bundle:nil]autorelease];
            viewController.homeViewController = self.homeViewController;
            viewController.backViewController = self.backViewController;
            
            [self.navigationController pushViewController:viewController animated:YES];
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                            message:msg 
                                                           delegate:nil cancelButtonTitle:@"Dismiss" 
                                                  otherButtonTitles:nil];
            [alert show];
            [alert release];
        }
        
    }
    
}

//min:16
//max:40
//40-16 = 24

-(void)createWord:(int)wordType
{
    NSArray *arrayList = nil;
    
    if (wordType == kTypeCoreValues)
        arrayList = [DataMgr readCoreValuesData];
    else
        arrayList = [DataMgr readEnergyData];
    
    for(NSDictionary *dictItem in arrayList)
    {
        NSDictionary *dictPoint = nil;
        if (wordType == kTypeCoreValues)
            dictPoint = [dictItem objectForKey:@"Point1"];
        else
            dictPoint = [dictItem objectForKey:@"Point2"];
        
        CGPoint center = CGPointMake([[dictPoint objectForKey:@"x"]floatValue], [[dictPoint objectForKey:@"y"]floatValue]+(type == kTypeAll ? 15 : 40));
        NSString *word = [dictItem objectForKey:@"Word"];
        float value = [[dictItem objectForKey:@"Value"]floatValue];
        float fontSize = 16 + 24 * value;
        UILabel *label = [[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 320, 240)]autorelease];
        label.text = word;
        label.font = [UIFont systemFontOfSize:fontSize];
        label.adjustsFontSizeToFitWidth = NO;
        [label sizeToFit];
        label.center = center;
        
        if (label.frame.origin.x < 0)
            label.center = CGPointMake(label.center.x - label.frame.origin.x, label.center.y);
        
        if (label.frame.origin.x + label.frame.size.width > 320)
            label.center = CGPointMake(label.center.x - (label.frame.origin.x + label.frame.size.width - 320), label.center.y);
        
        if (wordType == kTypeCoreValues)
            label.textColor = RGBColor(0, 125, 198);
        else
            label.textColor = RGBColor(233, 18, 87);
        
        label.backgroundColor = [UIColor clearColor];
        
        [self.view addSubview:label];
    }
}

-(void)visualizeWord:(int)toolType;
{
    type = toolType;
    UILabel *labelInfo = (UILabel*)[self.view viewWithTag:10];
    UILabel *labelInfo2 = (UILabel*)[self.view viewWithTag:11];
    UIButton *btnNext = (UIButton*)[self.view viewWithTag:21];
    [btnNext setTitle:@"Next" forState:UIControlStateNormal];
    labelInfo.font = [UIFont systemFontOfSize:16];
    if (type == kTypeCoreValues)
    {
        labelInfo.text = @"The different sizes of the words show how you ranked your values.\r\n  ";
        labelInfo.textAlignment = UITextAlignmentLeft;
        
        labelInfo2.hidden = YES;
        
        [self createWord:type];
    }
    else if (type == kTypeEnergy)
    {
        labelInfo2.hidden = NO;
        labelInfo.text = @"The different sizes of the words show you ranked the amount of              you devote to each value.";
        labelInfo.textAlignment = UITextAlignmentLeft;
        [self createWord:type];
    }
    else
    {
        labelInfo2.hidden = YES;
        
        //[btnNext setTitle:@"You're Done!" forState:UIControlStateNormal];
        [btnNext setTitle:@"Next" forState:UIControlStateNormal];
        labelInfo.text = @"Blue = “The Talk”   Red = “The Walk”\r\n\r\n\r\n  ";
        labelInfo.textAlignment = UITextAlignmentCenter;
        labelInfo.font = [UIFont boldSystemFontOfSize:16];
        [self createWord:kTypeCoreValues];
        [self createWord:kTypeEnergy];
        
        [self showInfoView];
    }
    
    
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [infoViewController release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
