//
//  MainViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-1-19.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "MainViewController.h"
#import "HappyHundredthStep1ViewController.h"
#import "ThreeInOneStep1ViewController.h"
#import "ValueToolViewController.h"
#import "FeedbackViewController.h"
#import "DiscoverStep2ViewController.h"
#import "ValueToolViewController.h"
#import "DiscoverThankViewController.h"

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    self.navigationController.navigationBarHidden = YES;
    
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
    
    [self showGuideView];
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc
{
    [super dealloc];
}


-(void)showGuideView
{
    /*HappyHundredthStep1ViewController *viewControllerTmp = [[[HappyHundredthStep1ViewController alloc]initWithNibName:@"HappyHundredthStep1ViewController" bundle:nil]autorelease];
    
    viewControllerTmp.homeViewController = self;
    
    [self.navigationController pushViewController:viewControllerTmp animated:YES];
    
    return;*/
    
    
    /*ThreeInOneStep1ViewController *viewControllerTmp = [[[ThreeInOneStep1ViewController alloc]initWithNibName:@"ThreeInOneStep1ViewController" bundle:nil]autorelease];
    
    viewControllerTmp.homeViewController = self;
    
    [self.navigationController pushViewController:viewControllerTmp animated:YES];
    
    return;*/
    
    
     
     /*DiscoverStep2ViewController *viewControllerTmp = [[[DiscoverStep2ViewController alloc]initWithNibName:@"DiscoverStep2ViewController" bundle:nil]autorelease];
     
     viewControllerTmp.homeViewController = self;
     [self.navigationController pushViewController:viewControllerTmp animated:YES];
    
     return;*/
     
    /*ValueToolViewController *viewController = [[[ValueToolViewController alloc]initWithNibName:@"ValueToolViewController" bundle:nil]autorelease];
    viewController.homeViewController = viewController;
    [self.navigationController pushViewController:viewController animated:YES];
    [viewController setType:kTypeCoreValues];
    return;*/
    
    /*DiscoverThankViewController *viewControllerTmp = [[[DiscoverThankViewController alloc]initWithNibName:@"DiscoverThankViewController" bundle:nil]autorelease];
    
    [self.navigationController pushViewController:viewControllerTmp animated:YES];
    return;*/
    
    [self.navigationController popToRootViewControllerAnimated:NO];
    
    GuideViewController *guideViewController = [[[GuideViewController alloc]initWithNibName:@"GuideViewController" bundle:nil]autorelease];
    guideViewController.parent = self;
    
    [self.navigationController pushViewController:guideViewController animated:YES];
    
}

-(void)showHomeView
{
    HomeViewController *homeViewController = [[[HomeViewController alloc]initWithNibName:@"HomeViewController" bundle:nil]autorelease];
    
    [self.navigationController pushViewController:homeViewController animated:YES];
}

@end
