//
//  DiscoverStep3ViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-7.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "DiscoverStep3ViewController.h"
#import "ValueToolViewController.h"
#import "DiscoverStep4ViewController.h"

@implementation DiscoverStep3ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSMutableArray *arrayTmp = [NSMutableArray array];
    {
        NSMutableDictionary *dictItem = [NSMutableDictionary dictionary];
        [dictItem setValue:@"Core Values" forKey:@"Title"];
        [dictItem setValue:@"sign-questionmark.png" forKey:@"Image"];
        [arrayTmp addObject:dictItem];
    }
    
    /*{
        NSMutableDictionary *dictItem = [NSMutableDictionary dictionary];
        [dictItem setValue:@"Energy" forKey:@"Title"];
        [dictItem setValue:@"icon-question.png" forKey:@"Image"];
        [arrayTmp addObject:dictItem];
    }*/
    
    arrayItem = [arrayTmp retain];
}

-(IBAction)btnNextClick:(id)sender
{
    DiscoverStep4ViewController *viewController = [[[DiscoverStep4ViewController alloc]initWithNibName:@"DiscoverStep4ViewController" bundle:nil]autorelease];
    viewController.homeViewController = self.homeViewController;
    viewController.backViewController = self;
    [self.navigationController pushViewController:viewController animated:YES];
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    btnNext.enabled = [DataMgr hasCoreValuesData] && [DataMgr hasEnergyData];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)dealloc
{
    [arrayItem release];
    [btnNext release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return [arrayItem count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	UITableViewCell *cell = nil;
    
    static NSString *FirstLevelCell= @"Step3Cell";
    cell = [tableView dequeueReusableCellWithIdentifier: 
            FirstLevelCell];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                       reuseIdentifier: FirstLevelCell] autorelease];
        
        
            
    }
    
    NSInteger row = [indexPath row];
    NSDictionary *dictItem = [arrayItem objectAtIndex:row];
    cell.textLabel.text = [dictItem objectForKey:@"Title"];
    cell.imageView.image = [UIImage imageNamed:[dictItem objectForKey:@"Image"]];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    //NSUInteger row = [indexPath row];
    
    
    //[self.navigationController pushViewController:nextController animated:YES];
    ValueToolViewController *viewController = [[[ValueToolViewController alloc]initWithNibName:@"ValueToolViewController" bundle:nil]autorelease];
    viewController.homeViewController = self;
    [self.navigationController pushViewController:viewController animated:YES];
    [viewController setType:kTypeCoreValues];
     
}

@end
