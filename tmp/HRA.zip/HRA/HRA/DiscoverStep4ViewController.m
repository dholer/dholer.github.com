//
//  DiscoverStep4ViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-12.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "DiscoverStep4ViewController.h"
#import "HomeViewController.h"
#import "AppDelegate.h"
#import "DiscoverThankViewController.h"

@implementation DiscoverStep4ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self btnInfoClick:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillShow) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillHide) name:UIKeyboardWillHideNotification object:nil];
    
    textViewFirstDraft.text = [DataMgr readMissionFirstDraft];
    
    NSString *revised = [DataMgr readMissionRevised];
    if ([revised length]>0)
    {
        textViewRevised.text = revised;
        btnSave.enabled = NO;
        [btnSave setTitle:@"Saved" forState:UIControlStateNormal];
        [btnSave setTitle:@"Saved" forState:UIControlStateHighlighted];
        btnNext.enabled = YES;
    }
    
    viewSave.hidden = YES;
}

- (void) keyboardWillShow
{
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.6];
    self.view.transform = CGAffineTransformMakeTranslation(0, -165);
	[UIView commitAnimations];
    
    btnNext.enabled = NO;
    btnSave.enabled = YES;
    [btnSave setTitle:@"Done!" forState:UIControlStateNormal];
    [btnSave setTitle:@"Done!" forState:UIControlStateHighlighted];
    
}

- (void) keyboardWillHide
{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	self.view.transform = CGAffineTransformMakeTranslation(0, 0);
	[UIView commitAnimations];
    
    if ([textViewRevised.text length] > 0)
    {
        [btnSave setTitle:@"Save" forState:UIControlStateNormal];
        [btnSave setTitle:@"Save" forState:UIControlStateHighlighted];
    }
    else
    {
        [btnSave setTitle:@"Done!" forState:UIControlStateNormal];
        [btnSave setTitle:@"Done!" forState:UIControlStateHighlighted];
    }
}

-(IBAction)btnInfoClick:(id)sender
{
    if (infoViewController == nil)
        infoViewController = [[DiscoverStep4InfoViewController alloc]initWithNibName:@"DiscoverStep4InfoViewController" bundle:nil];
    infoViewController.view.alpha = 0.0;
    
    [self.view addSubview:infoViewController.view];
    [UIView animateWithDuration:0.8 animations:^{
        infoViewController.view.alpha = 1.0;
    } completion:^(BOOL finished)
     {
         
     }];
}

-(IBAction)btnGalleryClick:(id)sender
{
    [textViewRevised resignFirstResponder];
    
    MissionGalleryViewController *galleryViewController = [[[MissionGalleryViewController alloc]initWithNibName:@"MissionGalleryViewController" bundle:nil]autorelease];
    [self.navigationController pushViewController:galleryViewController animated:YES];
    
}

-(IBAction)btnSaveClick:(id)sender
{
    if ([textViewRevised isFirstResponder])
    {
        [textViewRevised resignFirstResponder];
    }
    else
    {
        if ([textViewRevised.text length] <= 0)
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                            message:@"Please try to write your revised mission" 
                                                           delegate:nil cancelButtonTitle:@"Dismiss" 
                                                  otherButtonTitles:nil];
            [alert show];
            [alert release];
            return;
        }
        else
        {
            //btnSave.enabled = NO;
            //[btnSave setTitle:@"Saved" forState:UIControlStateNormal];
            //[btnSave setTitle:@"Saved" forState:UIControlStateHighlighted];
            //btnNext.enabled = YES;
            
            //[DataMgr saveMissionFirstDraft:textViewInfo.text];
            
            //show save view
            viewSave.alpha = 0.0;
            viewSave.hidden = NO;
            [UIView animateWithDuration:0.8 animations:^{
                viewSave.alpha = 1.0;
            } completion:^(BOOL finished)
             {
                 
             }];
        }
    }
}

-(void)postMissio2Server
{
    NSString *firstDraft = [DataMgr readMissionFirstDraft];
    NSString *revise = [DataMgr readMissionRevised];
    
    WebService *webService = [[WebService alloc]init];
    webService.delegate = self;
    webService.tag = 100;
    if ([webService postFirstDraft:firstDraft Revise:revise] == NO)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                        message:@"Error" 
                                                       delegate:nil cancelButtonTitle:@"Dismiss" 
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        [webService release];
        webService = nil;
    }
    else
    {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
        [((AppDelegate*)[UIApplication sharedApplication].delegate) showLoadingView];
    }
}

-(void)saveRevisedMission:(NSString*)text
{
    btnSave.enabled = NO;
    [btnSave setTitle:@"Saved" forState:UIControlStateNormal];
    [btnSave setTitle:@"Saved" forState:UIControlStateHighlighted];
    btnNext.enabled = YES;
    
    [DataMgr saveMissionRevised:text];
    
    [self btnCloseSaveViewClick:nil];
}

-(IBAction)btnSaveAndPostClick:(id)sender
{
    [self saveRevisedMission:textViewRevised.text];
 
    //Post to server
    [self postMissio2Server];
}

-(IBAction)btnSaveNoPostClick:(id)sender
{
    [self saveRevisedMission:textViewRevised.text];
}

-(IBAction)btnCloseSaveViewClick:(id)sender
{
    [UIView animateWithDuration:0.8 animations:^{
        viewSave.alpha = 0.0;
    } completion:^(BOOL finished)
     {
         viewSave.hidden = YES;
     }];
}

-(IBAction)btnPreviousClick:(id)sender
{
    //[self.navigationController popToViewController:self.backViewController animated:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnNextClick:(id)sender
{
    /*HomeViewController *homeController = (HomeViewController*)self.homeViewController;
    [self.navigationController popToViewController:homeController animated:YES];
 
    [homeController showDiscoverDoneInfo];*/
    
    WebService *webService = [[WebService alloc]init];
    webService.delegate = self;
    webService.tag = 200;
    NSArray *arrayCoreValue = [DataMgr readCoreValuesData];
    NSArray *arrayEnery = [DataMgr readEnergyData];
    if ([webService postCoreValues:arrayCoreValue Energy:arrayEnery] == NO)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                        message:@"Error" 
                                                       delegate:nil cancelButtonTitle:@"Dismiss" 
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        [webService release];
        webService = nil;
    }
    else
    {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
        [((AppDelegate*)[UIApplication sharedApplication].delegate) showLoadingView];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [textViewFirstDraft release];
    [textViewRevised release];
    [btnNext release];
    [btnSave release];
    [infoViewController release];
    [viewSave release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark WebServiceDelegate delegate methods
-(void)didFinishWebService:(WebService*)webService Ret:(NSDictionary*)dictRet;
{   
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    [((AppDelegate*)[UIApplication sharedApplication].delegate) hideLoadingView];
    
    
    int ret = [[dictRet objectForKey:@"ret"]intValue];
    if (ret == kNetworkError)
    {
        [btnSave setTitle:@"Save" forState:UIControlStateNormal];
        [btnSave setTitle:@"Save" forState:UIControlStateHighlighted];
        btnSave.enabled = YES;
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                        message:@"Bad Network, please try it again." 
                                                       delegate:nil cancelButtonTitle:@"Dismiss" 
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    else if (ret == kJsonError)
    {
        [btnSave setTitle:@"Save" forState:UIControlStateNormal];
        [btnSave setTitle:@"Save" forState:UIControlStateHighlighted];
        btnSave.enabled = YES;
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                        message:@"Unkonw return, please try it again." 
                                                       delegate:nil cancelButtonTitle:@"Dismiss" 
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    else
    {
        NSDictionary *dictData = [dictRet objectForKey:@"Data"];
        NSDictionary *dictRestule = [dictData objectForKey:@"result"];
        NSString *msg = [dictRestule objectForKey:@"Msg"];
        
        if (webService.tag == 100)
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                            message:msg 
                                                           delegate:nil cancelButtonTitle:@"Close" 
                                                  otherButtonTitles:nil];
            [alert show];
            [alert release];
        }
        else
        {
            int number = [[dictRestule objectForKey:@"Errno"]intValue];
            if (number == 0)
            {
                /*HomeViewController *homeController = (HomeViewController*)self.homeViewController;
                [self.navigationController popToViewController:homeController animated:YES];
                
                [homeController showDiscoverDoneInfo];*/
                
                DiscoverThankViewController *thankViewController = [[[DiscoverThankViewController alloc]initWithNibName:@"DiscoverThankViewController" bundle:nil]autorelease];
                
                [self.navigationController pushViewController:thankViewController animated:YES];
                
            }
            else
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                                message:msg 
                                                               delegate:nil cancelButtonTitle:@"Dismiss" 
                                                      otherButtonTitles:nil];
                [alert show];
                [alert release];
            }
        }
        
        
    }
  
}

@end
