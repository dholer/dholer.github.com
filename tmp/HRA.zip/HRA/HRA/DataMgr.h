//
//  DataMgr.h
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(Bundle)
-(NSString *)bundlePath;
@end

#define kTypeCoreValues     10
#define kTypeEnergy         20
#define kTypeAll            30


@interface DataMgr : NSObject

+(BOOL)isDiscoverActive;

+(NSArray*)getMissionGallery;
+(NSString*)readMissionFirstDraft;
+(void)saveMissionFirstDraft:(NSString*)text;

+(NSString*)readMissionRevised;
+(void)saveMissionRevised:(NSString*)text;


+(NSArray*)getActivities;

+(NSArray*)getPlistData:(NSString*)fileName;

+(void)saveHappyHundredthData:(NSArray*)data;
+(NSMutableArray*)readHappyHundredthData;
+(BOOL)hasHappyHundredthData;

+(void)saveThreeInOneData:(NSArray*)data;
+(NSMutableArray*)readThreeInOneData;
+(BOOL)hasThreeInOneData;

+(void)saveSuperpowerData:(NSDictionary*)data;
+(NSMutableDictionary*)readSuperPowerData;
+(BOOL)hasSuperpowerData;

+(void)saveCoreValuesData:(NSArray*)data;
+(NSMutableArray*)readCoreValuesData;
+(BOOL)hasCoreValuesData;


+(void)saveEnergyData:(NSArray*)data;
+(NSMutableArray*)readEnergyData;
+(BOOL)hasEnergyData;





@end
