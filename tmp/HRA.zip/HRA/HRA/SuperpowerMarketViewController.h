//
//  SuperpowerMarketViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-18.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"
#import "SuperpowerItemViewController.h"

@interface SuperpowerMarketViewController : CommonViewController
{
    NSArray         *arrayPowerImage;
    int             powerIndex;
}


-(void)showSuperpower:(int)index;
-(IBAction)btnPowerClick:(UIButton*)btn;
-(IBAction)btnFinishPower:(id)sender;

@end
