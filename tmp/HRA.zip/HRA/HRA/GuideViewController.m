//
//  GuideViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-1-19.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "GuideViewController.h"
#import "MainViewController.h"

@implementation GuideViewController
@synthesize parent;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self.view addSubview:guideView1]; 
    [self.view addSubview:guideView2]; 
    [self.view addSubview:guideView3]; 

    
    guideView1.frame = CGRectMake(0, 0, 320, 460);
    guideView2.frame = CGRectMake(320, 0, 320, 460);
    guideView3.frame = CGRectMake(640, 0, 320, 460);
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
	self.navigationController.navigationBarHidden = YES;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [guideView1 release];
    [guideView2 release];
    [guideView3 release];
    [parent release];
    [super dealloc];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)btnPreviousClick:(UIButton*)btn
{
    if (btn.tag == 20 || btn.tag == 30)
    {
        [UIView animateWithDuration:0.3 animations:^{
            guideView1.frame = CGRectMake(guideView1.frame.origin.x+320, 0, 320, 460);
            guideView2.frame = CGRectMake(guideView2.frame.origin.x+320, 0, 320, 460);
            guideView3.frame = CGRectMake(guideView3.frame.origin.x+320, 0, 320, 460);
        } completion:^(BOOL finished)
         {
             
         }];
    }
    
}

-(IBAction)btnNextClick:(UIButton*)btn
{
    if (btn.tag == 11 || btn.tag == 21)
    {
        [UIView animateWithDuration:0.3 animations:^{
            guideView1.frame = CGRectMake(guideView1.frame.origin.x-320, 0, 320, 460);
            guideView2.frame = CGRectMake(guideView2.frame.origin.x-320, 0, 320, 460);
            guideView3.frame = CGRectMake(guideView3.frame.origin.x-320, 0, 320, 460);
        } completion:^(BOOL finished)
         {
             
         }];
    }
    else
    {
        //start
        [parent showHomeView];
    }
}

@end
