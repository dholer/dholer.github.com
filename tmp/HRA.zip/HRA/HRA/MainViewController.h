//
//  MainViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-1-19.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GuideViewController.h"
#import "HomeViewController.h"

@interface MainViewController : UIViewController
{
    
}

-(void)showGuideView;
-(void)showHomeView;

@end
