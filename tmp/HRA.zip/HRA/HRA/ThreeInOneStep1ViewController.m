//
//  ThreeInOneStep1ViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-3.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "ThreeInOneStep1ViewController.h"

@implementation ThreeInOneStep1ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if ([DataMgr hasThreeInOneData])
    {
        arrayData = [[DataMgr readThreeInOneData]retain];
        
        
        NSArray *arrayList = [DataMgr getPlistData:@"ThreeInOne.plist"];
        int i=0;
        for(NSDictionary *dictItem in arrayList)
        {
            NSMutableDictionary *dictData = [arrayData objectAtIndex:i];
            [dictData setValue:[dictItem objectForKey:@"Title"] forKey:@"Title"];
            i++;
        }
        
    }
    else
    {
        arrayData = [[NSMutableArray array]retain];
        
        NSArray *arrayInfo = [DataMgr getPlistData:@"ThreeInOne.plist"];
        
        for(NSDictionary *dictItem in arrayInfo)
        {
            NSMutableDictionary *dictAdd = [NSMutableDictionary dictionary];
            [dictAdd setDictionary:dictItem];
            [arrayData addObject:dictAdd];
        }
    }
    
    
    rcSave = tableViewContent.frame;
    
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillShow) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillHide) name:UIKeyboardWillHideNotification object:nil];
    
    [NSTimer scheduledTimerWithTimeInterval:2.0
                                     target:self
                                   selector:@selector(flashScrollBar)
                                   userInfo:nil
                                    repeats:YES];
}

-(void)flashScrollBar
{
    [tableViewContent flashScrollIndicators];
}

- (void) keyboardWillShow
{
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
    tableViewContent.frame = CGRectMake(rcSave.origin.x, rcSave.origin.y, rcSave.size.width, rcSave.size.height-166);
	[UIView commitAnimations];
    
}

- (void) keyboardWillHide
{
	//[UIView beginAnimations:nil context:nil];
	//[UIView setAnimationDuration:0.3];
	tableViewContent.frame = rcSave;
	//[UIView commitAnimations];
    
    
}

-(IBAction)btnPutTogetherClick:(id)sender
{
    if ([[[[arrayData objectAtIndex:0] objectForKey:@"Values"]objectAtIndex:0]length]<=0 ||
        [[[[arrayData objectAtIndex:0] objectForKey:@"Values"]objectAtIndex:1]length]<=0 ||
        [[[[arrayData objectAtIndex:0] objectForKey:@"Values"]objectAtIndex:2]length]<=0 ||
        [[[[arrayData objectAtIndex:1] objectForKey:@"Values"]objectAtIndex:0]length]<=0 ||
        [[[[arrayData objectAtIndex:1] objectForKey:@"Values"]objectAtIndex:1]length]<=0 ||
        [[[[arrayData objectAtIndex:1] objectForKey:@"Values"]objectAtIndex:2]length]<=0 ||
        [[[[arrayData objectAtIndex:2] objectForKey:@"Values"]objectAtIndex:0]length]<=0 ||
        [[[[arrayData objectAtIndex:2] objectForKey:@"Values"]objectAtIndex:1]length]<=0 ||
        [[[[arrayData objectAtIndex:2] objectForKey:@"Values"]objectAtIndex:2]length]<=0 ||
        [[[[arrayData objectAtIndex:3] objectForKey:@"Values"]objectAtIndex:0]length]<=0 ||
        [[[[arrayData objectAtIndex:3] objectForKey:@"Values"]objectAtIndex:1]length]<=0 ||
        [[[[arrayData objectAtIndex:3] objectForKey:@"Values"]objectAtIndex:2]length]<=0 ||
        [[[[arrayData objectAtIndex:4] objectForKey:@"Values"]objectAtIndex:0]length]<=0 ||
        [[[[arrayData objectAtIndex:4] objectForKey:@"Values"]objectAtIndex:1]length]<=0 ||
        [[[[arrayData objectAtIndex:4] objectForKey:@"Values"]objectAtIndex:2]length]<=0 ||
        [[[[arrayData objectAtIndex:5] objectForKey:@"Values"]objectAtIndex:0]length]<=0 ||
        [[[[arrayData objectAtIndex:5] objectForKey:@"Values"]objectAtIndex:1]length]<=0 ||
        [[[[arrayData objectAtIndex:5] objectForKey:@"Values"]objectAtIndex:2]length]<=0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                        message:@"Please try to type in all questions" 
                                                       delegate:nil cancelButtonTitle:@"Dismiss" 
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        return;
    }
    
    
    
    ThreeInOneStep2ViewController *viewController = [[[ThreeInOneStep2ViewController alloc]initWithNibName:@"ThreeInOneStep2ViewController" bundle:nil]autorelease];
    
    viewController.homeViewController = self.homeViewController;
    viewController.arrayData = arrayData;
    
    [self.navigationController pushViewController:viewController animated:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillShowNotification
												  object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillHideNotification
												  object:nil];
    [arrayData release];
    [tableViewContent release];
    
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return [arrayData count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    NSDictionary *dictItem = [arrayData objectAtIndex:section];
    
    NSArray *arrayValues = [dictItem objectForKey:@"Values"];
    return  [arrayValues count];
    
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    NSDictionary *dictItem = [arrayData objectAtIndex:section];
    
    return [dictItem objectForKey:@"Title"];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	UITableViewCell *cell = nil;
    
    static NSString *FirstLevelCell= @"ThreeInOneCell";
    cell = [tableView dequeueReusableCellWithIdentifier: 
            FirstLevelCell];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                       reuseIdentifier: FirstLevelCell] autorelease];
        
        
        UITextField *textField = [[UITextField alloc]initWithFrame:CGRectMake(10, 0, cell.frame.size.width-40, cell.frame.size.height)];
        textField.tag = 10;
        textField.backgroundColor = [UIColor clearColor];
        textField.font = [UIFont systemFontOfSize:20];
        textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        textField.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        textField.textAlignment = UITextAlignmentLeft;
        textField.returnKeyType = UIReturnKeyDone;
        textField.textColor = RGBColor(70, 70, 70);
        textField.backgroundColor = [UIColor clearColor];
        textField.delegate = self;
        
        [textField addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventEditingDidEndOnExit];
        [cell.contentView addSubview:textField];
        [textField release];
    }
    
    NSInteger section = [indexPath section];
    NSInteger row = [indexPath row];
    
    NSDictionary *dictItem = [arrayData objectAtIndex:section];
    NSArray *arrayValue = [dictItem objectForKey:@"Values"];
    NSString *value = [arrayValue objectAtIndex:row];
    
    UITextField *textField = (UITextField*)[cell.contentView viewWithTag:10];
    if ([value length] > 0)
        textField.text = value;
    else
        textField.text = @"";
    
    NSString *key = [NSString stringWithFormat:@"Tips%d", row+1];
    NSString *keyValue = [dictItem objectForKey:key];
    if (keyValue)
        textField.placeholder = keyValue;
    else
        textField.placeholder = @"";
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.tag = 100*section + row;
    
    return cell;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    UITableViewCell *cell = (UITableViewCell*)[[textField superview]superview];
    
    
    NSInteger section = cell.tag/100;
    NSInteger row = cell.tag - section*100;
    
    NSIndexPath *path = [NSIndexPath indexPathForRow:row inSection:section];
    
    [self performSelector:@selector(showCell:) withObject:path afterDelay:0.3];
}

-(void)showCell:(NSIndexPath*)indexPath
{
    [tableViewContent scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    UITableViewCell *cell = (UITableViewCell*)[[textField superview]superview];
    
    NSInteger section = cell.tag/100;
    NSInteger row = cell.tag - section*100;
    
    
    NSMutableDictionary *dictItem = [arrayData objectAtIndex:section];
    NSMutableArray *arrayValues = [dictItem objectForKey:@"Values"];
    
    NSMutableArray *arrayUpdate = [NSMutableArray array];
    for(int i=0; i<[arrayValues count]; i++)
    {
        if (i == row)
            [arrayUpdate addObject:textField.text];
        else
            [arrayUpdate addObject:[arrayValues objectAtIndex:i]];
    }
    
    [dictItem setObject:arrayUpdate forKey:@"Values"];
    
}

-(void)saveAction:(UITextField*)textField
{
    UITableViewCell *cell = (UITableViewCell*)[[textField superview]superview];
    
    NSInteger section = cell.tag/100;
    NSInteger row = cell.tag - section*100;
    
    NSMutableDictionary *dictItem = [arrayData objectAtIndex:section];
    NSMutableArray *arrayValues = [dictItem objectForKey:@"Values"];
    
    NSMutableArray *arrayUpdate = [NSMutableArray array];
    for(int i=0; i<[arrayValues count]; i++)
    {
        if (i == row)
            [arrayUpdate addObject:textField.text];
        else
            [arrayUpdate addObject:[arrayValues objectAtIndex:i]];
    }
    
    [dictItem setObject:arrayUpdate forKey:@"Values"];
    
    
}


@end
