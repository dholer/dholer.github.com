//
//  FeedbackViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-12.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "FeedbackViewController.h"
#import "DiscoverStep4ViewController.h"

@implementation FeedbackViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    arrayItem = [[NSMutableArray array]retain];
    for(int i=0; i<5; i++)
    {
        [arrayItem addObject:[NSMutableDictionary dictionary]];
    }
    
    tableViewContent.tableHeaderView = viewHeader;
    tableViewContent.tableFooterView = viewFooter;
    tableViewContent.backgroundColor = [UIColor clearColor];
    rcSave = tableViewContent.frame;
    
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillShow) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillHide) name:UIKeyboardWillHideNotification object:nil];
    
    UILabel *labelInfo = (UILabel*)[viewHeader viewWithTag:10];
    labelInfo.hidden = YES;
    webView = [[UIWebView alloc]initWithFrame:labelInfo.frame];
    [viewHeader addSubview:webView];
    webView.backgroundColor = [UIColor clearColor];
    webView.userInteractionEnabled = NO;
    
    NSArray *arrayData = [DataMgr readHappyHundredthData];
    
    NSString *strHTML = [NSString stringWithFormat:@"<head><style>body{font-family:Helvetica;}</style></head><meta name=\"viewport\" content=\"width=240.0, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=yes\"/><div style='font-size:14px;color:0x464646'><i>%@ has given us your name as a person that they know and trust.  As part of a self-reflection exercise, here’s a list of ‘core values.’  In your opinion, how much <b>energy</b> (time and effort) do you think %@ regularly devotes to each one?  (1 = little or no energy; 2 = some energy; 3 = a lot of energy.)</i></div>", [[[arrayData objectAtIndex:0] objectForKey:@"Values"]objectAtIndex:0],[[[arrayData objectAtIndex:0] objectForKey:@"Values"]objectAtIndex:0]];
    
    [webView loadHTMLString:strHTML baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
    
    
    webView.backgroundColor = [UIColor clearColor];
	webView.opaque = NO;
	
	if ([[webView subviews] count] > 0)
	{
		UIView *shadowView = [[webView subviews] objectAtIndex:0];
		NSArray *array = [shadowView subviews];
		
		for(int i=0; i<[array count]-1; i++)
		{
			UIView *tmpView = [array objectAtIndex:i];
			tmpView.hidden = YES;
		}
	}
    
    [NSTimer scheduledTimerWithTimeInterval:2.0
                                     target:self
                                   selector:@selector(flashScrollBar)
                                   userInfo:nil
                                    repeats:YES];
}

-(void)flashScrollBar
{
    [tableViewContent flashScrollIndicators];
}


- (void) keyboardWillShow
{
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
    tableViewContent.frame = CGRectMake(rcSave.origin.x, rcSave.origin.y, rcSave.size.width, rcSave.size.height-166);
	[UIView commitAnimations];
    
}

- (void) keyboardWillHide
{
	//[UIView beginAnimations:nil context:nil];
	//[UIView setAnimationDuration:0.3];
	tableViewContent.frame = rcSave;
	//[UIView commitAnimations];
    
    
}

-(IBAction)btnBackExClick:(id)sender
{
    [self.navigationController popToViewController:self.backViewController animated:YES];
}

-(IBAction)btnSendEmailClick:(id)sender
{
    [currentTextField resignFirstResponder];
    NSLog(@"%@", arrayItem);
}

-(IBAction)btnNextClick:(id)sender
{
    DiscoverStep4ViewController *viewController = [[[DiscoverStep4ViewController alloc]initWithNibName:@"DiscoverStep4ViewController" bundle:nil]autorelease];
    //CommonViewController *homeController = (CommonViewController*)self.homeViewController;
    viewController.homeViewController = self.backViewController;
    viewController.backViewController = self;
    [self.navigationController pushViewController:viewController animated:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [viewHeader release];
    [tableViewContent release];
    [viewFooter release];
    [arrayItem release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	return 10;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{	
	UILabel *label = [[[UILabel alloc] init] autorelease];
	label.backgroundColor = [UIColor clearColor];
	return label;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return 1;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	UILabel *label = [[[UILabel alloc] init] autorelease];
	label.backgroundColor = [UIColor clearColor];
	return label;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	UITableViewCell *cell = nil;
    
    static NSString *FirstLevelCell= @"CoreValueCell";
    cell = [tableView dequeueReusableCellWithIdentifier: 
            FirstLevelCell];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                       reuseIdentifier: FirstLevelCell] autorelease];
        
        
        
        UILabel *label = [[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 50, 39)]autorelease];
        label.tag = 10;
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor blackColor];
        label.textAlignment = UITextAlignmentRight;
        label.font = [UIFont boldSystemFontOfSize:15];
        [cell.contentView addSubview:label];
        
        UITextField *textField = [[UITextField alloc]initWithFrame:CGRectMake(60, 0, cell.frame.size.width-85, cell.frame.size.height-3)];
        textField.tag = 20;
        textField.backgroundColor = [UIColor clearColor];
        textField.font = [UIFont systemFontOfSize:20];
        textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        textField.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        textField.textAlignment = UITextAlignmentLeft;
        textField.returnKeyType = UIReturnKeyDone;
        textField.textColor = RGBColor(70, 70, 70);
        textField.delegate = self;
        
        [textField addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventEditingDidEndOnExit];
        [cell.contentView addSubview:textField];
        [textField release];
        
    }
    
    NSInteger section = [indexPath section];
    NSInteger row = [indexPath row];
    NSMutableDictionary *dictItem = [arrayItem objectAtIndex:section];
    
    UILabel *labelTitle = (UILabel*)[cell.contentView viewWithTag:10];
    UITextField *labelValue = (UITextField*)[cell.contentView viewWithTag:20];
    if (row == 0)
    {
        labelTitle.text = @"Name";
        labelValue.text = [dictItem objectForKey:@"Name"];
        
    }
    else
    {
        labelTitle.text = @"Email";
        labelValue.text = [dictItem objectForKey:@"Email"];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.tag = 100*section + row;
    
    
    return cell;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    currentTextField = textField;
    
    UITableViewCell *cell = (UITableViewCell*)[[textField superview]superview];
    
    
    NSInteger section = cell.tag/100;
    NSInteger row = cell.tag - section*100;
    
    NSIndexPath *path = [NSIndexPath indexPathForRow:row inSection:section];
    
    [self performSelector:@selector(showCell:) withObject:path afterDelay:0.3];
}

-(void)showCell:(NSIndexPath*)indexPath
{
    [tableViewContent scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}


-(void)saveAction:(UITextField*)textField
{
    currentTextField = textField;
    
    UITableViewCell *cell = (UITableViewCell*)[[textField superview]superview];
    
    NSInteger section = cell.tag/100;
    NSInteger row = cell.tag - section*100;
    
    NSMutableDictionary *dictItem = [arrayItem objectAtIndex:section];
    if (row == 0)
        [dictItem setValue:textField.text forKey:@"Name"];
    else
        [dictItem setValue:textField.text forKey:@"Email"];
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self saveAction:textField];
}


@end
