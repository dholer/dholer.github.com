//
//  HappyHundredthStep2ViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "HappyHundredthStep2ViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation HappyHundredthStep2ViewController
@synthesize arrayData;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    coverAngle = 0.0;
    
    imageViewCover.layer.anchorPoint = CGPointMake(0.0, 0.5);
    imageViewCover.layer.position = CGPointMake(37.0, 287/2.0+imageViewCover.frame.origin.y);
    imageViewCover.layer.transform = CATransform3DMakeRotation(M_PI / 180*coverAngle, 0, -1, 0);
    
    CATransform3D sublayerTransform = CATransform3DIdentity;
    sublayerTransform.m34 = -0.0005;
    [self.view.layer setSublayerTransform:sublayerTransform];
    
    NSString *strContent = [NSString stringWithFormat:@"<div style='font-size:14px;color:0x464646'>Happy Birthday, %@!<br/><br/>Wow, what a century! Not only have you accomplished everything you set out to do, like %@, %@ and %@, but you surprised us all by mastering %@, and writing a best-selling book about %@<br/><br/>Have a great time on your upcoming trip to %@, and don't forget to pack your %@ and your %@!</div>",
                            [[[arrayData objectAtIndex:0] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:1] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:1] objectForKey:@"Values"]objectAtIndex:1],
                            [[[arrayData objectAtIndex:1] objectForKey:@"Values"]objectAtIndex:2],
                            [[[arrayData objectAtIndex:2] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:3] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:4] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:5] objectForKey:@"Values"]objectAtIndex:0],
                            [[[arrayData objectAtIndex:5] objectForKey:@"Values"]objectAtIndex:1]
                            ];
    
    // Do any additional setup after loading the view from its nib.
    NSString *strHTML = [NSString stringWithFormat:@"<head><style>body{font-family:Helvetica;}</style></head><meta name=\"viewport\" content=\"width=240.0, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=yes\"/>%@<br/><img src=\"signature@2x.png\" height=\"23\" width=\"86\"/><br/>%@", strContent,
                         [[[arrayData objectAtIndex:6] objectForKey:@"Values"]objectAtIndex:0]];
	[webViewContent loadHTMLString:strHTML baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
    
    webViewContent.backgroundColor = [UIColor clearColor];
	webViewContent.opaque = NO;
	
	if ([[webViewContent subviews] count] > 0)
	{
		UIView *shadowView = [[webViewContent subviews] objectAtIndex:0];
		NSArray *array = [shadowView subviews];
		
		for(int i=0; i<[array count]-1; i++)
		{
			UIView *tmpView = [array objectAtIndex:i];
			tmpView.hidden = YES;
		}
	}
    
    UIButton *btn = (UIButton*)[self.view viewWithTag:99];
    [self performSelector:@selector(btnCoverClick:) withObject:btn afterDelay:0.5];
    
    [NSTimer scheduledTimerWithTimeInterval:2.0
                                     target:self
                                   selector:@selector(flashScrollBar)
                                   userInfo:nil
                                    repeats:YES];
}

-(void)flashScrollBar
{
    [webViewContent.scrollView flashScrollIndicators];
}

-(IBAction)btnFinishClick:(id)sender
{
    [DataMgr saveHappyHundredthData:arrayData];
    [self btnRootClick:nil];
}

-(IBAction)btnCoverClick:(id)sender
{
    UIButton *btn = (UIButton*)sender;
    btn.hidden = YES;
    
    [UIView animateWithDuration:0.35 animations:^{
        imageViewCover.transform = CGAffineTransformMakeTranslation(20, 0);
        webViewContent.transform = CGAffineTransformMakeTranslation(20, 0);
        imageViewBottom.transform = CGAffineTransformMakeTranslation(20, 0);
    } completion:^(BOOL finished)
     {
         coverAngle = 0.0;
         imageViewCover.layer.anchorPoint = CGPointMake(0.0, 0.5);
         imageViewCover.layer.position = CGPointMake(37+20.0, 287/2.0+imageViewCover.frame.origin.y);
         imageViewCover.layer.transform = CATransform3DMakeRotation(M_PI / 180*coverAngle, 0, -1, 0);
          
         if (coverAnimateTimer)
             return;
         
         coverAnimateTimer = [[NSTimer scheduledTimerWithTimeInterval:1.5/94.0
                                                                  target:self
                                                                selector:@selector(coverOpenAnimate)
                                                                userInfo:nil
                                                                 repeats:YES]retain];
     }];
    
    
}

-(void)coverOpenAnimate
{
    if (coverAngle >= 94.0)
    {
        [coverAnimateTimer invalidate];
        [coverAnimateTimer release];
        coverAnimateTimer = nil;
    }
    else
    {
        coverAngle += 1.0;
        if (coverAngle >= 90)
        {
            imageViewCover.highlighted = YES;
            //imageViewCover.layer.anchorPoint = CGPointMake(0.0, 0.5);
            //imageViewCover.layer.position = CGPointMake(39+20.0, 287/2+imageViewCover.frame.origin.y);
        }
        else
        {
            imageViewCover.highlighted = NO;
            //imageViewCover.layer.anchorPoint = CGPointMake(0.0, 0.5);
            //imageViewCover.layer.position = CGPointMake(37+20.0, 287/2+imageViewCover.frame.origin.y);
        }
        
        imageViewCover.layer.transform = CATransform3DMakeRotation(M_PI / 180*coverAngle, 0, -1, 0);
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)dealloc
{
    [webViewContent release];
    [arrayData release];
    [imageViewCover release];
    [imageViewBottom release];
    [coverAnimateTimer release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
