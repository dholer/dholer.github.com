//
//  DiscoverStep4ViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-12.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"
#import "DiscoverStep4InfoViewController.h"
#import "MissionGalleryViewController.h"
#import "WebService.h"

@interface DiscoverStep4ViewController : CommonViewController<WebServiceDelegate>
{
    IBOutlet UITextView                 *textViewFirstDraft;
    IBOutlet UITextView                 *textViewRevised;
    IBOutlet UIButton                   *btnSave;
    IBOutlet UIButton                   *btnNext;
    
    DiscoverStep4InfoViewController     *infoViewController;
    
    
    IBOutlet UIView                     *viewSave;
}

-(IBAction)btnInfoClick:(id)sender;
-(IBAction)btnGalleryClick:(id)sender;
-(IBAction)btnSaveClick:(id)sender;
-(IBAction)btnNextClick:(id)sender;
-(IBAction)btnPreviousClick:(id)sender;

-(IBAction)btnSaveAndPostClick:(id)sender;
-(IBAction)btnSaveNoPostClick:(id)sender;
-(IBAction)btnCloseSaveViewClick:(id)sender;

@end
