//
//  ThreeInOneStep2ViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-3.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"

@interface ThreeInOneStep2ViewController : CommonViewController
{
    
    IBOutlet UIWebView              *webViewContent;
    
    NSArray                         *arrayData;
    
}

@property(nonatomic, retain)NSArray *arrayData;

-(IBAction)btnFinishClick:(id)sender;

@end
