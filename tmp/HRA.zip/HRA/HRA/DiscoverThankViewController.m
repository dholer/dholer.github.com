//
//  DiscoverThankViewController.m
//  HRA
//
//  Created by zhugang on 12-2-28.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "DiscoverThankViewController.h"
#import "AppDelegate.h"

@interface DiscoverThankViewController ()

@end

@implementation DiscoverThankViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(IBAction)btnHomeClick:(id)sender
{
    [((AppDelegate*)[UIApplication sharedApplication].delegate) showStartView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
