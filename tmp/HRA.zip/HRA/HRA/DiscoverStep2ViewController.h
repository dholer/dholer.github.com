//
//  DiscoverStep2ViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"
#import "DiscoverStep2InfoViewController.h"
#import "HappyHundredthStep1ViewController.h"
#import "ThreeInOneStep1ViewController.h"
#import "DiscoverStep3ViewController.h"
#import "SuperpowerMarketViewController.h"

@interface DiscoverStep2ViewController : CommonViewController
{
    NSArray                             *arrayActivities;
    IBOutlet UITableView                *tableViewItem;
    
    IBOutlet UIButton                   *btnNext;
    
    DiscoverStep2InfoViewController     *infoViewController;
    
}

-(IBAction)btnInfoClick:(id)sender;
-(IBAction)btnNextClick:(id)sender;

@end
