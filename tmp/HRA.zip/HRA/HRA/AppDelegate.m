//
//  AppDelegate.m
//  HRA
//
//  Created by Zhu Gang on 12-1-17.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>

@implementation AppDelegate

@synthesize window = _window;

- (void)dealloc
{
    [_window release];
    [mainViewController release];
    [navController release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSArray* languages = [prefs objectForKey:@"AppleLanguages"];
    NSString* currentLanguage = [languages objectAtIndex:0];
    NSLog(@"System:%@", currentLanguage);
    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    mainViewController = [[MainViewController alloc]init];
    navController = [[UINavigationController alloc]initWithRootViewController:mainViewController];
    [self.window addSubview:navController.view];
    
    [self.window makeKeyAndVisible];
    
    return YES;
}

-(void)showStartView
{
    [mainViewController showGuideView];
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}


-(void)showLoadingView
{
    NSLog(@"showLoadingView  *************");
    UIView *viewLoading = (UIView*)[navController.view viewWithTag:9998889];
    if (viewLoading == nil)
        viewLoading = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 480)];
    viewLoading.backgroundColor = [UIColor clearColor];
    viewLoading.tag = 9998889;
    viewLoading.alpha = 0.0;
    {
        UIView *viewBK = [[UIView alloc]initWithFrame:CGRectMake((320-140)/2, (480-90)/2, 140, 90)];
        viewBK.backgroundColor = [UIColor blackColor];
        viewBK.alpha = 0.65;
        [viewLoading addSubview:viewBK];
        [viewBK.layer setCornerRadius:10];
		[viewBK.layer setMasksToBounds:YES];
        
        [viewBK release];                                                        
        
        UIActivityIndicatorView *statusView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        statusView.center = CGPointMake(160, 240);
        [statusView startAnimating];
        [viewLoading addSubview:statusView];
        [statusView release];
    }
    
    
    [navController.view addSubview:viewLoading];
    
    [UIView animateWithDuration:0.5 animations:^{
        viewLoading.alpha = 1.0;
    } completion:^(BOOL finished)
	 {
		 
	 }];
}

-(void)hideLoadingView
{
    NSLog(@"hideLoadingView  *************");
    UIView *viewLoading = (UIView*)[navController.view viewWithTag:9998889];
    if (viewLoading)
    {
        [UIView animateWithDuration:0.5 animations:^{
            viewLoading.alpha = 0.0;
        } completion:^(BOOL finished)
         {
             [viewLoading removeFromSuperview]; 
         }];
    }
}


@end
