//
//  HomeViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-1.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HomeGetStartViewController.h"
#import "DiscoverStep1ViewController.h"
#import "DiscoverDoneInfoViewController.h"

@interface HomeViewController : UIViewController
{
    HomeGetStartViewController      *startViewController;
    
    IBOutlet UITableView            *tableViewItem;
    
    NSIndexPath                     *indexPathSelect;
    
    DiscoverDoneInfoViewController  *discoverDoneInfoViewController;
    
}

-(IBAction)btnInfoClick:(id)sender;

-(void)showDiscoverDoneInfo;

@end
