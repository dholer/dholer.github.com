//
//  FeedbackViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-12.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"

@interface FeedbackViewController : CommonViewController<UITextFieldDelegate>
{
    IBOutlet UIView         *viewHeader;
    IBOutlet UITableView    *tableViewContent;
    IBOutlet UIView         *viewFooter;
    
    CGRect                  rcSave;
    
    NSMutableArray          *arrayItem;
    
    UITextField             *currentTextField;
    
    UIWebView               *webView;
}

-(IBAction)btnSendEmailClick:(id)sender;
-(IBAction)btnNextClick:(id)sender;
-(IBAction)btnBackExClick:(id)sender;



@end
