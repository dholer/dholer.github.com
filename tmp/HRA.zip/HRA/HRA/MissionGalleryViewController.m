//
//  MissionGalleryViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "MissionGalleryViewController.h"

@implementation MissionGalleryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    arrayMission = [[DataMgr getMissionGallery]retain];

    [self btnInfoClick:nil];
}

-(IBAction)btnInfoClick:(id)sender
{
    if (infoViewController == nil)
        infoViewController = [[MissionGalleryInfoViewController alloc]initWithNibName:@"MissionGalleryInfoViewController" bundle:nil];
    infoViewController.view.alpha = 0.0;
    
    [self.view addSubview:infoViewController.view];
    [UIView animateWithDuration:0.8 animations:^{
        infoViewController.view.alpha = 1.0;
    } completion:^(BOOL finished)
     {
         
     }];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)dealloc
{
    [arrayMission release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return [arrayMission count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	UITableViewCell *cell = nil;
    
    static NSString *FirstLevelCell= @"MissionCell";
    cell = [tableView dequeueReusableCellWithIdentifier: 
            FirstLevelCell];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                       reuseIdentifier: FirstLevelCell] autorelease];
        
        UIImageView *imageAvator = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 70, 70)];
        imageAvator.tag = 10;
        imageAvator.contentMode = UIViewContentModeScaleAspectFit;
        imageAvator.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:imageAvator];
        [imageAvator release];
        
        /*UILabel *labelInfo = [[UILabel alloc]initWithFrame:CGRectMake(75, 0, 245, 70)];
        labelInfo.tag = 11;
        labelInfo.font = [UIFont italicSystemFontOfSize:16];
        labelInfo.textAlignment = UITextAlignmentLeft;
        labelInfo.backgroundColor = [UIColor clearColor];
        labelInfo.numberOfLines = 5;
        labelInfo.highlightedTextColor = [UIColor whiteColor];
        labelInfo.textColor = RGBColor(83, 83, 83);
        [cell.contentView addSubview:labelInfo];
        [labelInfo release];*/
        
        UIWebView *webInfo = [[UIWebView alloc]initWithFrame:CGRectMake(70, 0, 250, 70)];
        webInfo.tag = 11;
        webInfo.opaque = NO;
        webInfo.userInteractionEnabled = NO;
        webInfo.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:webInfo];
        [webInfo release];
    }
    
    UIImageView *imageAvator = (UIImageView*)[cell.contentView viewWithTag:10];
   // UILabel *labelInfo = (UILabel*)[cell.contentView viewWithTag:11];
    UIWebView *webInfo = (UIWebView*)[cell.contentView viewWithTag:11];
    
    NSInteger row = [indexPath row];
    
    NSDictionary *dictItem = [arrayMission objectAtIndex:row];
    imageAvator.image = [UIImage imageNamed:[dictItem objectForKey:@"Avator"]];
                            
    NSString *strContent = [NSString stringWithFormat:@"<div style='font-size:16px;color:0x464646'>\"%@\" <i>%@, %@<i></div>", [dictItem objectForKey:@"Words"], [dictItem objectForKey:@"Name"], [dictItem objectForKey:@"Age"]];

    NSString *strHTML = [NSString stringWithFormat:@"<head><style>body{font-family:Helvetica;}</style></head><meta name=\"viewport\" content=\"width=250, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=yes\"/>%@", strContent];
	[webInfo loadHTMLString:strHTML baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

@end
