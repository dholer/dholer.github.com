//
//  DiscoverStep2ViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "DiscoverStep2ViewController.h"
#import "ValueToolViewController.h"

@implementation DiscoverStep2ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    arrayActivities = [[DataMgr getActivities]retain];
    
    [self btnInfoClick:nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [tableViewItem reloadData];
    
    int count = 0;
    if ([DataMgr hasHappyHundredthData])
        count += 1;
    
    if ([DataMgr hasThreeInOneData])
        count += 1;
    
    if ([DataMgr hasSuperpowerData])
        count += 1;
    
    btnNext.enabled = count >= 3;
}

-(IBAction)btnInfoClick:(id)sender
{
    if (infoViewController == nil)
        infoViewController = [[DiscoverStep2InfoViewController alloc]initWithNibName:@"DiscoverStep2InfoViewController" bundle:nil];
    infoViewController.view.alpha = 0.0;
    
    [self.view addSubview:infoViewController.view];
    [UIView animateWithDuration:0.8 animations:^{
        infoViewController.view.alpha = 1.0;
    } completion:^(BOOL finished)
     {
         
     }];
}

-(IBAction)btnNextClick:(id)sender
{
    /*DiscoverStep3ViewController *viewController = [[[DiscoverStep3ViewController alloc]initWithNibName:@"DiscoverStep3ViewController" bundle:nil]autorelease];
    viewController.homeViewController = self.homeViewController;
    [self.navigationController pushViewController:viewController animated:YES];*/
    
    ValueToolViewController *viewController = [[[ValueToolViewController alloc]initWithNibName:@"ValueToolViewController" bundle:nil]autorelease];
    viewController.homeViewController = self;
    viewController.backViewController = self.homeViewController;
    [viewController setType:kTypeCoreValues];
    [self.navigationController pushViewController:viewController animated:YES];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)dealloc
{
    [arrayActivities release];
    [tableViewItem release];
    [btnNext release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)btnClickActivities:(UIButton*)btn
{
    UIViewController *viewController = nil;
    if (btn.tag == 10)
    {
        HappyHundredthStep1ViewController *viewControllerTmp = [[[HappyHundredthStep1ViewController alloc]initWithNibName:@"HappyHundredthStep1ViewController" bundle:nil]autorelease];
        
        viewControllerTmp.homeViewController = self;
        viewController = viewControllerTmp;
    }
    else if (btn.tag == 11)
    {
        SuperpowerMarketViewController *viewControllerTmp = [[[SuperpowerMarketViewController alloc]initWithNibName:@"SuperpowerMarketViewController" bundle:nil]autorelease];
        
        viewControllerTmp.homeViewController = self;
        viewController = viewControllerTmp;
    }
    else if (btn.tag == 12)
    {
        
    }
    else if (btn.tag == 20)
    {
        ThreeInOneStep1ViewController *viewControllerTmp = [[[ThreeInOneStep1ViewController alloc]initWithNibName:@"ThreeInOneStep1ViewController" bundle:nil]autorelease];
        
        viewControllerTmp.homeViewController = self;
        viewController = viewControllerTmp;
    }
    else if (btn.tag == 21)
    {
        
    }
    else if (btn.tag == 22)
    {
        
    }
    else if (btn.tag == 30)
    {
        
    }
    else if (btn.tag == 31)
    {
        
    }
    else if (btn.tag == 32)
    {
        
    }
    
    if (viewController)
        [self.navigationController pushViewController:viewController animated:YES];
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    int count = [arrayActivities count];
    
    return count/3 + (count%3 == 0 ? 0: 1);

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 105.0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	UITableViewCell *cell = nil;
    
    NSInteger row = [indexPath row];
    
    static NSString *FirstLevelCell= @"ActivityCell";
    cell = [tableView dequeueReusableCellWithIdentifier: 
            FirstLevelCell];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                       reuseIdentifier: FirstLevelCell] autorelease];
        
        float spin = (320 - 3*90)/4.0;
        
        for(int i=0; i<3; i++)
        {
            UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(spin+(90+spin)*i, 0, 90, 110)];
            btn.tag = 10*(row+1)+i;
            
            UIImageView *imageAvator = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 90, 70)];
            imageAvator.tag = 100;
            imageAvator.contentMode = UIViewContentModeCenter;
            imageAvator.backgroundColor = [UIColor clearColor];
            [btn addSubview:imageAvator];
            [imageAvator release];
            
            UILabel *labelInfo = [[UILabel alloc]initWithFrame:CGRectMake(0, 68, 90, 35)];
            labelInfo.tag = 200;
            labelInfo.font = [UIFont boldSystemFontOfSize:14];
            labelInfo.textAlignment = UITextAlignmentCenter;
            labelInfo.backgroundColor = [UIColor clearColor];
            labelInfo.shadowOffset = CGSizeMake(0, 1);
            labelInfo.shadowColor = [UIColor whiteColor];
            labelInfo.numberOfLines = 2;
            labelInfo.highlightedTextColor = [UIColor whiteColor];
            labelInfo.textColor = RGBColor(70, 70, 70);
            [btn addSubview:labelInfo];
            [labelInfo release];
            
            [btn addTarget:self action:@selector(btnClickActivities:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:btn];
            [btn release];
        }
        
    }

    for(int i=0; i<3; i++)
    {
        UIButton *btn = (UIButton*)[cell.contentView viewWithTag:10*(row+1)+i];
        UIImageView *imageAvator = (UIImageView*)[btn viewWithTag:100];
        UILabel *labelInfo = (UILabel*)[btn viewWithTag:200];
        
        int index = row * 3 + i;
        
        if (index >= [arrayActivities count])
            break;
        
        NSDictionary *dictItem = [arrayActivities objectAtIndex:index];
        
        NSString *imageIcon = @"sign-questions.png";
        if (index == 0)
        {
            if([DataMgr hasHappyHundredthData])
                imageIcon = @"sign-cake.png";
        }
        else if (index == 1)
        {
            if([DataMgr hasSuperpowerData])
            {
                NSMutableDictionary *dictData = [DataMgr readSuperPowerData];
                int index = [[dictData objectForKey:@"PowerIndex"]intValue];
                NSArray *arrayData = [DataMgr getPlistData:@"Superpower.plist"];
                NSDictionary *dictItem = [arrayData objectAtIndex:index-1];
                imageIcon = [dictItem objectForKey:@"Icon"];
            }
        }
        else if (index == 2)
        {
            
        }
        else if (index == 3)
        {
            if ([DataMgr hasThreeInOneData])
                imageIcon = @"sign-dots.png";
        }
        else if (index == 4)
        {
            
        }
        else if (index == 5)
        {
            
        }
        else if (index == 6)
        {
            
        }
        else if (index == 7)
        {
            
        }
        else if (index == 8)
        {
            
        }
        
        
        imageAvator.image = [UIImage imageNamed:imageIcon];
        
        labelInfo.text = [dictItem objectForKey:@"Name"];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

@end
