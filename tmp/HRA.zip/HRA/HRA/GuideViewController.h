//
//  GuideViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-1-19.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainViewController;

@interface GuideViewController : UIViewController
{
    IBOutlet UIView          *guideView1;
    IBOutlet UIView          *guideView2;
    IBOutlet UIView          *guideView3;
    
    
    MainViewController       *parent;
}

@property(nonatomic, retain)MainViewController *parent;

-(IBAction)btnPreviousClick:(UIButton*)btn;
-(IBAction)btnNextClick:(UIButton*)btn;

@end
