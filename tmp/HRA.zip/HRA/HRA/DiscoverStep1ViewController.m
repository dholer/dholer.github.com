//
//  DiscoverStep1ViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "DiscoverStep1ViewController.h"

@implementation DiscoverStep1ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillShow) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(keyboardWillHide) name:UIKeyboardWillHideNotification object:nil];
    
    
    NSString *firstDraft = [DataMgr readMissionFirstDraft];
    if ([firstDraft length]>0)
    {
        textViewInfo.text = firstDraft;
        btnSave.enabled = NO;
        [btnSave setTitle:@"Saved" forState:UIControlStateNormal];
        [btnSave setTitle:@"Saved" forState:UIControlStateHighlighted];
        btnNext.enabled = YES;
    }
    
    [self btnInfoClick:nil];
}

- (void) keyboardWillShow
{
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.6];
    self.view.transform = CGAffineTransformMakeTranslation(0, -165);
	[UIView commitAnimations];
    
    btnNext.enabled = NO;
    btnSave.enabled = YES;
    [btnSave setTitle:@"Done!" forState:UIControlStateNormal];
    [btnSave setTitle:@"Done!" forState:UIControlStateHighlighted];
    
}

- (void) keyboardWillHide
{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	self.view.transform = CGAffineTransformMakeTranslation(0, 0);
	[UIView commitAnimations];
    
    if ([textViewInfo.text length] > 0)
    {
        [btnSave setTitle:@"Save" forState:UIControlStateNormal];
        [btnSave setTitle:@"Save" forState:UIControlStateHighlighted];
    }
    else
    {
        [btnSave setTitle:@"Done!" forState:UIControlStateNormal];
        [btnSave setTitle:@"Done!" forState:UIControlStateHighlighted];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillShowNotification
												  object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillHideNotification
												  object:nil];
    
    [textViewInfo release];
    [btnSave release];
    [btnNext release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)btnInfoClick:(id)sender
{
    if (infoViewController == nil)
        infoViewController = [[DiscoverStep1InfoViewController alloc]initWithNibName:@"DiscoverStep1InfoViewController" bundle:nil];
    infoViewController.view.alpha = 0.0;
    
    [self.view addSubview:infoViewController.view];
    [UIView animateWithDuration:0.8 animations:^{
        infoViewController.view.alpha = 1.0;
    } completion:^(BOOL finished)
     {
         
     }];
}

-(IBAction)btnGalleryClick:(id)sender
{
    [textViewInfo resignFirstResponder];
    
    MissionGalleryViewController *galleryViewController = [[[MissionGalleryViewController alloc]initWithNibName:@"MissionGalleryViewController" bundle:nil]autorelease];
    [self.navigationController pushViewController:galleryViewController animated:YES];
    
}

-(IBAction)btnSaveClick:(id)sender
{
    if ([textViewInfo isFirstResponder])
    {
        [textViewInfo resignFirstResponder];
    }
    else
    {
        if ([textViewInfo.text length] <= 0)
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil 
                                                            message:@"Please try to write your first draft" 
                                                           delegate:nil cancelButtonTitle:@"Dismiss" 
                                                  otherButtonTitles:nil];
            [alert show];
            [alert release];
            return;
        }
        else
        {
            btnSave.enabled = NO;
            [btnSave setTitle:@"Saved" forState:UIControlStateNormal];
            [btnSave setTitle:@"Saved" forState:UIControlStateHighlighted];
            btnNext.enabled = YES;
            
            [DataMgr saveMissionFirstDraft:textViewInfo.text];
            
        }
    }
}

-(IBAction)btnNextClick:(id)sender
{
    DiscoverStep2ViewController *viewController = [[[DiscoverStep2ViewController alloc]initWithNibName:@"DiscoverStep2ViewController" bundle:nil]autorelease];
    viewController.homeViewController = self.homeViewController;
    [self.navigationController pushViewController:viewController animated:YES];
}

@end
