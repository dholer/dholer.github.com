//
//  SuperpowerMarketViewController.m
//  HRA
//
//  Created by Zhu Gang on 12-2-18.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import "SuperpowerMarketViewController.h"


@implementation SuperpowerMarketViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    arrayPowerImage = [[NSArray alloc]initWithObjects:@"midbtn-supersmarts.png", 
    @"midbtn-superbeauty.png", 
    @"midbtn-superdiplomacy.png", 
    @"midbtn-superspeed.png", 
    @"midbtn-superhumor.png", 
    @"midbtn-superstrength.png", 
    @"midbtn-supervision.png", nil];
    
    if ([DataMgr hasSuperpowerData])
    {
        NSMutableDictionary *dictData = [DataMgr readSuperPowerData];
        int index = [[dictData objectForKey:@"PowerIndex"]intValue];
        [self showSuperpower:index];
    }
    else
    {
        [self showSuperpower:1];
    }
}

-(void)showSuperpower:(int)index
{
    powerIndex = index;
    [UIView animateWithDuration:0.35 animations:^{
        for(int i= 1; i<=7; i++)
        {
            UIImageView *imageView = (UIImageView*)[self.view viewWithTag:i+100];
            UIButton *btn = (UIButton*)[self.view viewWithTag:i+200];
            if (i == index)
            {
                //imageView.hidden = NO;
                //btn.hidden = YES;
                imageView.alpha = 1.0;
                btn.alpha = 0.0;
            }
            else
            {
                //imageView.hidden = YES;
                //btn.hidden = NO;
                imageView.alpha = 0.0;
                btn.alpha = 1.0;
            }
        }
        
        UIImageView *imageViewCenter = (UIImageView*)[self.view viewWithTag:500];
        imageViewCenter.image = [UIImage imageNamed:[arrayPowerImage objectAtIndex:index-1]];

    } completion:^(BOOL finished)
     {
         for(int i= 1; i<=7; i++)
         {
             UIImageView *imageView = (UIImageView*)[self.view viewWithTag:i+100];
             UIButton *btn = (UIButton*)[self.view viewWithTag:i+200];
             if (i == index)
             {
                 imageView.hidden = NO;
                 btn.hidden = YES;
                 
                 
             }
             else
             {
                 imageView.hidden = YES;
                 btn.hidden = NO;
             }
         }
     }];
    }

-(IBAction)btnPowerClick:(UIButton*)btn
{
    [self showSuperpower:btn.tag - 200];
}

-(IBAction)btnFinishPower:(id)sender
{
    SuperpowerItemViewController *viewController = [[[SuperpowerItemViewController alloc]initWithNibName:@"SuperpowerItemViewController" bundle:nil]autorelease];
    
    viewController.homeViewController = self.homeViewController;
    [self.navigationController pushViewController:viewController animated:YES];
    [viewController setPower:powerIndex];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [arrayPowerImage release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
