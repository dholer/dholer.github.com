//
//  HomeGetStartViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-1.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeGetStartViewController : UIViewController
{
    
}

-(IBAction)btnCloseClick:(id)sender;

@end
