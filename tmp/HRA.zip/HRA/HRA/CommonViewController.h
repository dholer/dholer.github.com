//
//  CommonViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface CommonViewController : UIViewController
{
    UIViewController *homeViewController;
    UIViewController *backViewController;
}

@property(nonatomic, retain)UIViewController *homeViewController;
@property(nonatomic, retain)UIViewController *backViewController;

-(IBAction)btnBackClick:(id)sender;
-(IBAction)btnRootClick:(id)sender;

@end
