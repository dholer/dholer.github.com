//
//  HappyHundredthStep2ViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"


@interface HappyHundredthStep2ViewController : CommonViewController
{
    IBOutlet UIWebView              *webViewContent;
    
    NSArray                         *arrayData;
    
    IBOutlet UIImageView            *imageViewCover;
    
    float                           coverAngle;
    
    IBOutlet UIImageView            *imageViewBottom;
    
    NSTimer                         *coverAnimateTimer;
}

@property(nonatomic, retain)NSArray *arrayData;

-(IBAction)btnFinishClick:(id)sender;
-(IBAction)btnCoverClick:(id)sender;

@end
