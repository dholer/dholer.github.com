//
//  DiscoverStep1ViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-2.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"
#import "DiscoverStep1InfoViewController.h"
#import "MissionGalleryViewController.h"
#import "DiscoverStep2ViewController.h"

@interface DiscoverStep1ViewController : CommonViewController
{
    IBOutlet UITextView                 *textViewInfo;
    IBOutlet UIButton                   *btnSave;
    IBOutlet UIButton                   *btnNext;
    
    DiscoverStep1InfoViewController     *infoViewController;
    
    
}

-(IBAction)btnInfoClick:(id)sender;
-(IBAction)btnGalleryClick:(id)sender;
-(IBAction)btnSaveClick:(id)sender;
-(IBAction)btnNextClick:(id)sender;

@end
