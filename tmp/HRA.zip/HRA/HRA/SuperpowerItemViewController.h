//
//  SuperpowerItemViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-18.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonViewController.h"

@interface SuperpowerItemViewController : CommonViewController
{
    int         powerIndex;
    
    IBOutlet UILabel        *labelTitle;
    IBOutlet UILabel        *labelInfo;
    IBOutlet UITextField    *textFieldData;
    IBOutlet UIImageView    *imageViewPower;
    
}

-(void)setPower:(int)index;
-(IBAction)btnFinishClick:(id)sender;
-(IBAction)hideKeyPad:(id)sender;

@end
