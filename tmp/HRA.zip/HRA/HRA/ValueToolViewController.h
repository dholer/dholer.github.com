//
//  CoreValuesViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-11.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CommonViewController.h"
#import "ValueToolInfoViewController.h"
#import "VisualizeViewController.h"

@interface ValueToolViewController : CommonViewController
{
    IBOutlet UIButton           *btnVisualize;
    IBOutlet UITableView        *tableViewContent;
    NSMutableArray              *arrayItem;
    
    ValueToolInfoViewController    *infoViewController;
    
    int             type;
    
    UIImageView                 *imageViewInfo;
}

-(void)setType:(int)toolType;

-(IBAction)btnVisualizeClick:(id)sender;
-(IBAction)btnInfoClick:(id)sender;

@end
