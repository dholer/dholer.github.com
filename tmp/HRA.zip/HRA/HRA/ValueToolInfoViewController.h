//
//  ValueToolInfoViewController.h
//  HRA
//
//  Created by Zhu Gang on 12-2-11.
//  Copyright (c) 2012年 LogicSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ValueToolInfoViewController : UIViewController
{
    int             type;
}

-(void)setType:(int)toolType;
-(IBAction)btnCloseClick:(id)sender;

@end
