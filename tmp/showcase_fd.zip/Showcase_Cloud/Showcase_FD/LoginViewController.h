//
//  LoginViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 3/28/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LoginViewControllerDelegate <NSObject>

- (void)loginViewControllerDismissBackgroundViews;

@end

@interface LoginViewController : UIViewController 

@property (nonatomic) BOOL online;

@property (nonatomic, assign) id <LoginViewControllerDelegate> delegate;

@end
