//
//  ZoneEntity.m
//  Showcase_FD
//
//  Created by Yue Gu on 12-4-3.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "ZoneEntity.h"

@implementation ZoneEntity

@synthesize zoneID = _zoneID;
@synthesize name = _name;
@synthesize cityID = _cityID;

- (void)dealloc
{
    [_zoneID release];
    [_name release];
    [_cityID release];
    [super dealloc];
}

@end
