//
//  ProductListViewController.h
//  Showcase_FD
//
//  Created by august on 12-3-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMainMenuViewController.h"
#import "MainProductView.h"
@interface ProductListViewController : UIViewController<FMainMenuViewControllerDelegate,MainProductViewDelegate>{
    @private
    FMainMenuViewController *mainMenuView;
    MainProductView *mainProductView;
    NSMutableArray *all_group_array;
}
@property (nonatomic, retain) NSMutableArray *all_group_array;
@end
