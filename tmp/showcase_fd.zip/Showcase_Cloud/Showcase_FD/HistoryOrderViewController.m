//
//  HistoryOrderViewController.m
//  Showcase_FD
//
//  Created by Yue Gu on 4/6/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import "HistoryOrderViewController.h"

#import "DataManagerModel.h"

#define SUBVIEWTAGBASE 1000000000

@interface HistoryOrderViewController () <UITableViewDelegate, UITableViewDataSource>

@property (retain, nonatomic) IBOutlet UITextField *searchTextField;
@property (retain, nonatomic) IBOutlet UIButton *editButton;

@property (retain, nonatomic) NSArray * historyOrders;

@property (nonatomic) BOOL isEditing;

@end

@implementation HistoryOrderViewController

@synthesize searchTextField;
@synthesize editButton = _editButton;
@synthesize historyOrderTableView;

@synthesize historyOrders = _historyOrders;

@synthesize isEditing = _isEditing;

@synthesize delegate = _delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (NSArray *)historyOrders
{
    [_historyOrders release];
    _historyOrders = [[[DataManagerModel sharedDataModel] getOrderEntitiesFilteredBySearchString:[[self searchTextField] text]] mutableCopy];
    return _historyOrders;
}

#pragma mark - GUI interactions

- (void)orderDeleteButtonPressed:(id)sender
{
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"消息"
                                                     message:@"确定要删除当前订单么？" 
                                                    delegate:self
                                           cancelButtonTitle:@"确定"
                                           otherButtonTitles:@"取消", nil] autorelease];
    [alert setTag:[sender tag] - SUBVIEWTAGBASE];
    [alert show];
}

- (void)showOrHiddenDelBtn:(BOOL)flag{
    for (int i = 0; i < [[self historyOrders] count]; i++) {
        UIView *cell = [self.historyOrderTableView viewWithTag:i+SUBVIEWTAGBASE];
        [cell setHidden:flag];
    }
}

- (IBAction)editButtonPressed:(id)sender 
{
    if (self.isEditing = !self.isEditing) {
        [[self editButton] setTitle:@"完成" forState:UIControlStateNormal];
        [self showOrHiddenDelBtn:NO];
    } else {
        [[self editButton] setTitle:@"编辑" forState:UIControlStateNormal];
        [self showOrHiddenDelBtn:YES];
    }
}

- (IBAction)hideButtonPressed:(id)sender 
{
    [UIView animateWithDuration:0.3 animations:^{
        [[self view] setHidden:YES];
    }];
}

- (IBAction)searchTextFieldEditingChanged:(id)sender 
{
    [self setHistoryOrders:[[DataManagerModel sharedDataModel] getOrderEntitiesFilteredBySearchString:[[self searchTextField] text]]];
    [[self historyOrderTableView] reloadData];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    // delete the current cell data
    if (0 == buttonIndex) {
        [[DataManagerModel sharedDataModel] removeOrderEntity:[[self historyOrders] objectAtIndex:[alertView tag]]];
        [[self historyOrderTableView] reloadData];
    }
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[self delegate] didSelectOrder:[[self historyOrders] objectAtIndex:[indexPath row]]];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self historyOrders] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CellIdentifier";
    
    UITableViewCell *cell = nil; //[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell)
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    FDOrderEntity *orderEntity = [[self historyOrders] objectAtIndex:[indexPath row]];
    
    //0. delete button
    {
        UIButton *delBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        delBtn.tag = SUBVIEWTAGBASE + [indexPath row];
        delBtn.frame = CGRectMake(3.0, 15.0, 20, 21.0);
        [delBtn setImage:[UIImage imageNamed:@"icon-delet.png"] forState:UIControlStateNormal];
        [delBtn addTarget:self action:@selector(orderDeleteButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        [cell.contentView addSubview:delBtn];
        delBtn.hidden = ![self isEditing];
    }
    //1、客户姓名
    {
        UILabel *Label1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 16, 90, 30)]; 
        Label1.textColor = [UIColor blackColor];
        Label1.text = [orderEntity customer];
        Label1.backgroundColor = [UIColor clearColor];
        Label1.font = [UIFont boldSystemFontOfSize:18];
        Label1.textAlignment = UITextAlignmentCenter;
        [cell.contentView addSubview:Label1];
        [Label1 release];
    }
    
    //2、联系电话
    {
        UILabel *Label2 = [[UILabel alloc] initWithFrame:CGRectMake(90, 16, 116, 30)]; 
        Label2.textColor = [UIColor blackColor];
        Label2.text = [orderEntity cellPhone];
        Label2.backgroundColor = [UIColor clearColor];
        Label2.font = [UIFont systemFontOfSize:14];
        Label2.textAlignment = UITextAlignmentCenter;
        [cell.contentView addSubview:Label2];
        [Label2 release];
    }
    
    //3、日期
    {
        UILabel *Label3 = [[UILabel alloc] initWithFrame:CGRectMake(196, 16, 116, 30)]; 
        Label3.textColor = [UIColor blackColor];
        NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"YYYY-MM-dd"];            
        NSString* str = [formatter stringFromDate:[orderEntity deliveringDate]];
        [formatter release];
        Label3.text =str;
        Label3.backgroundColor = [UIColor clearColor];
        Label3.font = [UIFont systemFontOfSize:14];
        Label3.textAlignment = UITextAlignmentCenter;
        [cell.contentView addSubview:Label3];
        [Label3 release];
    }

    return cell;
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setHistoryOrders:[[DataManagerModel sharedDataModel] getOrderEntitiesFilteredBySearchString:nil]];
}

- (void)viewDidUnload
{
    [self setSearchTextField:nil];
    [self setHistoryOrderTableView:nil];
    
    [self setEditButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (void)dealloc 
{
    [searchTextField release];
    [historyOrderTableView release];
    
    [_historyOrders release];
    
    [_editButton release];
    [super dealloc];
}

@end
