//
//  HistoryOrderViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 4/6/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FDOrderEntity;

@protocol HistoryOrderViewControllerDelegate <NSObject>

- (void)didSelectOrder:(FDOrderEntity *)order;

@end

@interface HistoryOrderViewController : UIViewController

@property (assign, nonatomic) id <HistoryOrderViewControllerDelegate> delegate;
@property (retain, nonatomic) IBOutlet UITableView *historyOrderTableView;

@end
