//
//  SingleProductView.h
//  Showcase_FD
//
//  Created by august on 12-3-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FDProductEntity;

@protocol SingleProductViewDelegate <NSObject>
@optional
- (void)didSelectedSingleProduct:(FDProductEntity *)selectedProduct;

@end

@interface SingleProductView : UIView{
    IBOutlet UIImageView *imageview;
    IBOutlet UILabel *titleLabel;
    IBOutlet UIButton *shopCartBtn;
    IBOutlet UILabel *skuLabel;
    IBOutlet UILabel *priceLabel;
    BOOL isclick;
    FDProductEntity *currentProduct;
    id<SingleProductViewDelegate> delegate;
}
@property (nonatomic,retain) FDProductEntity *currentProduct;
@property (nonatomic,retain) id<SingleProductViewDelegate> delegate;
- (id)initWithFrame:(CGRect)frame withProductEntity:(FDProductEntity *)productEntity;
@end
