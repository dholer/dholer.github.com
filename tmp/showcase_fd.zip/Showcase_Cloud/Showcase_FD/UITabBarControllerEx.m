//
//  UITabBarControllerEx.m
//  Mauijim
//
//  Created by leo on 11-9-19.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "UITabBarControllerEx.h"
#import "QuickOrderViewController.h"
#import "ProductListViewController.h"
#import "ProductCaseViewController.h"
#import "OrdersViewController.h"
#import "NewsViewController.h"
#import "SyncViewController.h"
#import "Constants.h"
#import "HomeViewController.h"
#import "UIImage+Resize.h"

#define SCALE 70.0
#define BUTTON_WIDTH 70.f
#define BUTTON_HEIGHT 58.f
#define BUTTON_TOPGAP 5.f
#define BUTTON_SPACEGAP 40.f

@implementation UITabBarControllerEx

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}
#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    //Init view controllers

    QuickOrderViewController *quickOrder = [[QuickOrderViewController alloc] init]; 
//    UINavigationController *quickOrderController = [[UINavigationController alloc] initWithRootViewController:quickOrder];
    ProductListViewController *productlist = [[ProductListViewController alloc] init];
                           
    UINavigationController *navProductlistController = [[UINavigationController alloc] initWithRootViewController:productlist];
    
    ProductCaseViewController *cases = [[ProductCaseViewController alloc] init];
    UINavigationController *navCaseController = [[UINavigationController alloc] initWithRootViewController:cases];                                         
    
    OrdersViewController *orders = [[OrdersViewController alloc] 
                                        init];
    NewsViewController *news = [[NewsViewController alloc] init];
                                               
    SyncViewController *sync = [[SyncViewController alloc] 
                                initWithNibName:@"SyncViewController" 
                                bundle:nil];
    
    self.viewControllers = [NSArray arrayWithObjects:quickOrder,navProductlistController,navCaseController,orders,news,sync, nil];
    [quickOrder release];
    [productlist release];
    [cases release];
    [orders release];
    [news release];
    [sync release];
    [navProductlistController release];
    [navCaseController release];
    // Create the customized tab bar
    [self hideTabBar];

}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}


- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)dealloc {
	[super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}


#pragma mark ----
#pragma mark function
-(void)backToHomeView:(NSNotification *)noti {
    [self setSelectedIndex:0];
    
    //navigate to home page
    if ([self.parentViewController isKindOfClass:[UINavigationController class]]) {
        [(UINavigationController *)self.parentViewController popToRootViewControllerAnimated:YES];
    }
    
    // De-highlight the other buttons
    UIView *customTabbarview = [self.view viewWithTag:1001];
	UITabBarButtonEx *customerBtn = (UITabBarButtonEx *)[customTabbarview viewWithTag:2];
	UIButton *btn2 = (UIButton *)[customerBtn viewWithTag:2];
    UITabBarButtonEx *quickOrderBtn = (UITabBarButtonEx *)[customTabbarview viewWithTag:3];
	UIButton *btn3 = (UIButton *)[quickOrderBtn viewWithTag:3];
	UITabBarButtonEx *productBtn = (UITabBarButtonEx *)[customTabbarview viewWithTag:4];
	UIButton *btn4 = (UIButton *)[productBtn viewWithTag:4];
	UITabBarButtonEx *inventroyBtn = (UITabBarButtonEx *)[customTabbarview viewWithTag:5];
	UIButton *btn5 = (UIButton *)[inventroyBtn viewWithTag:5];
	UITabBarButtonEx *syncBtn = (UITabBarButtonEx *)[customTabbarview viewWithTag:6];
	UIButton *btn6 = (UIButton *)[syncBtn viewWithTag:6];
    
    [btn2 setSelected:NO];
    [btn3 setSelected:NO];
    [btn4 setSelected:NO];
    [btn5 setSelected:NO];
    [btn6 setSelected:NO];
    
}

- (void)removeCustomTabbarView{
    
    if ([self.view viewWithTag:1001]) {
        for (UIView *v in [self.view subviews]) {
            if ([v isKindOfClass:[UITabBar class]]) {
                [v setHidden:YES];
            }
            if (v.tag == 1001) {
                [v removeFromSuperview]; 
            }
        }
    }
}

- (void)showLandscapeView{
    
    UIImage *tabBarBGImage = [UIImage imageNamed:@"btmbar.png"];
    [self removeCustomTabbarView];
    
    UIView *customTabBarParentView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 768.0 - tabBarBGImage.size.height, 1024.0, tabBarBGImage.size.height)];
    
    //add bg image view
    UIImageView *bgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, 1024.0, tabBarBGImage.size.height)];
    bgImageView.image = tabBarBGImage;
    bgImageView.tag = 11103;
    [customTabBarParentView addSubview:bgImageView];
    [bgImageView release];
    
    UIButton *logoBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [logoBtn setFrame:CGRectMake(5, 8, 160, 49)];
    [logoBtn addTarget:self action:@selector(backToHomeView:) forControlEvents:UIControlEventTouchUpInside];
    [logoBtn setBackgroundImage:[UIImage imageNamed:@"btm-logo.png"] forState:UIControlStateNormal];
    logoBtn.tag = 10007;
    [customTabBarParentView addSubview:logoBtn];
    
    UITabBarButtonEx *quickOrderBtn = [[UITabBarButtonEx alloc] initWithFrame:CGRectMake(315.0, BUTTON_TOPGAP, BUTTON_WIDTH, BUTTON_HEIGHT)
                                                            normalImage:@"quote.png"
                                                         highLightImage:@"quote-on.png"
                                                                 target:self 
                                                                 action:@selector(tabBarBtnPressed:)
                                                                  title:Localized(@"快速报价")
                                                                    tag:1];
    quickOrderBtn.tag = 10001;
    [customTabBarParentView addSubview:quickOrderBtn];
    
	UITabBarButtonEx *productlistBtn = [[UITabBarButtonEx alloc] initWithFrame:CGRectMake(quickOrderBtn.frame.origin.x+BUTTON_SPACEGAP+BUTTON_WIDTH, BUTTON_TOPGAP, BUTTON_WIDTH, BUTTON_HEIGHT)
                                                               normalImage:@"product.png"
                                                            highLightImage:@"product-on.png"
                                                                    target:self 
                                                                    action:@selector(tabBarBtnPressed:)
                                                                     title:Localized(@"产品展示")
                                                                       tag:2];
    productlistBtn.tag = 10002;
    [customTabBarParentView addSubview:productlistBtn];
    
    UITabBarButtonEx *casesBtn = [[UITabBarButtonEx alloc] 
                                  initWithFrame:CGRectMake(productlistBtn.frame.origin.x+BUTTON_SPACEGAP+BUTTON_WIDTH, BUTTON_TOPGAP, BUTTON_WIDTH, BUTTON_HEIGHT)
                                                                normalImage:@"casestudies.png"
                                                             highLightImage:@"casestudies-on.png"
                                                                     target:self 
                                                                     action:@selector(tabBarBtnPressed:)
                                                                      title:Localized(@"产品展示")
                                                                        tag:3];
    casesBtn.tag = 10003;
    [customTabBarParentView addSubview:casesBtn];
	
	
    UITabBarButtonEx *orderBtn = [[UITabBarButtonEx alloc] 
                                  initWithFrame:CGRectMake(casesBtn.frame.origin.x+BUTTON_SPACEGAP+BUTTON_WIDTH, BUTTON_TOPGAP, BUTTON_WIDTH, BUTTON_HEIGHT)
                                                             normalImage:@"orderlist.png"
                                                          highLightImage:@"orderlist-on.png"
                                                                  target:self 
                                                                  action:@selector(tabBarBtnPressed:)
                                                                   title:Localized(@"我的订单")
                                                                     tag:4];
    orderBtn.tag = 10004;
    [customTabBarParentView addSubview:orderBtn];
   
	
    UITabBarButtonEx *newsBtn = [[UITabBarButtonEx alloc] 
                                 initWithFrame:CGRectMake(orderBtn.frame.origin.x+BUTTON_SPACEGAP+BUTTON_WIDTH, BUTTON_TOPGAP, BUTTON_WIDTH, BUTTON_HEIGHT)
                                                             normalImage:@"news.png"
                                                          highLightImage:@"news-on.png"
                                                                  target:self 
                                                                  action:@selector(tabBarBtnPressed:)
                                                                   title:Localized(@"最新通知")
                                                                     tag:5];
    newsBtn.tag = 10005;
    [customTabBarParentView addSubview:newsBtn];
    
    UITabBarButtonEx *syncBtn = [[UITabBarButtonEx alloc] 
                                 initWithFrame:CGRectMake(newsBtn.frame.origin.x+BUTTON_SPACEGAP+BUTTON_WIDTH, BUTTON_TOPGAP, BUTTON_WIDTH, BUTTON_HEIGHT)
                                                            normalImage:@"sync.png"
                                                         highLightImage:@"sync-on.png"
                                                                 target:self 
                                                                 action:@selector(tabBarBtnPressed:)
                                                                  title:Localized(@"资料更新")
                                                                    tag:6];
    syncBtn.tag = 10006;
    [customTabBarParentView addSubview:syncBtn];
    
	
    customTabBarParentView.tag = 1001;
    [self.view addSubview:customTabBarParentView];
    //release 
    [quickOrderBtn release];
    [productlistBtn release];
    [casesBtn release];
    [orderBtn release];
    [newsBtn release];
    [syncBtn release];
    [customTabBarParentView release];
}



- (void)hideTabBar{
    for (UIView *subView in self.view.subviews) 
    {
        if([subView isKindOfClass:[UITabBar class]])
        {
            subView.hidden = YES;
        }
        else
        {
   
            subView.frame = CGRectMake(0.0, 0.0, 768.0, 1024.0);             
        }
    }
    
    for (UIViewController *controller in self.viewControllers)
    {
        controller.view.frame = CGRectMake(0.0, 0.0, 768.0, 1024.0);

	}
   
    [self showLandscapeView];
    // Hide the Cart Btn
    
}

- (IBAction)tabBarBtnPressed:(id)sender
{
	UIButton *btn = (UIButton *)sender;

    UIView *customTabbarview = [self.view viewWithTag:1001];
   
    UITabBarButtonEx *tabButton_quickOrder = (UITabBarButtonEx *)[customTabbarview viewWithTag:10001];
    
	UIButton *btn1 = (UIButton *)[tabButton_quickOrder viewWithTag:1];
    
	UITabBarButtonEx *tabButton_product = (UITabBarButtonEx *)[customTabbarview viewWithTag:10002];
	UIButton *btn2 = (UIButton *)[tabButton_product viewWithTag:2];
    
    UITabBarButtonEx *tabButton_case = (UITabBarButtonEx *)[customTabbarview viewWithTag:10003];
	UIButton *btn3 = (UIButton *)[tabButton_case viewWithTag:3];
    
	UITabBarButtonEx *tabButton_order = (UITabBarButtonEx *)[customTabbarview viewWithTag:10004];
	UIButton *btn4 = (UIButton *)[tabButton_order viewWithTag:4];
    
	UITabBarButtonEx *tabButton_news = (UITabBarButtonEx *)[customTabbarview viewWithTag:10005];
	UIButton *btn5 = (UIButton *)[tabButton_news viewWithTag:5];
    
	UITabBarButtonEx *tabButton_sync = (UITabBarButtonEx *)[customTabbarview viewWithTag:10006];
	UIButton *btn6 = (UIButton *)[tabButton_sync viewWithTag:6];

//    UITabBarButtonEx *tabButton_home = (UITabBarButtonEx *)[customTabbarview viewWithTag:10007];
//	UIButton *btn7 = (UIButton *)[tabButton_home viewWithTag:7];
    
    [btn setSelected:YES];
    
	switch (btn.tag) {
		case 1:{ // quickorder
            
            [tabButton_quickOrder setBgView:NO];  
            [tabButton_product setBgView:YES];
            [tabButton_case setBgView:YES];
            [tabButton_order setBgView:YES];
            [tabButton_news setBgView:YES];
            [tabButton_sync setBgView:YES];
            [self setSelectedIndex:0];
            [btn2 setSelected:NO];
			[btn3 setSelected:NO];
			[btn4 setSelected:NO];
			[btn5 setSelected:NO];
			[btn6 setSelected:NO];
            //[btn7 setSelected:NO];
			break;
		}
		case 2:{

            [tabButton_quickOrder setBgView:YES];  
            [tabButton_product setBgView:NO];
            [tabButton_case setBgView:YES];
            [tabButton_order setBgView:YES];
            [tabButton_news setBgView:YES];
            [tabButton_sync setBgView:YES];
			[self setSelectedIndex:1];
            if ([self.selectedViewController isKindOfClass:[UINavigationController class]]) {
                [(UINavigationController *)self.selectedViewController popViewControllerAnimated:NO];
            }
            [btn1 setSelected:NO];
			[btn6 setSelected:NO];
			[btn3 setSelected:NO];
			[btn4 setSelected:NO];
            [btn5 setSelected:NO];
            //[btn7 setSelected:NO];
			break;
		}
		case 3:{
            [tabButton_quickOrder setBgView:YES];  
            [tabButton_product setBgView:YES];
            [tabButton_case setBgView:NO];
            [tabButton_order setBgView:YES];
            [tabButton_news setBgView:YES];
            [tabButton_sync setBgView:YES];
			[self setSelectedIndex:2];
            if ([self.selectedViewController isKindOfClass:[UINavigationController class]]) {
                [(UINavigationController *)self.selectedViewController popViewControllerAnimated:NO];
            }
			[btn1 setSelected:NO];
			[btn2 setSelected:NO];
			[btn6 setSelected:NO];
			[btn4 setSelected:NO];
            [btn5 setSelected:NO];
            //[btn7 setSelected:NO];
			break;
		}
		case 4:{
            [tabButton_quickOrder setBgView:YES];  
            [tabButton_product setBgView:YES];
            [tabButton_case setBgView:YES];
            [tabButton_order setBgView:NO];
            [tabButton_news setBgView:YES];
            [tabButton_sync setBgView:YES];
            [self setSelectedIndex:3];
			[btn1 setSelected:NO];
			[btn2 setSelected:NO];
			[btn3 setSelected:NO];
			[btn6 setSelected:NO];
            [btn5 setSelected:NO];
            //[btn7 setSelected:NO];
			break;
		}
		case 5:{
            [tabButton_quickOrder setBgView:YES];  
            [tabButton_product setBgView:YES];
            [tabButton_case setBgView:YES];
            [tabButton_order setBgView:YES];
            [tabButton_news setBgView:NO];
            [tabButton_sync setBgView:YES];
			[self setSelectedIndex:4];
			[btn1 setSelected:NO];
			[btn2 setSelected:NO];
			[btn3 setSelected:NO];
			[btn4 setSelected:NO];
            [btn6 setSelected:NO];
            //[btn7 setSelected:NO];
			break;
		}
        case 6:{
            [tabButton_quickOrder setBgView:YES];  
            [tabButton_product setBgView:YES];
            [tabButton_case setBgView:YES];
            [tabButton_order setBgView:YES];
            [tabButton_news setBgView:YES];
            [tabButton_sync setBgView:NO];
			[self setSelectedIndex:5];
			[btn1 setSelected:NO];
			[btn2 setSelected:NO];
			[btn3 setSelected:NO];
            [btn4 setSelected:NO];
			[btn5 setSelected:NO];
            //[btn7 setSelected:NO];
			break;
		}
        /*case 7: {

            [self setSelectedIndex:6];
            [btn1 setSelected:NO];
			[btn2 setSelected:NO];
			[btn3 setSelected:NO];
            [btn4 setSelected:NO];
			[btn5 setSelected:NO];
            [btn6 setSelected:NO];
          
        }*/
		default:
			break;
	}
    
}

@end
