//
//  NSString+HTML.h
//  Showcase_FD
//
//  Created by Yue Gu on 4/18/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (HTML)

+ (NSString *)stringFromHTMLString:(NSString *)htmlString;

@end
