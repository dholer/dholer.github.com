//
//  ProvinceEntity.m
//  Showcase_FD
//
//  Created by Yue Gu on 12-4-3.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "ProvinceEntity.h"

@implementation ProvinceEntity

@synthesize name = _name;
@synthesize sort = _sort;
@synthesize remark = _remark;

- (void)dealloc
{
    [_name release];
    [_sort release];
    [_remark release];
    [super dealloc];
}

@end
