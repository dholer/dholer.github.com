//
//  FDOrderItemEntity.m
//  Showcase_FD
//
//  Created by Yue Gu on 4/5/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import "FDOrderItemEntity.h"
#import "FDProductEntity.h"

#define DEFAULT_COUNT 1
#define DEFAULT_DISCOUNT 1.0

@implementation FDOrderItemEntity

@synthesize serial = _serial;
@synthesize orderID = _orderID;
@synthesize productID = _productID;
@synthesize count = _count;
@synthesize discount = _discount;
@synthesize discountPrice = _discountPrice;
@synthesize note = _note;
@synthesize flag = _flag;

@synthesize product = _product;

- (id)initWithProductEntity:(FDProductEntity *)productEntity
{
    if (self = [super init]) {
        [self setProduct:productEntity];
        _count = DEFAULT_COUNT;
        _discount = DEFAULT_DISCOUNT;
        _discountPrice = [productEntity price] * DEFAULT_DISCOUNT;
        _flag = 0;
    }
    return self;
}

- (void)dealloc
{
    [_serial release];
    [_orderID release];
    [_note release];
    
    [_product release];
    
    [super dealloc];
}

@end
