//
//  FDProductModel.m
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "FDProductModel.h"
#import "FDProductEntity.h"
#import "FDProductCatalogModel.h"
#import "FDProductCatalogEntity.h"
#import "FDWebservice.h"
#import "UIDevice+IdentifierAddition.h"
#import "NSString+HTML.h"

@interface FDProductModel()

@property (nonatomic, retain) NSURLConnection *theConnection;
@property (nonatomic, retain) NSMutableData *theData;

@end

@implementation FDProductModel

@synthesize delegate = _delegate;

@synthesize theConnection = _theConnection;
@synthesize theData = _theData;

- (void)dealloc
{
    [_theConnection release];
    [_theData release];
    [super dealloc];
}

- (BOOL)synchronizeWithProductEntities:(NSArray *)productEntities
{
    BOOL flag = NO;
    for (FDProductEntity *productEntity in productEntities) {
        flag = [self addProductEntity:productEntity];
        if (!flag) return NO;
    }
    return flag;
}

- (void)syncProducts
{
    NSString *isFull = nil;
    if ([[FDWebservice sharedInstance] userHasSynced]) isFull = @"false";
    else isFull = @"true";
    NSURL *url = [NSURL URLWithString:[[[FDWebservice sharedInstance] getDataURL] stringByAppendingFormat:SYNC_FD_PRODUCT, [[FDWebservice sharedInstance] sesseionId], [[FDWebservice sharedInstance] getClientId], [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], isFull]];
    NSLog(@"%@", url);
    NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120.0];
    [self setTheConnection:[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease]];    
}

- (BOOL)addProductEntity:(FDProductEntity *)productEntity
{
    NSString *sql = [NSString stringWithFormat:@"INSERT OR REPLACE INTO %@ (%@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", 
                     PRODUCT_TABLE_NAME, 
                     PRODUCT_COLUMN_NAME_PRODUCT_ID, 
                     PRODUCT_COLUMN_NAME_SKU, 
                     PRODUCT_COLUMN_NAME_NAME, 
                     PRODUCT_COLUMN_NAME_TYPE, 
                     PRODUCT_COLUMN_NAME_STYLE, 
                     PRODUCT_COLUMN_NAME_ROOM, 
                     PRODUCT_COLUMN_NAME_LWH,
                     PRODUCT_COLUMN_NAME_SHORTCUT, 
                     PRODUCT_COLUMN_NAME_MATERIAL, 
                     PRODUCT_COLUMN_NAME_PRICE, 
                     PRODUCT_COLUMN_NAME_CURRENCY, 
                     PRODUCT_COLUMN_NAME_THUMB_IMAGE,
                     PRODUCT_COLUMN_NAME_FULL_IMAGE, 
                     PRODUCT_COLUMN_NAME_PUBLISH, 
                     PRODUCT_COLUMN_NAME_ATTRIBUTE, 
                     PRODUCT_COLUMN_NAME_DESC, 
                     PRODUCT_COLUMN_NAME_RELATED, 
                     PRODUCT_COLUMN_NAME_CREATED_TIME, 
                     PRODUCT_COLUMN_NAME_CREATED_BY, 
                     PRODUCT_COLUMN_NAME_UPDATED_TIME, 
                     PRODUCT_COLUMN_NAME_UPDATED_BY, 
                     PRODUCT_COLUMN_NAME_DELETED
                     ];
	NSArray *argArray = [NSArray arrayWithObjects:
                         [NSNumber numberWithInt:[productEntity productID]],
                         [productEntity sku] ? [productEntity sku] : @"", 
                         [productEntity name] ? [productEntity name] : @"", 
                         [productEntity type] ? [productEntity type] : @"", 
                         [NSNumber numberWithInt:[productEntity style]], 
                         [NSNumber numberWithInt:[productEntity room]], 
                         [productEntity lwh] ? [productEntity lwh] : @"", 
                         [productEntity shortcut] ? [productEntity shortcut] : @"", 
                         [productEntity material] ? [productEntity material] : @"", 
                         [NSNumber numberWithFloat:[productEntity price]], 
                         [productEntity currency] ? [productEntity currency] : @"", 
                         [productEntity thumbImage] ? [productEntity thumbImage] : @"", 
                         [productEntity fullImage] ? [productEntity fullImage] : @"", 
                         [NSNumber numberWithInt:[productEntity publish]], 
                         [productEntity attibute] ? [productEntity attibute] : @"", 
                         [productEntity desc] ? [productEntity desc] : @"", 
                         [productEntity related] ? [productEntity related] : @"", 
                         [productEntity createdTime] ? [productEntity createdTime] : @"",
                         [productEntity createdBy] ? [productEntity createdBy] : @"", 
                         [productEntity updatedTime] ? [productEntity updatedTime] : @"",
                         [productEntity updatedBy] ? [productEntity updatedBy] : @"", 
                         [NSNumber numberWithInt:[productEntity deleted]], 
                         nil];
	FMDatabase *db = [FMDatabase sharedDataBase];
	BOOL result = [db executeUpdate:sql withArgumentsInArray:argArray];
	
	return result;
}

#pragma mark - 

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response 
{
    NSMutableData *t = [[NSMutableData alloc] initWithLength:0];
    [self setTheData:t];
    [t release];
}

- (void)connection:(NSURLConnection *)connection  didReceiveData:(NSData *)data 
{
	[[self theData] appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection 
{
	NSLock *lock1= [[NSLock alloc] init];
	[lock1 lock];
	NSString *JSONString=[[NSString alloc] initWithData:[self theData] encoding:NSUTF8StringEncoding];
	id JSON = [[JSONString JSONValue] retain];
	[JSONString release];
    NSString *status = [[[JSON objectForKey:@"results"] objectAtIndex:0] objectForKey:@"status"];
    BOOL flag = NO;
    NSMutableArray *productImagesWithFullURL = [[[NSMutableArray alloc] init] autorelease];
    if ([@"200" isEqualToString:status]) {
        NSArray *productsJSONArray = (NSArray *)[JSON objectForKey:@"content"];
        if (!productsJSONArray || [[NSNull null] isEqual:productsJSONArray] || 0 >= [productsJSONArray count]) {
            [[self delegate] productModelSyncFinished:self withInfo:NO andProductImagesToDownload:nil];
            return;
        }
        else {
            NSMutableArray *productsArray = [[NSMutableArray alloc] init];
            NSMutableArray *catalogArray = [[NSMutableArray alloc] init];
            for (id productJSON in productsJSONArray) {
                FDProductEntity *productEntity = [[FDProductEntity alloc] init];
                [productEntity setProductID:[(NSNumber *)[productJSON objectForKey:@"productID"] intValue]];
                [productEntity setSku:[productJSON objectForKey:@"productSKU"]];
                [productEntity setName:[productJSON objectForKey:@"productName"]];
                [productEntity setType:[productJSON objectForKey:@"productType"]];
                [productEntity setStyle:[(NSNumber *)[productJSON objectForKey:@"productStyleID"] intValue]];
                [productEntity setRoom:[(NSNumber *)[productJSON objectForKey:@"productRoomID"] intValue]];
                [productEntity setLwh:[productJSON objectForKey:@"productLWH"]];
                [productEntity setShortcut:[productJSON objectForKey:@"productShortcut"]];
                [productEntity setShortcut:[NSString stringFromHTMLString:[productEntity shortcut]]];
                [productEntity setMaterial:[productJSON objectForKey:@"productMaterial"]];
                [productEntity setPrice:[(NSNumber *)[productJSON objectForKey:@"productPrice"] floatValue]];
                [productEntity setCurrency:[productJSON objectForKey:@"productCurrency"]];
                [productEntity setThumbImage:[productJSON objectForKey:@"productThumbImage"]];
                [productEntity setFullImage:[productJSON objectForKey:@"productFullImage"]];
                [productEntity setRelated:[productJSON objectForKey:@"productRelated"]];
                [productEntity setPublish:[(NSNumber *)[productJSON objectForKey:@"productPublish"] intValue]];
                [productEntity setAttibute:[productJSON objectForKey:@"productAttr"]];
                [productEntity setDesc:[productJSON objectForKey:@"productdesc"]];
                
                [productsArray addObject:productEntity];
                
                id productRoomID = [productJSON objectForKey:@"productRoomID"];
                id productStyleID = [productJSON objectForKey:@"productStyleID"];
                
                if (productRoomID) {
                    int newID = [productRoomID intValue];
                    BOOL catalogExistsFlag = NO;
                    for (FDProductCatalogEntity *catalogEntity in catalogArray) {
                        if ([catalogEntity catalogID] == newID) {
                            catalogExistsFlag = YES;
                            break;
                        }
                    }
                    if (!catalogExistsFlag) {
                        FDProductCatalogEntity *productCatalogEntity = [[FDProductCatalogEntity alloc] init];
                        [productCatalogEntity setCatalogID:[productRoomID intValue]];
                        [productCatalogEntity setName:[productJSON objectForKey:@"productRoom"]];
                        [productCatalogEntity setCode:[productJSON objectForKey:@"productRoomCode"]];
                        [productCatalogEntity setType:[productJSON objectForKey:@"productRoomType"]];
                        [productCatalogEntity setOrder:[[productJSON objectForKey:@"productRoomOrdering"] intValue]];
                        [catalogArray addObject:productCatalogEntity];
                        [productCatalogEntity release];
                    }
                }
                if (productStyleID) {
                    int newID = [productStyleID intValue];
                    BOOL catalogExistsFlag = NO;
                    for (FDProductCatalogEntity *catalogEntity in catalogArray) {
                        if ([catalogEntity catalogID] == newID) {
                            catalogExistsFlag = YES;
                            break;
                        }
                    }
                    if (!catalogExistsFlag) {
                        FDProductCatalogEntity *productCatalogEntity = [[FDProductCatalogEntity alloc] init];
                        [productCatalogEntity setCatalogID:[productStyleID intValue]];
                        [productCatalogEntity setName:[productJSON objectForKey:@"productStyle"]];
                        [productCatalogEntity setCode:[productJSON objectForKey:@"productStyleCode"]];
                        [productCatalogEntity setType:[productJSON objectForKey:@"productStyleType"]];
                        [productCatalogEntity setOrder:[[productJSON objectForKey:@"productStyleOrdering"] intValue]];
                        [catalogArray addObject:productCatalogEntity];
                        [productCatalogEntity release];
                    }
                }
                if ([productEntity thumbImage] && ![@"" isEqualToString:[productEntity thumbImage]])
                    [productImagesWithFullURL addObject:[productEntity thumbImage]];
                if ([productEntity fullImage] && ![@"" isEqualToString:[productEntity fullImage]])
                    [productImagesWithFullURL addObject:[productEntity fullImage]];
                [productEntity release];
            }
            if ([self synchronizeWithProductEntities:productsArray]) {
                FDProductCatalogModel *model = [[FDProductCatalogModel alloc] init];
                flag = [model synchronizeWithProductCatalogEntities:catalogArray];
                [model release];
            }
            [productsArray release];
            [catalogArray release];
        }
        if (flag) [[self delegate] productModelSyncFinished:self withInfo:YES andProductImagesToDownload:productImagesWithFullURL];
        else [[self delegate] productModel:self syncErrorMessage:nil];
        [lock1 unlock];
        [lock1 release];
        //    [JSON release];
        [self setTheConnection:nil];
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
	[self setTheConnection:nil];
}





@end
