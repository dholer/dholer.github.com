//
//  ProvinceCityZoneViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 4/9/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ProvinceCityZoneViewController;

@protocol ProvinceCityZoneViewControllerDelegate <NSObject>

- (void)provinceCityZoneViewController:(ProvinceCityZoneViewController *)provinceCityZoneViewController didSelectItem:(id)item;

@end

@interface ProvinceCityZoneViewController : UITableViewController

@property (nonatomic, retain) NSArray * items;

@property (nonatomic, assign) id <ProvinceCityZoneViewControllerDelegate> delegate;

@property (nonatomic) int tag;

@end
