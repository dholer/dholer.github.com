//
//  LoginViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 3/28/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import "LoginViewController.h"
#import "FDWebservice.h"
#import "ModalAlert.h"

@interface LoginViewController () <UITextFieldDelegate, UIAlertViewDelegate>

@property (retain, nonatomic) IBOutlet UITextField *usernameTextField;
@property (retain, nonatomic) IBOutlet UITextField *passwordTextField;
@property (retain, nonatomic) IBOutlet UIButton *loginButton;

@end

@implementation LoginViewController

@synthesize usernameTextField;
@synthesize passwordTextField;
@synthesize loginButton;

@synthesize online = _online;

@synthesize delegate = _delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{    
    [super viewDidLoad];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    // Overriden to allow any orientation.
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (void)didReceiveMemoryWarning 
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload 
{
    [self setUsernameTextField:nil];
    [self setPasswordTextField:nil];
    [self setLoginButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc 
{
    [usernameTextField release];
    [passwordTextField release];
    [loginButton release];
    [super dealloc];
}

#pragma mark - GUI interactions

- (void)loginSuccedeed
{
    UIViewController *controller;
    if (SYSTEM_VERSION_LESS_THAN(@"5.0")) {
        controller = self.parentViewController;
    } else {
        controller = self.presentingViewController;
    }
    [controller dismissModalViewControllerAnimated:YES];
    [[self delegate] loginViewControllerDismissBackgroundViews];
    NSString *lastSyncDateString = [[FDWebservice sharedInstance] lastSyncDate];
    int inDate = [[FDWebservice sharedInstance] inDate];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *startDate = [dateFormatter dateFromString:lastSyncDateString];
    NSDate *endDate = [NSDate date];
    [dateFormatter release];
    int dayDifference = inDate - (int)[endDate timeIntervalSinceDate:startDate] / (60.0 * 60.0 * 24);
    NSString *message = nil;
    if (dayDifference > 0 <= inDate)
        message = [NSString stringWithFormat:@"登陆成功，数据还有%d天过期", dayDifference];
    else 
        message = [NSString stringWithFormat:@"登陆成功，数据已经过期，请及时更新数据"];
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"通知"
                                                     message:message 
                                                    delegate:nil
                                           cancelButtonTitle:nil
                                           otherButtonTitles:@"确定", nil] autorelease];
    [alert show];
}

//登录所需要进入的方法
-(IBAction)loginButtonPressed:(id)sender
{   
    [self setStatusForLogining];
    
    UIViewController *controller;
    if (SYSTEM_VERSION_LESS_THAN(@"5.0")) {
        controller = self.parentViewController;
    }
    else {
        controller = self.presentingViewController;        
    }
	if(controller){
        NSString *trimmedUserName = [[[self usernameTextField] text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
//        NSString *trimmedPassword = [passwordTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSString *trimmedPassword = [[self passwordTextField] text];
        if ([trimmedUserName length]!= 0&&[trimmedPassword length]!= 0) {
            if ([self online]) {
                NSString *cId = [[FDWebservice sharedInstance] getClientId];
                [[FDWebservice sharedInstance] login:self delegate:@selector(LoginFinished:)   clientId:cId accountID:trimmedUserName password:trimmedPassword];
                [self setStatusForLogining];
            } else {
                if ([trimmedUserName isEqualToString:[[FDWebservice sharedInstance] getUserId]] && [trimmedPassword isEqualToString:[[FDWebservice sharedInstance] getPassword]]) {
                    [self loginSuccedeed];
                } else {
                    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"错误"
                                                                     message:@"帐号或密码错误！" 
                                                                    delegate:nil
                                                           cancelButtonTitle:nil
                                                           otherButtonTitles:@"确定", nil] autorelease];
                    [alert show];
                    [self setStatusForNormal];
                }
            }
        } else {
            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"警告"
                                                             message:@"任何一项不能为空！" 
                                                            delegate:nil
                                                   cancelButtonTitle:nil
                                                   otherButtonTitles:@"确定", nil] autorelease];
            [alert show];
            [self setStatusForNormal];
        }		
	}
}

- (void)LoginFinished:(id)retData 
{
    
    [self setStatusForNormal];
    
    NSString *status=[[[retData objectForKey:@"results"] objectAtIndex:0]objectForKey:@"status"];
    if ([status isEqualToString:@"200"]) {
        NSString *sessionid = [[retData objectForKey:@"content"] objectForKey:@"sessionId"];
        NSString *lastSyncDate = [[[retData objectForKey:@"content"] objectForKey:@"user"] objectForKey:@"lastSyncDate"];
        int inDate = [[[[retData objectForKey:@"content"] objectForKey:@"user"] objectForKey:@"inDate"] intValue];
        NSString *userID = [[[retData objectForKey:@"content"] objectForKey:@"user"] objectForKey:@"account"];
        NSString *password = [[[retData objectForKey:@"content"] objectForKey:@"user"] objectForKey:@"password"];
        [[FDWebservice sharedInstance] setSesseionId:sessionid];
        [[FDWebservice sharedInstance] setUserId:userID];
        [[FDWebservice sharedInstance] setPassword:password];
        [[FDWebservice sharedInstance] setLastSyncDate:lastSyncDate];
        [[FDWebservice sharedInstance] setInDate:inDate];
        [self loginSuccedeed];
    } else if ([status isEqualToString:@"217"]) {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"错误"
                                                         message:@"帐号已过期，请联系管理员！" 
                                                        delegate:nil
                                               cancelButtonTitle:nil
                                               otherButtonTitles:@"确定", nil] autorelease];
        [alert show];
    } else if ([status isEqualToString:@"208"]) {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"错误"
                                                         message:@"设备尚未激活，请及时查收邮件！" 
                                                        delegate:nil
                                               cancelButtonTitle:nil
                                               otherButtonTitles:@"确定", nil] autorelease];
        [alert show];
    } else {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"错误"
                                                         message:@"帐号或密码错误！" 
                                                        delegate:nil
                                               cancelButtonTitle:nil
                                               otherButtonTitles:@"确定", nil] autorelease];
        [alert show];
    }
}

#pragma mark -  UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        [[self delegate] loginViewControllerDismissBackgroundViews];
    }
}

-(void)setStatusForLogining
{	
    [[self loginButton] setEnabled:NO];
//    [activityView setHidden:NO];
//	[contentInfo setHidden:YES];
//    activityView startAnimating];
//	[contentInfo setText:Localized(@"Verifying")];
}


-(void)setStatusForNormal
{
    [[self loginButton] setEnabled:YES];
//    [activityView setHidden:YES];
//    [activityView stopAnimating];
//	[contentInfo setHidden:YES];
}

@end
