//
//  FDProductModel.h
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "DataTablesModel.h"

@class FDProductEntity;
@class FDProductModel;

@protocol FDProductModelDelegate <NSObject>

- (void)productModelSyncFinished:(FDProductModel *)productModel withInfo:(BOOL)hasData andProductImagesToDownload:(NSMutableArray *)productImagesWithFullURL;
- (void)productModel:(FDProductModel *)productModel syncErrorMessage:(NSString *)errorMessage;

@end

@interface FDProductModel : DataTablesModel

@property (nonatomic, assign) id <FDProductModelDelegate> delegate;

- (void)syncProducts;

- (BOOL)synchronizeWithProductEntities:(NSArray *)productEntities;

- (BOOL)addProductEntity:(FDProductEntity *)productEntity;


@end
