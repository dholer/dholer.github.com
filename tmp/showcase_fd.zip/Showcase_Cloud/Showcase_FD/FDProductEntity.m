//
//  FDProductEntity.m
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "FDProductEntity.h"
#import "Constants.h"
@implementation FDProductEntity

@synthesize productID = _productID;
@synthesize sku = _sku;
@synthesize name = _name;
@synthesize type = _type;
@synthesize style = _style;
@synthesize room = _room;
@synthesize lwh = _lwh;
@synthesize shortcut = _shortcut;
@synthesize material = _material;
@synthesize price = _price;
@synthesize currency = _currency;
@synthesize thumbImage = _thumbImage;
@synthesize fullImage = _fullImage;
@synthesize related = _related;
@synthesize publish = _publish;
@synthesize attibute = _attibute;
@synthesize desc = _desc;
@synthesize createdTime = _createdTime;
@synthesize createdBy = _createdBy;
@synthesize updatedTime = _updatedTime;
@synthesize updatedBy = _updatedBy;
@synthesize deleted = _deleted;
@synthesize styleCode = _styleCode;
@synthesize styleName = _styleName;
@synthesize roomName = _roomName;

- (void) dealloc
{
	[_sku release];
	[_name release];
	[_type release];
	[_lwh release];
    [_shortcut release];
	[_material release];
    [_currency release];
	[_thumbImage release];
    [_fullImage release];
    [_related release];
    [_attibute release];
    [_createdTime release];
    [_createdBy release];
    [_updatedTime release];
    [_updatedBy release];
	[_styleName release];
    [_roomName release];
    [_styleCode release];
    
	[super dealloc];
}

@end
