//
//  FDOrderEntity.m
//  Showcase_FD
//
//  Created by Yue Gu on 4/5/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import "FDOrderEntity.h"

@implementation FDOrderEntity

@synthesize serial = _serial;
@synthesize store = _store;
@synthesize customer = _customer;
@synthesize phone = _phone;
@synthesize cellPhone = _cellPhone;
@synthesize shoppingGuide = _shoppingGuide;
@synthesize homePhone = _homePhone;
@synthesize province = _province;
@synthesize city = _city;
@synthesize zone = _zone;
@synthesize address = _address;
@synthesize detailProvince = _detailProvince;
@synthesize detailCity = _detailCity;
@synthesize detailZone = _detailZone;
@synthesize detailAddress = _detailAddress;
@synthesize orderingDate = _orderingDate;
@synthesize deliveringDate = _deliveringDate;
@synthesize deposit = _deposit;
@synthesize balance = _balance;
@synthesize requirements = _requirements;
@synthesize total = _total;
@synthesize totalDiscount = _totalDiscount;
@synthesize finalTotal = _finalTotal;
@synthesize note = _note;
@synthesize createdDate = _createdDate;

@synthesize orderItems = _orderItems;

- (void)dealloc
{
    [_serial release];
    [_store release];
    [_customer release];
    [_phone release];
    [_cellPhone release];
    [_shoppingGuide release];
    [_homePhone release];
    [_province release];
    [_city release];
    [_zone release];
    [_address release];
    [_detailProvince release];
    [_detailCity release];
    [_detailZone release];
    [_detailAddress release];
    [_orderingDate release];
    [_deliveringDate release];
    [_requirements release];
    [_note release];
    [_createdDate release];
    
    [_orderItems release];
    
    [super dealloc];
}

@end
