//
//  UIDevice+UIDevice_Until.h
//  Showcase_FD
//
//  Created by august on 12-3-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (UIDevice_Until)
+ (NSString *)getUUID;
@end
