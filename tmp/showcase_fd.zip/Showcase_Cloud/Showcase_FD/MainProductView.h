//
//  MainProductView.h
//  Showcase_FD
//
//  Created by august on 12-3-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CatalogView.h"
#import "FDProductEntity.h"
#import "Constants.h"
#import "MainProductListViewController.h"
@class MainProductView;

@protocol MainProductViewDelegate <NSObject>

@required
- (CGSize)sizeOfCatalogsCell;
- (NSUInteger)numberOfProdcutCatalogs:(NSString *)bigCatalogID;
- (id)productCatalogForIndex:(NSUInteger)index;
- (NSArray *)getArrayOfProductCatalogID:(int)smallcatalogID;
- (NSUInteger)numberOfColumnsForLandscape;
- (PAGETYPE)getCurrentPageType;
@optional
- (void)didProductSelect:(id)object;

@end

@interface MainProductView : UIViewController<CatalogViewDelegate,MainProductListViewControllerDelegate> {
	
    UIScrollView     *catalogScrollView;
    CGSize           sizeOfProdcutCatalogsCell;
    NSUInteger       numberOfRows;
    NSUInteger       numberOfProductCatalog;
    NSUInteger       numberOfColumns;
    NSUInteger       numberOfProducts;
    NSArray          *currentpArray;
	BOOL             wideShow;
    CGRect           scrollviewFrame;
    id <MainProductViewDelegate>   delegate;
    PAGETYPE         pageType;
    MainProductListViewController *productlistview;
    BOOL             isHidden;
}

@property (nonatomic,retain) UIScrollView *catalogScrollView;
@property (nonatomic,assign) id <MainProductViewDelegate> delegate;
@property (nonatomic,retain) NSArray *currentpArray;
@property(nonatomic) BOOL isHidden;
@property(nonatomic) BOOL wideShow;

- (id)initWithFrame:(CGRect)frame;
- (void)loadData:(NSString *)bigCatalogID;
- (void)didCatalogSelected:(id)object_ location:(CGPoint)location;
- (NSUInteger)indexForColumn:(NSUInteger)column inRow:(NSUInteger)row;

- (void)modifyProductListviewWidth;

@end
