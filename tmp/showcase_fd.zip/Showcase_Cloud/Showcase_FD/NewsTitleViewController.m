//
//  NewsTitleViewController.m
//  Showcase_FD
//
//  Created by Yue Gu on 12-3-23.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "NewsTitleViewController.h"
#import "NewsTitleTableViewCell.h"
#import "FDFileEntity.h"

@interface NewsTitleViewController () <UITableViewDataSource, UITableViewDelegate>

@property (retain, nonatomic) IBOutlet UITableView *titleTableView;
@property (retain, nonatomic) IBOutlet UIButton *sliderButton;

@property (nonatomic) BOOL sliderIsShown;

@end

@implementation NewsTitleViewController

@synthesize fileEntities = _fileEntities;

@synthesize delegate = _delegate;

@synthesize titleTableView = _titleTableView;
@synthesize sliderButton = _sliderButton;

@synthesize sliderIsShown = _sliderIsShown;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [_fileEntities release];
    [_titleTableView release];
    [_sliderButton release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setSliderIsShown:YES];
    if ([self sliderIsShown]) {
        [[self sliderButton] setImage:[UIImage imageNamed:@"arrow-lft.png"] forState:UIControlStateNormal];
    }else{
        [[self sliderButton] setImage:[UIImage imageNamed:@"arrow-rgt.png"] forState:UIControlStateNormal];
    }
}

- (void)viewDidUnload
{
    [self setTitleTableView:nil];
    [self setSliderButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

#pragma mark - GUI interactions

- (IBAction)sliderButtonPressed:(id)sender 
{
    [self setSliderIsShown:![self sliderIsShown]];
    if ([self sliderIsShown]) {
        [[self sliderButton] setImage:[UIImage imageNamed:@"arrow-lft.png"] forState:UIControlStateNormal];
    }else{
        [[self sliderButton] setImage:[UIImage imageNamed:@"arrow-rgt.png"] forState:UIControlStateNormal];
    }
    if ([[self delegate] respondsToSelector:@selector(sliderIsShownChanged:)]) 
        [[self delegate] sliderIsShownChanged:[self sliderIsShown]];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self fileEntities] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"NewsTitleTableViewCell";
    NewsTitleTableViewCell *cell = (NewsTitleTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
		NSArray *nibArray = [[NSBundle mainBundle] loadNibNamed:@"NewsTitleTableViewCell" 
														  owner:nil 
														options:nil];
		cell = (NewsTitleTableViewCell *)[nibArray objectAtIndex:0];
		[cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    FDFileEntity *fileEntity = [[self fileEntities] objectAtIndex:[indexPath row]];
    [[cell flagImageView] setImage:([fileEntity flag] ? [UIImage imageNamed:@"icon-read.png"] : [UIImage imageNamed:@"icon-unread.png"])];
    [[cell titleLabel] setText:[fileEntity title]];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    [[cell dateLabel] setText:[[dateFormatter stringFromDate:[fileEntity createdTime]] substringToIndex:10]];
    [dateFormatter release];
	
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FDFileEntity *fileEntity = [[self fileEntities] objectAtIndex:[indexPath row]];
    NewsTitleTableViewCell *cell = (NewsTitleTableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    [[cell flagImageView] setImage:[UIImage imageNamed:@"icon-read.png"]];
    if ([[self delegate] respondsToSelector:@selector(didSelectFile:)])
        [[self delegate] didSelectFile:fileEntity];
    [fileEntity setFlag:1];
}

@end
