//
//  MyMoveGesture.h
//  Showcase_FD
//
//  Created by  on 12-5-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyMoveGesture : UIPanGestureRecognizer {
    CGFloat moveX;
    CGFloat moveY;
    CGRect  cFrame;
    BOOL    flag;
}
@property (nonatomic) CGFloat moveX;
@property (nonatomic) CGFloat moveY;
@property (nonatomic) CGRect cFrame;
@property (nonatomic) BOOL flag;//判断图片图片时是否触发scrolview的平移
@end
