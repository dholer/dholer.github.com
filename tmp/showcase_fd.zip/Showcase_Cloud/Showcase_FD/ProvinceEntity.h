//
//  ProvinceEntity.h
//  Showcase_FD
//
//  Created by Yue Gu on 12-4-3.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#define PROVINCE_TABLE_NAME @"T_Province"

#define PROVINCE_TABLE_COLUMN_NAME_NAME @"ProName"
#define PROVINCE_TABLE_COLUMN_NAME_SORT @"ProSort"
#define PROVINCE_TABLE_COLUMN_NAME_REMARK @"ProRemark"

@interface ProvinceEntity : NSObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * sort;
@property (nonatomic, retain) NSString * remark;

@end
