//
//  FDImageModel.h
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "DataTablesModel.h"

@class FDFileEntity;
@class FDFileModel;

@protocol FDFileModelDelegate <NSObject>

- (void)fileModelSyncFinished:(FDFileModel *)fileModel withInfo:(BOOL)hasData andFilesToDownload:(NSMutableArray *)filesWithFullURL;
- (void)fileModel:(FDFileModel *)fileModel syncError:(NSString *)errorMessage;

@end

@interface FDFileModel : DataTablesModel

@property (nonatomic, assign) id <FDFileModelDelegate> delegate;

- (BOOL)synchronizeWithFileEntities:(NSArray *)fileEntities;

- (BOOL)addFileEntity:(FDFileEntity *)fileEntity;

- (void)syncFiles;

@end
