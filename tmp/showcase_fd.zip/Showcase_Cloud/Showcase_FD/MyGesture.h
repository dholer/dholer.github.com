//
//  MyGesture.h
//  Showcase_FD
//
//  Created by  on 12-4-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyGesture : UIPinchGestureRecognizer {
    CGFloat curScale;
    CGPoint center;
    CGRect cFrame;
    BOOL    flag;//判断是否添加平移手势，只有在放缩之后才添加
}
@property (nonatomic) CGFloat curScale;
@property (nonatomic) CGPoint center;
@property (nonatomic) CGRect cFrame;
@property (nonatomic) BOOL flag;

@end
