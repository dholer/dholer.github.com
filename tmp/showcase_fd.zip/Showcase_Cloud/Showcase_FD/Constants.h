/*
 *  Constants.h
 *  AutoFinance_iPad
 *
 *  Created by Fu Jinling on 10-7-26.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */
#import "DataManagerModel.h"
#import "AppDelegate.h"


#define SEVERURL @"192.168.42.227"
//#define SEVERURL @"216.91.145.81"
#define SEVERPORT 8080
#define IMAGEPORT 8080
#define MainPath @"ShowcaseCloudServer"
// Added by Alex 2012-3-15 --------------top

#define SYNC_FD_USER_REGISTER @"%@User?methodName=register&clientId=%@&deviceId=%@&userName=%@&userCode=%@&contact=%@&email=%@&phone=%@"
#define SYNC_FD_GET_DEVICE_STATUS @"%@User?methodName=getDeviceStatus&clientId=%@&deviceId=%@"
#define SYNC_FD_USER_LOGIN @"%@User?methodName=login&clientId=%@&accountId=%@&deviceId=%@&password=%@"
#define SYNC_FD_PDF @"SyncCloudServer;jsessionId=%@?methodName=syncData&clientId=%@&deviceId=%@&syncType=notice&isFull=%@"
#define SYNC_FD_VEDIO @"SyncCloudServer;jsessionId=%@?methodName=syncData&clientId=%@&deviceId=%@&syncType=vedio&isFull=%"
#define SYNC_FD_PRODUCT @"SyncCloudServer;jsessionId=%@?methodName=syncData&clientId=%@&deviceId=%@&syncType=product&isFull=%@"
#define SYNC_FD_FILE @"SyncCloudServer;jsessionId=%@?methodName=syncData&clientId=%@&deviceId=%@&syncType=product&isFull=%"
#define SYNC_FD_FINISHED @"SyncCloudServer;jsessionId=%@?methodName=syncDataFinished&clientId=%@&deviceId=%@&tableType=%@"

#define SYNC_FD_STATUS_SUCCESS 0
// Added by Alex 2012-3-15 --------------bottom

#define   RequestUserLoginURL            @"User?methodName=login&loginid=%@&password=%@"
//add by august 2011-12-20
#define   UploadDeviceTokenRequestURL    @"User?methodName=installApp&deviceId=%@&deviceToken=%@&softVersion=%@"
#define   CheckAppExpirationRequestURL   @"User?methodName=checkApp&deviceId=%@"

#define   PRODUCTIMAGESPATH @"ProductImages"
#define FILE_PATH @"Files"
#define   DOCUMENT_FOLDER_PATH [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
#define   PRODUCT_IMAGE_SOURCE_PATH  [DOCUMENT_FOLDER_PATH stringByAppendingPathComponent:PRODUCTIMAGESPATH]
#define FILE_SOURCE_PATH [DOCUMENT_FOLDER_PATH stringByAppendingPathComponent:FILE_PATH]

#define STATUSOFSUCCESS @"0"
#define kDatabaseName @"furniture_db.sqlite"
#define VIEWFRAME CGRectMake(0, 0, 1024.0, 768.0)



#ifdef _DEBUG__
void AssertFailed(const char *filename, int lineno);
#define ASSERT(x)  if (!(x)) AssertFailed(__FILE__, __LINE__)
#else
#define ASSERT(x) /**/
#endif

#define Localized(x) [DataManagerModel localizestr:x]
#define LANGUAGE_ZH @"中文"
#define LANGUAGE_EN @"English"
//ZH RETURN YES ,EN RETURN NO
#define GETLANGUAGE [DataManagerModel whichLanguageIs]

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

#define App_Delegate (AppDelegate *)[UIApplication sharedApplication].delegate
#define RGBCOLOR(r,g,b,al) [UIColor colorWithRed:(r/255.0) green:(g/255.0) blue:(b/255.0) alpha:al]

#define ROOM @"room"
#define STYLE @"style"

//product type
#define SINGLE @"SINGLE"
#define COMBINE @"COMBINE"
#define CASE  @"CASE"

typedef enum PAGETYPETag{
    QuickOrderPage = 0,
    ProdctShowPage,
    CasePage,
    
}PAGETYPE;

//TABLE CATALGO
#define CATALOG_TABLE_NAME @"fd_product_catalog"
#define CATALOG_COLUMN_NAME_CATALOG_ID @"catalog_id"
#define CATALOG_COLUMN_NAME_NAME @"name"
#define CATALOG_COLUMN_NAME_CODE @"code"
#define CATALOG_COLUMN_NAME_TYPE @"type"
#define CATALOG_COLUMN_NAME_ORDER @"ordering"
#define CATALOG_COLUMN_NAME_CREATED_TIME @"createtime"
#define CATALOG_COLUMN_NAME_CREATED_BY @"createby"
#define CATALOG_COLUMN_NAME_UPDATED_TIME @"updatetime"
#define CATALOG_COLUMN_NAME_UPDATED_BY @"updateby"

//TABALE PRODUCT
#define PRODUCT_TABLE_NAME @"fd_product"
#define PRODUCT_COLUMN_NAME_PRODUCT_ID @"product_id"
#define PRODUCT_COLUMN_NAME_SKU @"sku"
#define PRODUCT_COLUMN_NAME_NAME @"name"
#define PRODUCT_COLUMN_NAME_TYPE @"type"
#define PRODUCT_COLUMN_NAME_STYLE @"style"
#define PRODUCT_COLUMN_NAME_ROOM @"room"
#define PRODUCT_COLUMN_NAME_LWH @"lwh"
#define PRODUCT_COLUMN_NAME_SHORTCUT @"shortcut"
#define PRODUCT_COLUMN_NAME_MATERIAL @"material"
#define PRODUCT_COLUMN_NAME_PRICE @"price"
#define PRODUCT_COLUMN_NAME_CURRENCY @"currency"
#define PRODUCT_COLUMN_NAME_THUMB_IMAGE @"thumb_image"
#define PRODUCT_COLUMN_NAME_FULL_IMAGE @"full_image"
#define PRODUCT_COLUMN_NAME_RELATED @"related"
#define PRODUCT_COLUMN_NAME_PUBLISH @"publish"
#define PRODUCT_COLUMN_NAME_ATTRIBUTE @"attribute"
#define PRODUCT_COLUMN_NAME_DESC @"desc"
#define PRODUCT_COLUMN_NAME_CREATED_TIME @"createtime"
#define PRODUCT_COLUMN_NAME_CREATED_BY @"createby"
#define PRODUCT_COLUMN_NAME_UPDATED_TIME @"updatetime"
#define PRODUCT_COLUMN_NAME_UPDATED_BY @"updateby"
#define PRODUCT_COLUMN_NAME_DELETED @"deleted"

//TABLE FILE
#define FILE_TABLE_NAME @"fd_file"

#define FILE_COLUMN_NAME_FILE_ID @"fileid"
#define FILE_COLUMN_NAME_KIND @"kind"
#define FILE_COLUMN_NAME_TITLE @"title"
#define FILE_COLUMN_NAME_NAME @"name"
#define FILE_COLUMN_NAME_CREATED_TIME @"createtime"
#define FILE_COLUMN_NAME_CREATED_BY @"createby"
#define FILE_COLUMN_NAME_UPDATED_TIME @"updatetime"
#define FILE_COLUMN_NAME_UPDATED_BY @"updateby"
#define FILE_COLUMN_NAME_DELETED @"deleted"
#define FILE_COLUMN_NAME_FLAG @"flag"

//notification string
#define NOTIFICATION_FD_FINISHED_SYNC @"sync_finished_notification"

#define ISNULLSTRING(str) str?str:@""
