//
//  HomeViewController.h
//  iPadSales
//
//  Created by august on 11-10-18.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITabBarControllerEx.h"
#import "RegisterViewController.h"
#import "LoginViewController.h"

@interface HomeViewController : UIViewController <RegisterViewControllerDelegate, LoginViewControllerDelegate> {
	UITabBarControllerEx *tabbarcontrollerEx;
  
}
-(void)showLoginView:(UIViewController *)viewController online:(BOOL)online;

-(IBAction)didButtonSelected:(id)sender;

@end
