//
//  CatalogView.m
//  Showcase_FD
//
//  Created by august on 12-3-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CatalogView.h"
#import "FDProductEntity.h"
#import "Constants.h"
#import "UIImage+Until.h"
@implementation CatalogView
@synthesize delegate;



- (id)initWithFrame:(CGRect)frame productCatalogEntity:(id)catalog_object withPageType:(PAGETYPE)type delegate:(id<CatalogViewDelegate>) delegate_{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.delegate=delegate_;
        self.backgroundColor=[UIColor clearColor];
        CGRect lbTitlerect=CGRectMake(0, frame.size.height-30, frame.size.width,30);
        UILabel *lbTitle=[[UILabel alloc] initWithFrame:lbTitlerect];
        lbTitle.textAlignment=UITextAlignmentCenter;
        lbTitle.font = [UIFont systemFontOfSize:17.0];
        if ([catalog_object isKindOfClass:[FDProductEntity class]]) {
            
            NSString *styleCode = [(FDProductEntity *)catalog_object styleCode];
            NSString *title;
            if (type==CasePage||type==ProdctShowPage) {
                if (!styleCode||[@"" isEqualToString:styleCode]) {
                    title = [NSString stringWithFormat:@"%@-%@",[(FDProductEntity *)catalog_object styleName],[(FDProductEntity *)catalog_object roomName]];
                }else {
                    title = [NSString stringWithFormat:@"%@ %@-%@",[(FDProductEntity *)catalog_object styleName],[(FDProductEntity *)catalog_object styleCode],[(FDProductEntity *)catalog_object roomName]];
                }  
            }else {
                if (!styleCode||[@"" isEqualToString:styleCode]) {
                    title = [NSString stringWithFormat:@"%@系列",[(FDProductEntity *)catalog_object styleName]];
                }else {
                    title = [NSString stringWithFormat:@"%@系列",[(FDProductEntity *)catalog_object styleCode]];
                }
            }
            
            lbTitle.text = title;
        }
        
        [lbTitle setTextColor:[UIColor darkGrayColor]];
        lbTitle.backgroundColor=[UIColor clearColor];
        [self addSubview:lbTitle];
        [lbTitle release];
        
        //image Button
        UIImageView *btnCatalogConver=[[UIImageView alloc] init];
        UIImage *image = nil;
//        if (type==CasePage||type==ProdctShowPage) {
//            image = [UIImage getProductThumbImage:(FDProductEntity *)catalog_object];
//        }else {
//            image = [UIImage getQuickOrderProductThumbImage:(FDProductEntity *)catalog_object];
//        }
        FDProductEntity *entity = (FDProductEntity *)catalog_object;
        image = [UIImage imageWithContentsOfFile:[PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:entity.fullImage]];
        

        
        [btnCatalogConver setImage:image];
        [btnCatalogConver setBackgroundColor:[UIColor clearColor]];
//        CGRect imagerect=CGRectMake(10,2.0, frame.size.width-11,frame.size.height-51);
//        btnCatalogConver.frame=imagerect;
        CGSize size = CGSizeMake(frame.size.width, frame.size.height-28);
        float scale = btnCatalogConver.image.size.width/size.width>btnCatalogConver.image.size.height/size.height?btnCatalogConver.image.size.width/size.width:btnCatalogConver.image.size.height/size.height;
        if (btnCatalogConver.image) {
            btnCatalogConver.frame = CGRectMake((size.width-btnCatalogConver.image.size.width/scale)/2, (size.height-btnCatalogConver.image.size.height/scale)/2, btnCatalogConver.image.size.width/scale, btnCatalogConver.image.size.height/scale); 
        }
        else {
            btnCatalogConver.frame = CGRectMake(0, 0 ,0 ,0); 
        }
        [self addSubview:btnCatalogConver];
        [btnCatalogConver release];
        
    }
    
    return self;
    
}

- (id)initWithFrame:(CGRect)frame 
      productEntity:(FDProductEntity *)productEntity 
           withType:(NSString *)type
           delegate:(id<CatalogViewDelegate>) delegate_{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.delegate=delegate_;
        self.backgroundColor=[UIColor clearColor];
        CGRect lbTitlerect=CGRectMake(0, frame.size.height-28, frame.size.width,20);
        UILabel *lbTitle=[[UILabel alloc] initWithFrame:lbTitlerect];
        lbTitle.textAlignment=UITextAlignmentCenter;
        lbTitle.font = [UIFont systemFontOfSize:17.0];
       
        if ([ROOM isEqualToString:type]) {
            lbTitle.text = [NSString stringWithFormat:@"%@",productEntity.roomName];    
        }else if([STYLE isEqualToString:type]) {
            lbTitle.text = [NSString stringWithFormat:@"%@ %@",productEntity.styleName, productEntity.styleCode];
        }else {
            lbTitle.text = [NSString stringWithFormat:@"%@",productEntity.name];
        }
        
        [lbTitle setTextColor:[UIColor darkGrayColor]];
        lbTitle.backgroundColor=[UIColor clearColor];
        [self addSubview:lbTitle];
        [lbTitle release];
        
        //image Button
        UIImageView *btnCatalogConver=[[UIImageView alloc] init];
        [btnCatalogConver setImage:[UIImage productImageName:productEntity.fullImage]];
        [btnCatalogConver setBackgroundColor:[UIColor clearColor]];
        
        CGSize size = CGSizeMake(frame.size.width, frame.size.height-33);
        float scale = btnCatalogConver.image.size.width/size.width>btnCatalogConver.image.size.height/size.height?btnCatalogConver.image.size.width/size.width:btnCatalogConver.image.size.height/size.height;
        if (btnCatalogConver.image) {
            btnCatalogConver.frame = CGRectMake((size.width-btnCatalogConver.image.size.width/scale)/2, (size.height-btnCatalogConver.image.size.height/scale)/2, btnCatalogConver.image.size.width/scale, btnCatalogConver.image.size.height/scale); 
        }
        else {
            btnCatalogConver.frame = CGRectMake(0, 0 ,0 ,0); 
        }
//        CGRect imagerect=CGRectMake(10,2.0, frame.size.width-11,frame.size.height-51);
//        btnCatalogConver.frame=imagerect;
        [self addSubview:btnCatalogConver];
        [btnCatalogConver release];
        
    }
    
    return self;
    
}

#pragma mark -Touch Event
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if ([touches count]==1) {
        UITouch *touch = [touches anyObject];
        isclick=YES;
        location= [touch locationInView:self];
    }
	
}


-(void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    isclick=NO;
}


-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    isclick=NO;
}


-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (isclick) {
        [delegate didSelected:self];
    }
}


- (void)dealloc
{
    //[productCatalogEntity release];
    [super dealloc];
}
@end

