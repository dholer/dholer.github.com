//
//  NovelDataSources.h
//  Novel
//
//  Created by apple on 10-8-17.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <SystemConfiguration/SystemConfiguration.h>
#import "JSON.h"
#import "Constants.h"

@interface FDWebservice : NSObject {
	id			     targetobject;
	id			     myData;

	SEL			     connSEL;
	NSCondition      *ticketsCondition;
	NSString         *sesseionId;
	NSMutableData    *tmpData;
	NSURLConnection *theConnection;
}
@property(nonatomic,retain)NSMutableData    *tmpData; 
@property(nonatomic,retain)NSString         *sesseionId;
@property(nonatomic)SEL connSEL;
@property(nonatomic,retain) NSURLConnection *theConnection;

@property (nonatomic) BOOL userHasRegistered;
@property (nonatomic) BOOL userHasSynced;
@property (nonatomic, retain) NSString *lastSyncDate;
@property (nonatomic) int inDate;

// ugly used
@property (nonatomic) BOOL needToRegisterWithoutDeleteApp;

//////////////////////////////////////////////////////////
// order detail items cache                             //
@property (nonatomic, retain) NSString *store;          //
@property (nonatomic, retain) NSString *phone;          //
@property (nonatomic, retain) NSString *shoppingGuide;  //
@property (nonatomic, retain) NSString *province;       //
@property (nonatomic, retain) NSString *city;           //
@property (nonatomic, retain) NSString *zone;           //
@property (nonatomic, retain) NSString *address;        //
@property (nonatomic, retain) NSString *requirements;   //
//////////////////////////////////////////////////////////

+ (FDWebservice *) sharedInstance;
-(void)setClientId:(NSString *)cid;
- (NSString *)getClientId;
- (NSString *)		 getUserId;
-(void)setUserId:(NSString *)userID;
- (NSString *)		 getPassword;
-(void)setPassword:(NSString *)pswd;
- (BOOL)		     getLoginMode;
-(void)setLoginMode:(BOOL)isonline;
- (NSString *)		 getRandomParam:(NSString *)url;
- (NSURL *)			 getUrlBystrUrl:(NSString *)strpath;
- (void)			 syncDataFromRemoting:(id)target delegate:(SEL)delegate url:(NSURL *)url;

-(void)setMailAddress:(NSString *)address;
-(NSString *)getMailAddress;
-(void)cancelConnection;

//add by august 2011-12-20
- (void)uploadDeviceToken:(id)target selector:(SEL)selector_ withDeviceToken:(NSString *)deviceToken withAppVersion:(NSString *)version;
- (void)checkAppIfExpiration:(id)target selector:(SEL)selector_;
//end

- (NSString *)getDataURL;
- (NSString *)getImageURL;
- (NSString *)getFileURL;

- (void)getDeviceStatus:(id)target delegate:(SEL)delegate deviceID:(NSString *)deviceID;

- (void)signUp:(id)target delegate:(SEL)delegate clientId:cId userName:(NSString *)userName userCode:(NSString *)userCode contact:(NSString *)contact email:(NSString *)email phone:(NSString *)phone;

- (void)login:(id)target delegate:(SEL)delegate clientId:cId accountID:(NSString *)accountId password:(NSString *)password;

- (void)sync:(id)target delegate:(SEL)delegate;

@end
