//
//  FMainMenuViewController.m
//  Showcase_FD
//
//  Created by august on 12-3-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FMainMenuViewController.h"
#import "Constants.h"
#import "FDProductCatalogModel.h"

#define GROUPFONTSIZE 20.0
#define MAINMENUFONTSIZE 17.0
FMainMenuViewController *_shareInstance = nil;
@implementation FMainMenuViewController
@synthesize delegate;
@synthesize isShown;
@synthesize menu_Dic;

//init
+ (FMainMenuViewController *)shareInstance{
    if (!_shareInstance) {
        _shareInstance = [[FMainMenuViewController alloc] init];
    }
    return _shareInstance;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (id)init
{
    self = [super init];
    if (self) {
        
        [[NSNotificationCenter defaultCenter] addObserverForName:NOTIFICATION_FD_FINISHED_SYNC object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note){
            
            [self.menu_Dic removeAllObjects];
            self.menu_Dic = [[DataManagerModel sharedDataModel]  getAllCatagoriesToDictionary];
            [groupTableView reloadData];
            [catagoryTableView reloadData];
            [self getMenuItems];
        }];
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

// added by Alex @ 2012.4.27
- (void)getMenuItems
{
    //init data
    self.menu_Dic = [[DataManagerModel sharedDataModel]  getAllCatagoriesToDictionary];
    //self.selected_Dic = [NSMutableDictionary dictionaryWithCapacity:0];
    //add "全部房型"
    NSMutableArray *catalog_array = [self.menu_Dic objectForKey:ROOM];
    if ([catalog_array count]) {
        FDProductCatalogEntity *tempcatalog = [[FDProductCatalogEntity alloc] init];
        tempcatalog.catalogID = 0;
        tempcatalog.name = @"全部房型";
        tempcatalog.type = ROOM;
        tempcatalog.order = 0;
        [catalog_array insertObject:tempcatalog atIndex:0];
        [tempcatalog release];  
        
        //default selected "全部房型"
        [groupTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
    }
    //end
}
//

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (!isShown) {
        [sliderBtn setImage:[UIImage imageNamed:@"arrow-rgt.png"] forState:UIControlStateNormal];
    }else{
        [sliderBtn setImage:[UIImage imageNamed:@"arrow-lft.png"] forState:UIControlStateNormal];
    }
    
    [self getMenuItems];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    groupTableView = nil;
    catagoryTableView = nil;
    //clean up
    [menu_Dic removeAllObjects];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}


- (void)dealloc {
    [menu_Dic release];
    [groupTableView release];
    [catagoryTableView release];
    [super dealloc];
}

#pragma mark ----
#pragma mark function
- (void)refreshView{
    [groupTableView reloadData];
    [catagoryTableView reloadData];
    //default selected "全部房型"
    [groupTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
    [self.delegate didselectedMenu:[NSDictionary dictionaryWithObject:[NSNumber numberWithInt:0] forKey:ROOM]];
}

- (IBAction)sliderAction:(id)sender{
    
    if ((isShown=!isShown)) {
        [sliderBtn setImage:[UIImage imageNamed:@"arrow-lft.png"] forState:UIControlStateNormal];
        
    }else{
        [sliderBtn setImage:[UIImage imageNamed:@"arrow-rgt.png"] forState:UIControlStateNormal];
    }
    [self refreshView];
    [self.delegate slideMenuAction:isShown];
}

- (void)selectStyle:(int)styleID
{
    [catagoryTableView reloadData];
    
    NSMutableDictionary *selected_Dic = [NSMutableDictionary dictionaryWithCapacity:0];
    NSMutableArray *arrayStyle = [menu_Dic objectForKey:STYLE];
    int row = 0;
    for (FDProductCatalogEntity *proEntiry in arrayStyle) 
    {
        if(proEntiry.catalogID == styleID)
        {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
            [catagoryTableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
            FDProductCatalogEntity *catalogEntity = [arrayStyle objectAtIndex:indexPath.row];
            [selected_Dic setObject:[NSNumber numberWithInt:catalogEntity.catalogID] forKey:STYLE];
            [self.delegate didselectedMenu:selected_Dic];
            break;
        }
        
        row++;
    }
    
}

#pragma mark ---
#pragma mark tableview delegate and datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (tableView==groupTableView) {
        return [[menu_Dic objectForKey:ROOM] count];
    }else{
        return [[menu_Dic objectForKey:STYLE] count];
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (tableView==groupTableView) {
        static NSString *cellIdentifier = @"groupView";
        
        UITableViewCell *groupCell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (groupCell == nil) {
            groupCell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
            UIImageView *selectedView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"navon-bg.png"]];
            groupCell.selectedBackgroundView = selectedView;
            [selectedView release];
            //set cell
            [groupCell.textLabel setNumberOfLines:0];
            [groupCell.textLabel setFont:[UIFont systemFontOfSize:GROUPFONTSIZE]];
            [groupCell.textLabel setTextAlignment:UITextAlignmentCenter];
            [groupCell.textLabel setTextColor:[UIColor lightGrayColor]];
            groupCell.textLabel.highlightedTextColor = RGBCOLOR(132,187,59,1);
        }
        NSMutableArray *group_array = [menu_Dic objectForKey:ROOM];
        if ([group_array count]) {
            FDProductCatalogEntity *catalogEntity = [group_array objectAtIndex:indexPath.row];
            NSString *name_ = catalogEntity.name;
            NSMutableString *mutableString = [[NSMutableString alloc] initWithCapacity:0];
            for (int i=0; i<name_.length; i++) {
                NSRange range = NSMakeRange(i, 1);
                NSString *tempstr = [[name_ substringWithRange:range] stringByAppendingString:@"\n"];
                [mutableString appendString:tempstr];
            }
            groupCell.textLabel.text = mutableString;
            [mutableString release];
        }
        
        return groupCell;
        
    }else{
        
        static NSString *cellIdentifier = @"category";
        
        UITableViewCell *categoryCell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (categoryCell == nil) {
            categoryCell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                                   reuseIdentifier:cellIdentifier] autorelease];
            UIImageView *lineView = [[UIImageView alloc] initWithFrame:CGRectMake(2, tableView.rowHeight-1, tableView.frame.size.width-5, 2)];
            lineView.image = [UIImage imageNamed:@"dividerline.png"];
            [categoryCell.contentView addSubview:lineView];
            [lineView release];
            categoryCell.textLabel.textColor = [UIColor grayColor];
            categoryCell.textLabel.textAlignment = UITextAlignmentCenter;
            categoryCell.textLabel.font = [UIFont systemFontOfSize:18];
            
            [categoryCell setSelectionStyle:UITableViewCellSelectionStyleGray];
            UIImageView *selectedView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"news-selectbg.png"]];
            categoryCell.selectedBackgroundView = selectedView;
            [selectedView release];
        }
        NSMutableArray *style_array = [menu_Dic objectForKey:STYLE];
        if ([style_array count]) {
            
            FDProductCatalogEntity *catalogEntity = [style_array objectAtIndex:indexPath.row];
            NSString *txName = catalogEntity.name;
            if(catalogEntity.code && catalogEntity.code.length > 0)
                txName = [txName stringByAppendingFormat:@"-%@", catalogEntity.code];
            
            categoryCell.textLabel.text = txName;
            
        };
        return categoryCell;
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSMutableDictionary *selected_Dic = [NSMutableDictionary dictionaryWithCapacity:0];
    
    if (tableView==groupTableView) {
        
        [catagoryTableView reloadData];
        currentSytleCode = 0;
        [selected_Dic setObject:[NSNumber numberWithInt:currentSytleCode] forKey:STYLE];
        
        NSMutableArray *group_array = [menu_Dic objectForKey:ROOM];
        
        if ([group_array count]) {
            
            FDProductCatalogEntity *catalogEntity = [group_array objectAtIndex:indexPath.row];
            
//            if (currentRoomCode!=catalogEntity.catalogID) {
                currentRoomCode = catalogEntity.catalogID;
                
                [selected_Dic setObject:[NSNumber numberWithInt:currentRoomCode] forKey:ROOM];
                [self.delegate didselectedMenu:selected_Dic];
//            }
            
        }
        
    }else{
        
        NSMutableArray *style_array = [menu_Dic objectForKey:STYLE];
        
        if ([style_array count]) {
            
            FDProductCatalogEntity *catalogEntity = [style_array objectAtIndex:indexPath.row];
            
//            if (currentSytleCode!=catalogEntity.catalogID) {
                
                currentSytleCode = catalogEntity.catalogID;
                
                [selected_Dic setObject:[NSNumber numberWithInt:currentSytleCode] forKey:STYLE];
                if (currentRoomCode!=0) {
                    [selected_Dic setObject:[NSNumber numberWithInt:currentRoomCode] forKey:ROOM];
                }
                
                [self.delegate didselectedMenu:selected_Dic];
//            }
            
        }
        
    }
    
    
}

@end
