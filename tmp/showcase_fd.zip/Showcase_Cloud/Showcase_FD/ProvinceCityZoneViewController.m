//
//  ProvinceCityZoneViewController.m
//  Showcase_FD
//
//  Created by Yue Gu on 4/9/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import "ProvinceCityZoneViewController.h"

#import "ProvinceEntity.h"
#import "CityEntity.h"
#import "ZoneEntity.h"

@interface ProvinceCityZoneViewController ()

@end

@implementation ProvinceCityZoneViewController

@synthesize items = _itemsOfTypeString;

@synthesize delegate = _delegate;

@synthesize tag = _tag;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [_itemsOfTypeString release];
    
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [[self items] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell)
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    
    // Configure the cell...
    id item = [[self items] objectAtIndex:[indexPath row]];
    NSString * textString = nil;
    if ([item isKindOfClass:[NSString class]]) textString = (NSString *)item;
    else if ([item isKindOfClass:[ProvinceEntity class]]) textString = [(ProvinceEntity *)item name];
    else if ([item isKindOfClass:[CityEntity class]]) textString = [(CityEntity *)item name];
    else if ([item isKindOfClass:[ZoneEntity class]]) textString = [(ZoneEntity *)item name];
    [[cell textLabel] setText:textString];
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[self delegate] provinceCityZoneViewController:self didSelectItem:[[self items] objectAtIndex:[indexPath row]]];
}

@end
