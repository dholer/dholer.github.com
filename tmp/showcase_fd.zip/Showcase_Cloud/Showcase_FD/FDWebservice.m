//
//  NovelDataSources.m
//  Novel
//
//  Created by apple on 10-8-17.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "FDWebservice.h"
#import "ModalAlert.h"
#import "UIDevice+IdentifierAddition.h"
static FDWebservice *_shareInstanceOrderingSync = nil;

@implementation FDWebservice

@synthesize connSEL,sesseionId,tmpData;
@synthesize theConnection;

- (id)init{
	if((self=[super init]))
	{
		
	} 
	return self;
}


#pragma mark -
#pragma mark sington
+ (FDWebservice *) sharedInstance
{
	if (_shareInstanceOrderingSync == nil)
	{
		_shareInstanceOrderingSync = [[FDWebservice alloc] init];
	}
	return _shareInstanceOrderingSync;
}


#pragma mark --------
- (NSURL *)getUrlBystrUrl:(NSString *)strpath
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *baseUrl=[defaults stringForKey:@"DataIP_preference"];
	if (baseUrl==nil) {
        [defaults setObject:SEVERURL forKey:@"DataIP_preference"];
		baseUrl=SEVERURL;
	}
	int port=[defaults integerForKey:@"Dataport_preference"];
	if (port==0) {
		port=SEVERPORT;
	}
	NSString *websitePath=[defaults stringForKey:@"DatawebsitePath_preference"];
	if (websitePath==nil) {
		websitePath=MainPath;
	}
	NSString *url=[NSString stringWithString:[NSString stringWithFormat:@"http://%@:%d/%@/%@",baseUrl,port,websitePath,strpath]];
	url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	NSURL *nsurl = [NSURL URLWithString:[self getRandomParam:url]];
	return nsurl;
}

- (BOOL)userHasRegistered
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str = [defaults stringForKey:@"userHasRegistered_preference"];
	if (str == nil) {
		return NO;
	}
	return [defaults boolForKey:@"userHasRegistered_preference"];
}
- (void)setUserHasRegistered:(BOOL)userHasRegistered
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:[NSNumber numberWithBool:userHasRegistered] forKey:@"userHasRegistered_preference"];
	[defaults synchronize];
}

- (BOOL)userHasSynced
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str = [defaults stringForKey:@"userHasSynced_preference"];
	if (str == nil) {
		return NO;
	}
	return [defaults boolForKey:@"userHasSynced_preference"];
}
- (void)setUserHasSynced:(BOOL)userHasSynced
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:[NSNumber numberWithBool:userHasSynced] forKey:@"userHasSynced_preference"];
	[defaults synchronize];
}

- (NSString *)lastSyncDate
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults stringForKey:@"lastSyncDate_preference"];
}
- (void) setLastSyncDate:(NSString *)lastSyncDate
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:lastSyncDate forKey:@"lastSyncDate_preference"];
	[defaults synchronize];
}

- (int)inDate
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults integerForKey:@"inDate_preference"];
}
- (void)setInDate:(int)inDate
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:[NSNumber numberWithInt:inDate] forKey:@"inDate_preference"];
	[defaults synchronize];
}

- (BOOL)needToRegisterWithoutDeleteApp
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str = [defaults stringForKey:@"needToRegisterWithoutDeleteApp_preference"];
	if (str == nil) {
		return NO;
	}
	return [defaults boolForKey:@"needToRegisterWithoutDeleteApp_preference"];
}
- (void)setNeedToRegisterWithoutDeleteApp:(BOOL)needToRegisterWithoutDeleteApp
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:[NSNumber numberWithBool:needToRegisterWithoutDeleteApp] forKey:@"needToRegisterWithoutDeleteApp_preference"];
	[defaults synchronize];
}

// order detail items cache
- (NSString *)store
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str=[defaults stringForKey:@"store_preference"];
	if (str==nil) {
		str=@"";
	}
	return [NSString stringWithFormat:@"%@",str];
}

-(void)setStore:(NSString *)store
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:store forKey:@"store_preference"];
	[defaults synchronize];
}
- (NSString *)phone
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str=[defaults stringForKey:@"phone_preference"];
	if (str==nil) {
		str=@"";
	}
	return [NSString stringWithFormat:@"%@",str];
}

-(void)setPhone:(NSString *)phone
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:phone forKey:@"phone_preference"];
	[defaults synchronize];
}
- (NSString *)shoppingGuide
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str=[defaults stringForKey:@"shoppingGuide_preference"];
	if (str==nil) {
		str=@"";
	}
	return [NSString stringWithFormat:@"%@",str];
}

-(void)setShoppingGuide:(NSString *)shoppingGuide
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:shoppingGuide forKey:@"shoppingGuide_preference"];
	[defaults synchronize];
}
- (NSString *)province
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str=[defaults stringForKey:@"province_preference"];
	if (str==nil) {
		str=@"";
	}
	return [NSString stringWithFormat:@"%@",str];
}

-(void)setProvince:(NSString *)province
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:province forKey:@"province_preference"];
	[defaults synchronize];
}
- (NSString *)city
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str=[defaults stringForKey:@"city_preference"];
	if (str==nil) {
		str=@"";
	}
	return [NSString stringWithFormat:@"%@",str];
}

-(void)setCity:(NSString *)city
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:city forKey:@"city_preference"];
	[defaults synchronize];
}
- (NSString *)zone
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str=[defaults stringForKey:@"zone_preference"];
	if (str==nil) {
		str=@"";
	}
	return [NSString stringWithFormat:@"%@",str];
}

-(void)setZone:(NSString *)zone
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:zone forKey:@"zone_preference"];
	[defaults synchronize];
}
- (NSString *)address
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str=[defaults stringForKey:@"address_preference"];
	if (str==nil) {
		str=@"";
	}
	return [NSString stringWithFormat:@"%@",str];
}

-(void)setAddress:(NSString *)address
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:address forKey:@"address_preference"];
	[defaults synchronize];
}
- (NSString *)requirements
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str=[defaults stringForKey:@"requirements_preference"];
	if (str==nil) {
		str=@"";
	}
	return [NSString stringWithFormat:@"%@",str];
}

-(void)setRequirements:(NSString *)requirements
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:requirements forKey:@"requirements_preference"];
	[defaults synchronize];
}
//

- (NSString *)getUserId
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *userID=[defaults stringForKey:@"userID_preference"];
	if (userID==nil) {
		userID=@"";
	}
	return [NSString stringWithFormat:@"%@",userID];
}

-(void)setUserId:(NSString *)userID{
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:userID forKey:@"userID_preference"];
	[defaults synchronize];
}

- (NSString *)getClientId{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *cid=[defaults stringForKey:@"clientId_preference"];
	if (cid==nil) {
		cid=@"";
	}
	return [NSString stringWithFormat:@"%@",cid];
}

-(void)setClientId:(NSString *)cid{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:cid forKey:@"clientId_preference"];
	[defaults synchronize];
}


- (NSString *)getPassword{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *password=[defaults stringForKey:@"password_preference"];
	if (password==nil) {
		password=@"";
	}
	return [NSString stringWithFormat:@"%@",password];
}

-(void)setPassword:(NSString *)pswd{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:pswd forKey:@"password_preference"];
	[defaults synchronize];
}

- (BOOL)getLoginMode
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *str = [defaults stringForKey:@"LoginMode_preference"];
	if (str == nil) {
		return YES;
	}
	return [defaults boolForKey:@"LoginMode_preference"];     
}

-(void)setLoginMode:(BOOL)isonline{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:[NSNumber numberWithBool:isonline] forKey:@"LoginMode_preference"];
	[defaults synchronize];
}


-(NSString *)getMailAddress{
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *baseUrl=[defaults stringForKey:@"DirectorTitle_perference"];
	
	return baseUrl;
}

-(void)setMailAddress:(NSString *)address{
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:address forKey:@"DirectorTitle_perference"];
	[defaults synchronize];
}
	
-(NSString *)getLanguage{
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *language_str=[defaults stringForKey:@"lan_perference"];
	if(language_str==nil){
		language_str = LANGUAGE_ZH;
	}
	return language_str;
}

-(void)setLanguage:(NSString *)language_{
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:language_ forKey:@"lan_perference"];
	[defaults synchronize];
}

- (NSString *)getDataURL
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *baseUrl=[defaults stringForKey:@"DataIP_preference"];
	if (baseUrl==nil) {
        [defaults setObject:SEVERURL forKey:@"DataIP_preference"];
		baseUrl=SEVERURL;
	}
	int port=[defaults integerForKey:@"Dataport_preference"];
	if (port==0) {
        [defaults setObject:[NSNumber numberWithInt:SEVERPORT] forKey:@"Dataport_preference"];
		port=SEVERPORT;
	}
	NSString *websitePath=[defaults stringForKey:@"DatawebsitePath_preference"];
	if (websitePath==nil) {
        [defaults setObject:MainPath forKey:@"DatawebsitePath_preference"];
		websitePath=MainPath;
	}
	NSString *dataURLString = [NSString stringWithFormat:@"http://%@:%d/%@/", baseUrl, port,websitePath];
	dataURLString = [dataURLString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	return dataURLString;

}
- (NSString *)getImageURL
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *baseUrl=[defaults stringForKey:@"PicIP_preference"];
	if (baseUrl==nil) {
        [defaults setObject:SEVERURL forKey:@"PicIP_preference"];
		baseUrl=SEVERURL;
	}
	NSString *websitePath=[defaults stringForKey:@"PicwebsitePath_preference"];
	if (websitePath==nil) {
		websitePath=MainPath;
	}
	NSString *url=[NSString stringWithString:[NSString stringWithFormat:@"http://%@/%@/",baseUrl,websitePath]];
	url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	return url;

}
- (NSString *)getFileURL
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *baseUrl=[defaults stringForKey:@"FileIP_preference"];
	if (baseUrl==nil) {
        [defaults setObject:SEVERURL forKey:@"FileIP_preference"];
		baseUrl=SEVERURL;
	}
	NSString *websitePath=[defaults stringForKey:@"FilewebsitePath_preference"];
	if (websitePath==nil) {
		websitePath=@"fdchina/images/notice";
	}
	NSString *url=[NSString stringWithString:[NSString stringWithFormat:@"http://%@/%@/",baseUrl,websitePath]];
	url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	return url;

}

- (void)getDeviceStatus:(id)target delegate:(SEL)delegate deviceID:(NSString *)deviceID
{
    targetobject = target;
    connSEL = delegate;
    NSString *cid = [self getClientId];
    NSString *str = [NSString stringWithFormat:SYNC_FD_GET_DEVICE_STATUS, [self getDataURL], cid, deviceID];
    str = [str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url = [NSURL URLWithString:str];
    [self syncDataFromRemoting:self delegate:delegate url:url];
}

- (void)signUp:(id)target delegate:(SEL)delegate clientId:cId userName:(NSString *)userName userCode:(NSString *)userCode contact:(NSString *)contact email:(NSString *)email phone:(NSString *)phone 
{
    targetobject=target;
	connSEL=delegate;
    NSString *deviceId = [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier];
    NSString *str = [NSString stringWithFormat:SYNC_FD_USER_REGISTER, [self getDataURL], cId, deviceId, userName, userCode, contact, email, phone];
    str = [str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	NSURL *url = [NSURL URLWithString:str];
	[self syncDataFromRemoting:self delegate:delegate url:url];
}

- (void)login:(id)target delegate:(SEL)delegate clientId:cId accountID:(NSString *)accountID password:(NSString *)password {
    targetobject=target;
	connSEL=delegate;
    NSString *deviceId = [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier];
    NSLog(@"%@", deviceId);
    NSString *str = [NSString stringWithFormat:SYNC_FD_USER_LOGIN, [self getDataURL], cId, accountID, deviceId, password];
    str = [str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	NSURL *url = [NSURL URLWithString:str];
    NSLog(@"%@", str);
	[self syncDataFromRemoting:self delegate:delegate url:url];    
}


-(void)cancelConnection{
	if(theConnection)
	[self.theConnection cancel];
}

//add by august 2011-12-20
- (void)uploadDeviceToken:(id)target selector:(SEL)selector_ withDeviceToken:(NSString *)deviceToken withAppVersion:(NSString *)version{
    targetobject=target;
	connSEL=selector_;
    NSURL *url = [self getUrlBystrUrl:[NSString stringWithFormat:UploadDeviceTokenRequestURL,[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier],deviceToken,version]];
	[self syncDataFromRemoting:self delegate:selector_ url:url];
}

- (void)checkAppIfExpiration:(id)target selector:(SEL)selector_ {
    targetobject=target;
	connSEL=selector_;
	NSURL *url = [self getUrlBystrUrl:[NSString stringWithFormat:CheckAppExpirationRequestURL,[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]]];
	[self syncDataFromRemoting:self delegate:selector_ url:url];

}
//end

#pragma mark -
#pragma mark Common Module
-(NSString *) getRandomParam:(NSString *)url{
	NSRange foundRange= [url rangeOfString:@"?"];
    if (foundRange.location != NSNotFound) {
		return [url stringByAppendingFormat:@"&r=%d",rand()];
	}
	else{
		return [url stringByAppendingFormat:@"?r=%d",rand()];
	}
}

- (void)syncDataFromRemoting:(id)target delegate:(SEL)delegate url:(NSURL *)url
{
	NSURLRequest *request=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120.0]; 
	self.theConnection=[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSAssert(self.theConnection != nil, @"Failure to create URL connection.");
	
}


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response  {
    NSMutableData *t=[[NSMutableData alloc] initWithLength:0];
    self.tmpData=t;
    [t release];
}

- (void)connection:(NSURLConnection *)connection  didReceiveData:(NSData *)data {
	[self.tmpData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	NSLock *lock1= [[NSLock alloc] init];
	[lock1 lock];
	NSString *JSONString=[[NSString alloc] initWithData:tmpData encoding:NSUTF8StringEncoding];
	//NSLog(@"%@",JSONString);
	myData=[[JSONString JSONValue] retain];
	if (targetobject!=nil) {
		[targetobject performSelector:connSEL withObject:myData];
	}

	[JSONString release];
	[lock1 unlock];
	[lock1 release];
	self.theConnection = nil;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	
	if (targetobject!=nil) {
		[targetobject performSelector:connSEL withObject:nil];
	}
	[ModalAlert showAlertView:@"网络故障" withMessage:@"当前网络不稳定或已经断开，请稍后再试" withCancelBtn:@"确定"];
	self.theConnection = nil;
}

- (void)dealloc {
	[theConnection release];
    [tmpData release];
	[myData release];
	[super dealloc];
}

- (void)sync:(id)target delegate:(SEL)delegate
{
    [[FDWebservice sharedInstance] login:target delegate:delegate accountID:@"accountttt" password:@"passwordttt"];
}


@end
