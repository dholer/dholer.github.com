//
//  RegisterViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 3/28/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol RegisterViewControllerDelegate <NSObject>

- (void)dismissBackgroundViews;

@end

@interface RegisterViewController : UIViewController<UITextFieldDelegate, UIAlertViewDelegate> 
{
    UITextField *nameTextField;
    UITextField *numberTextField;
    UITextField *personTextField;
    UITextField *phoneTextField;
    UITextField *emailTextField;
    UITextField *cIdTextField;
}

@property (nonatomic, assign) id <RegisterViewControllerDelegate> delegate;

@end
