//
//  NewsViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 12-3-20.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsViewController : UIViewController

@end
