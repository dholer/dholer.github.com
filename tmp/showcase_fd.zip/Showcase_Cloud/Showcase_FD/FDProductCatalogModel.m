//
//  FDProductCatalogModel.m
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "FDProductCatalogModel.h"


@implementation FDProductCatalogModel

@synthesize delegate = _delegate;

- (BOOL)synchronizeWithProductCatalogEntities:(NSArray *)productCatalogEntities
{
    for (FDProductCatalogEntity *productCatalogEntity in productCatalogEntities) {
        [self addProductCatalogEntity:productCatalogEntity];
    }
    return YES;
}

- (BOOL)synchronizeWithRemoteJson:(id)remoteJson
{
    [[self delegate] productCatalogModelSyncFinished:self];
    return NO;
}

- (BOOL)addProductCatalogEntity:(FDProductCatalogEntity *)productCatalogEntity
{
    NSString *sql = [NSString stringWithFormat:@"INSERT OR REPLACE INTO %@ (%@, %@, %@, %@, %@, %@, %@, %@, %@) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", 
                     CATALOG_TABLE_NAME, 
                     CATALOG_COLUMN_NAME_CATALOG_ID, 
                     CATALOG_COLUMN_NAME_NAME, 
                     CATALOG_COLUMN_NAME_TYPE, 
					 CATALOG_COLUMN_NAME_CODE, 
                     CATALOG_COLUMN_NAME_ORDER, 
                     CATALOG_COLUMN_NAME_CREATED_TIME, 
                     CATALOG_COLUMN_NAME_CREATED_BY, 
                     CATALOG_COLUMN_NAME_UPDATED_TIME, 
                     CATALOG_COLUMN_NAME_UPDATED_BY

                     ];
	NSArray *argArray = [NSArray arrayWithObjects: 
                         [NSNumber numberWithInt:[productCatalogEntity catalogID]], 
                         [productCatalogEntity name] ? [productCatalogEntity name] : @"", 
                         [productCatalogEntity type] ? [productCatalogEntity type] : @"", 
                         [productCatalogEntity code] ? [productCatalogEntity code] : @"", 
                         [NSNumber numberWithInt:[productCatalogEntity order]],
                         [productCatalogEntity createdTime] ? [productCatalogEntity createdTime] : @"",
                         [productCatalogEntity createdBy] ? [productCatalogEntity createdBy] : @"", 
                         [productCatalogEntity updatedTime] ? [productCatalogEntity updatedTime] : @"",
                         [productCatalogEntity updatedBy] ? [productCatalogEntity updatedBy] : @"",  
                         nil];
	FMDatabase *db = [FMDatabase sharedDataBase];
	BOOL result = [db executeUpdate:sql withArgumentsInArray:argArray];
	
	return result;
}


@end
