//
//  MainProductListViewController.m
//  Showcase_FD
//
//  Created by august on 12-3-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//
#import "MainProductListViewController.h"
#define VIEWGAP 55.f
#define LEFTGAP 53.f
#define TOPGAP  35.f
@implementation MainProductListViewController
@synthesize productlist_delegate;
@synthesize productsScrollview;
@synthesize dictPoint;
@synthesize wideShow;

- (id)initWithFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        MainProductScrollview *tmpProductsScrollview=[[MainProductScrollview alloc] initWithFrame:frame];
		tmpProductsScrollview.autoresizingMask = UIViewAutoresizingNone;
        tmpProductsScrollview.backgroundColor=[UIColor clearColor];
        tmpProductsScrollview.showsHorizontalScrollIndicator=NO;
        tmpProductsScrollview.showsVerticalScrollIndicator=NO;
        tmpProductsScrollview.multipleTouchEnabled=YES;
        tmpProductsScrollview.userInteractionEnabled=YES;
        tmpProductsScrollview.delegate=self;
        self.productsScrollview=tmpProductsScrollview;
        [tmpProductsScrollview release];
        [self.view addSubview:self.productsScrollview]; 
        self.view.multipleTouchEnabled=YES;
		
		wideShow = NO;
		
        UIPinchGestureRecognizer *pinchRecognizer=[[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinch:)];
        [self.view addGestureRecognizer:pinchRecognizer];
        [pinchRecognizer release];
        
    }
    return self;
}


- (void)ProductListMove:(id)sender
{
    [UIView beginAnimations:@"move" context:nil];
    [UIView setAnimationDuration:0.2];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(ProductListFadout:)];

    for (int i=0;i<[self.productsScrollview.subviews count]; i++) {
        UIView *cell=(UIView *)[self.productsScrollview.subviews objectAtIndex:i];
        cell.center=openLocation;   
    }
    
    self.productsScrollview.alpha=0.0;
    [UIView commitAnimations];
}


- (void)ProductListFadout:(id)sender
{
    [self.productlist_delegate jrxProductListController:self doneProductSelect:nil];
    [self.view removeFromSuperview];
}


- (void)pinch:(UIPinchGestureRecognizer *)sender{
    
    if (sender.state == UIGestureRecognizerStateBegan)
    {
        [sender setScale:1.0f];
        lastscale=1.0f;
        touchCenter=self.productsScrollview.center;
    }
    if (sender.state == UIGestureRecognizerStateEnded)
    {
        if(sender.scale<0.75)
        {
            [UIView beginAnimations:@"fadout" context:nil];
            [UIView setAnimationDuration:0.3];
            [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
            [UIView setAnimationDelegate:self];
            [UIView setAnimationDidStopSelector:@selector(ProductListMove:)];
            for (int i=0;i<[self.productsScrollview.subviews count]; i++) {
                UIView *cell=(UIView *)[self.productsScrollview.subviews objectAtIndex:i];
                CGPoint lastPoint;
                CGPoint cellPoint=cell.center;
                
                CGFloat xdistance=ABS(cellPoint.x -touchCenter.x)*(0.01-lastscale);
                CGFloat ydistance=ABS(cellPoint.y -touchCenter.y)*(0.01-lastscale);
                if (cell.center.x<touchCenter.x) {
                    lastPoint.x=cell.center.x -xdistance;
                    
                    if (cell.center.y<touchCenter.y) {
                        lastPoint.y=cell.center.y -ydistance;
                    }
                    else
                    {
                        lastPoint.y=cell.center.y -ydistance;
                    }
                }
                else
                {
                    lastPoint.x=cell.center.x +xdistance;
                    
                    if (cell.center.y<touchCenter.y) {
                        lastPoint.y=cell.center.y -ydistance;
                    }
                    else
                    {
                        lastPoint.y=cell.center.y -ydistance;
                    }
                }
                cell.center=lastPoint;   
            }
            
            [UIView commitAnimations];
			
        }
        else
        {
           
            NSArray *tmpproductArray=self.productsScrollview.subviews;
            [UIView beginAnimations:@"move" context:nil];
            [UIView setAnimationDuration:0.2];
            [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
            for (int i=0; i<numberOfProducts; i++) {
//
//                CGRect rect = [self productSubviewChangeByIndex:i];
//                SingleProductView *oneProductview=[tmpproductArray objectAtIndex:i];
//                oneProductview.frame=rect;
            }
            [UIView commitAnimations];
        }
    }
    if (sender.state == UIGestureRecognizerStateChanged)
    {
        if (sender.scale<=1.0) {

            for (int i=0;i<[self.productsScrollview.subviews count]; i++) {
                UIView *cell=(UIView *)[self.productsScrollview.subviews objectAtIndex:i];
                CGPoint lastPoint;
                CGPoint cellPoint=cell.center;
				
                CGFloat xdistance=ABS(cellPoint.x -touchCenter.x)*(sender.scale-lastscale);
                CGFloat ydistance=ABS(cellPoint.y -touchCenter.y)*(sender.scale-lastscale);
                if (cell.center.x<touchCenter.x) {
                    lastPoint.x=cell.center.x -xdistance;
					
                    if (cell.center.y<touchCenter.y) {
                        lastPoint.y=cell.center.y -ydistance;
                    }
                    else
                    {
                        lastPoint.y=cell.center.y -ydistance;
                    }
                }
                else
                {
                    lastPoint.x=cell.center.x +xdistance;
					
                    if (cell.center.y<touchCenter.y) {
                        lastPoint.y=cell.center.y -ydistance;
                    }
                    else
                    {
                        lastPoint.y=cell.center.y -ydistance;
                    }
                }
                cell.center=lastPoint;   
            }
            lastscale=sender.scale;
            [self.view setNeedsDisplay];
        }      
    }   
}


-(void)viewTouchesMove:(CGFloat)rate lastdistance:(CGFloat)lastdistance
{
    if (rate<=1.0) {
		for (int i=0;i<[self.view.subviews count]; i++) {
            UIView *cell=(UIView *)[self.view.subviews objectAtIndex:i];
            CGPoint lastPoint;
            CGFloat xdistance=ABS(cell.center.x -touchCenter.x)*rate;
            CGFloat ydistance=ABS(cell.center.y -touchCenter.y)*rate;
            if (cell.center.x>touchCenter.x) {
                lastPoint.x=cell.center.x -xdistance;
                lastPoint.y=cell.center.y -ydistance;
            }
            cell.center=lastPoint;
        }
        
    }
    else
    {
        for (int i=0;i<[self.view.subviews count]; i++) {
            UIView *cell=(UIView *)[self.view.subviews objectAtIndex:i];
            CGPoint lastPoint;
            CGFloat xdistance=ABS(cell.center.x -touchCenter.x)*rate;
            CGFloat ydistance=ABS(cell.center.y -touchCenter.y)*rate;
            if (cell.center.x>touchCenter.x) {
                lastPoint.x=cell.center.x +xdistance;
                lastPoint.y=cell.center.y +ydistance;
            }
            cell.center=lastPoint;
            
        }
    }
}


- (void)modifySingleProductviewWidth{
    
    numberOfColumns = [productlist_delegate numberOfColumnsForProductListLandscape];
    
	self.productsScrollview.frame = self.view.bounds;
	if (wideShow){
		productsScrollview.contentSize=CGSizeMake(productsScrollview.frame.size.width,(numberOfRows+1) *(productsScrollview.frame.size.height +34.0));
	}else{
		productsScrollview.contentSize=CGSizeMake(productsScrollview.frame.size.width,(numberOfRows+1) *(productsScrollview.frame.size.height +34.0));
	}
	
	NSArray *cellarray=[self.productsScrollview subviews];

	for(int i = 0; i < [cellarray count]; i++){
//		SingleProductView *aCell = [cellarray objectAtIndex:i];
//		CGRect rect = [self productSubviewChangeByIndex:i];
//        [UIView animateWithDuration:0.3 animations:^(void){
//            aCell.alpha = 0.3;
//        }completion:^(BOOL finished){
//            aCell.frame = rect;
//            aCell.alpha = 1.0f;
//        }];
	}
    
}

- (CGRect)productSubviewChangeByIndex:(int)currentIndex{
    
    CGRect rect;
    if(wideShow)
        rect=CGRectMake((currentIndex % numberOfColumns)*(sizeOfProdcutCell.width+54)+50, (sizeOfProdcutCell.height+TOPGAP) *(currentIndex / numberOfColumns)+TOPGAP, sizeOfProdcutCell.width, sizeOfProdcutCell.height);
    else
        rect=CGRectMake((currentIndex % numberOfColumns)*(sizeOfProdcutCell.width+VIEWGAP)+LEFTGAP, (sizeOfProdcutCell.height +TOPGAP) *(currentIndex / numberOfColumns)+TOPGAP, sizeOfProdcutCell.width, sizeOfProdcutCell.height);
    return rect;
}


- (void)updateView:(NSString *)catalogID location:(CGPoint)location{
    
    //loading infomation
    openLocation=location;
	numberOfColumns = [productlist_delegate numberOfColumnsForProductListLandscape];
    numberOfProducts = [productlist_delegate numberOfProdcutsInView];  
    sizeOfProdcutCell=[productlist_delegate getSizeOfProdcutView];
	numberOfRows = numberOfProducts / numberOfColumns;
    //remove all subview
    [self.productsScrollview.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
	if (numberOfProducts % numberOfColumns)
		numberOfRows += 1;
	
	self.productsScrollview.frame = self.view.frame;
	
    if ((numberOfRows+1) *(sizeOfProdcutCell.height +34.0)<=self.productsScrollview.frame.size.height) {
        self.productsScrollview.contentSize=CGSizeMake(self.productsScrollview.frame.size.width,self.productsScrollview.frame.size.height+1);
    }else
    {
        self.productsScrollview.contentSize=CGSizeMake(self.productsScrollview.frame.size.width,(numberOfRows+1) *(sizeOfProdcutCell.height +34.0));
    }
	
    NSMutableArray *tmpproductArray=[[NSMutableArray alloc] initWithCapacity:numberOfProducts];
    
    self.productsScrollview.alpha=1.0;
    for (int i=0; i<numberOfProducts; i++) {
        CGRect rect = [self productSubviewChangeByIndex:i];
        FDProductEntity *productCatalogEntity=(FDProductEntity *)[self.productlist_delegate productEntityForIndex:i];
        SingleProductView *oneCatalogview=[[SingleProductView alloc] initWithFrame:rect withProductEntity:productCatalogEntity];
        oneCatalogview.tag=i;
        [self.productsScrollview addSubview:oneCatalogview];
        [oneCatalogview release];
    }
	
    [tmpproductArray release];
    
}


/*- (void)jrxProductListController:(MainProductListController *)jrxProductListController doneProductSelect:(ProductDetailEntity *)productEntity{
 self.productsScrollview.alpha=1.0;
 }
 
 
 -(void) jrxProductCell:(ProductSubView *)jrxProductCell didProductSelect:(ProductDetailEntity *)productEntity
 {
 [delegate jrxProductListController:self didProductSelect:productEntity];
 }*/


- (void)viewDidLoad {
    [super viewDidLoad];
    
}


- (void)dealloc
{
    [dictPoint release];
    [productsScrollview release];
    [super dealloc];
}


@end
