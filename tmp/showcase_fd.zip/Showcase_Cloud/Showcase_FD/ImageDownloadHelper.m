/*
 Erica Sadun, http://ericasadun.com
 iPhone Developer's Cookbook, 3.0 Edition
 BSD License, Use at your own risk
 */

#import "ImageDownloadHelper.h"

#define DELEGATE_CALLBACK(X, Y) if (sharedInstance.delegate && [sharedInstance.delegate respondsToSelector:@selector(X)]) [sharedInstance.delegate performSelector:@selector(X) withObject:Y];
#define NUMBER(X) [NSNumber numberWithFloat:X]

static ImageDownloadHelper *sharedInstance = nil;

@implementation ImageDownloadHelper
@synthesize response;
@synthesize data;
@synthesize delegate;
@synthesize urlString;
@synthesize urlconnection;
@synthesize isDownloading;
- (NSString *)getUrlBystrUrl:(NSString *)strpath
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *baseUrl=[defaults stringForKey:@"PicIP_preference"];
	if (baseUrl==nil) {
        [defaults setObject:SEVERURL forKey:@"PicIP_preference"];
		baseUrl=SEVERURL;
	}
	int port=[defaults integerForKey:@"Picport_preference"];
	if (port==0) {
		port=IMAGEPORT;
	}
	NSString *websitePath=[defaults stringForKey:@"PicwebsitePath_preference"];
	if (websitePath==nil) {
		websitePath=@"fdchina/images/products/";
	}
       // strpath=[NSString stringWithFormat:RequestProductImageURL,strpath];
	NSString *url=[NSString stringWithString:[NSString stringWithFormat:@"http://%@/%@/%@",baseUrl,websitePath,strpath]];
	url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	return  url;
}

- (NSString *)getProductImagePathByPath:(NSString *)filename{
    
    return [PRODUCT_IMAGE_SOURCE_PATH stringByAppendingFormat:@"/%@", filename];
 
}
- (void) start
{
	self.isDownloading = NO;
	
	NSURL *url = [NSURL URLWithString:self.urlString];
	if (!url)
	{
		NSString *reason = [NSString stringWithFormat:@"Could not create URL from string %@", self.urlString];
		DELEGATE_CALLBACK(dataDownloadFailed:, reason);
		return;
	}
	
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	if (!theRequest)
	{
		NSString *reason = [NSString stringWithFormat:@"Could not create URL request from string %@", self.urlString];
		DELEGATE_CALLBACK(dataDownloadFailed:, reason);
		return;
	}
	
	self.urlconnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
	if (!self.urlconnection)
	{
		NSString *reason = [NSString stringWithFormat:@"URL connection failed for string %@", self.urlString];
		DELEGATE_CALLBACK(dataDownloadFailed:, reason);
		return;
	}
	
	self.isDownloading = YES;
	
	// Create the new data object
	self.data = [NSMutableData data];
	self.response = nil;
	
	[self.urlconnection scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
	
}

- (void) cleanup
{
	[fileStream close];
	self.data = nil;
	self.response = nil;
	self.urlconnection = nil;
	self.urlString = nil;
	self.isDownloading = NO;
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)aResponse
{
	// store the response information
    self.response = (NSHTTPURLResponse*)aResponse;
	
	// Check for bad connection
	if ([aResponse expectedContentLength] < 0)
	{
		NSString *reason = [NSString stringWithFormat:@"Invalid URL [%@]", self.urlString];
		DELEGATE_CALLBACK(dataDownloadFailed:, reason);
		[connection cancel];
		[self cleanup];
		return;
	}
    
    if (404 == [self.response statusCode]) {
		NSString *reason = [NSString stringWithFormat:@"Invalid URL [%@]", self.urlString];
		self.isDownloading = NO;
		DELEGATE_CALLBACK(dataDownloadFailed:, reason);
		[connection cancel];
		[self cleanup];
		return;
	}
	
	NSString *filePath =[self getProductImagePathByPath:[aResponse suggestedFilename]];
	
	fileStream = [[NSOutputStream outputStreamToFileAtPath:filePath append:NO] retain];
	[fileStream open];
	
	if ([aResponse suggestedFilename])
		DELEGATE_CALLBACK(didReceiveFilename:, [aResponse suggestedFilename]);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)theData
{
	NSInteger       dataLength;
    const uint8_t * dataBytes;
    NSInteger       bytesWritten;
    NSInteger       bytesWrittenSoFar;
    
    dataLength = [theData length];
    dataBytes  = [theData bytes];
	
    bytesWrittenSoFar = 0;
    do {
        bytesWritten = [fileStream write:&dataBytes[bytesWrittenSoFar] maxLength:dataLength - bytesWrittenSoFar];
        if (bytesWritten == -1) {
            break;
        } else {
            bytesWrittenSoFar += bytesWritten;
        }
    } while (bytesWrittenSoFar != dataLength);
	
	// append the new data and update the delegate
	[self.data appendData:theData];
	if (self.response)
	{
		float expectedLength = [self.response expectedContentLength];
		float currentLength = self.data.length;
		float percent = currentLength / expectedLength;
		DELEGATE_CALLBACK(dataDownloadAtPercent:, NUMBER(percent));
	}
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	// finished downloading the data, cleaning up
	self.response = nil;
	[self cleanup];
    [self.urlconnection unscheduleFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
	// Delegate is responsible for releasing data
	if (self.delegate)
	{
		NSData *theData = [self.data retain];
		DELEGATE_CALLBACK(didReceiveData:, theData);
	}
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	self.isDownloading = NO;
	DELEGATE_CALLBACK(dataDownloadFailed:, @"Failed Connection");
	[self cleanup];
}

+ (ImageDownloadHelper *) sharedInstance
{
	if(!sharedInstance) sharedInstance = [[ImageDownloadHelper alloc] init];
    return sharedInstance;
}

+ (void) download:(NSString *) aURLString {
	if ([ImageDownloadHelper sharedInstance].isDownloading)
	{
		DELEGATE_CALLBACK(dataDownloadFailed:, @"");
		return;
	}
	[ImageDownloadHelper sharedInstance].urlString = [[ImageDownloadHelper sharedInstance] getUrlBystrUrl:aURLString];
	[[ImageDownloadHelper sharedInstance] start];
}

+ (void) cancel
{
	if (sharedInstance.isDownloading) [sharedInstance.urlconnection cancel];
}
@end
