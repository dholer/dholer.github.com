//
//  SyncDataMngController.m
//  iPadSales
//
//  Created by Yue Gu on 12-3-4.
//  Copyright 2012 Logic Solutions, Inc. All rights reserved.
//

#import "SyncViewController.h"
#import "ModalAlert.h"
#import "FDWebservice.h"
#import "DataManagerModel.h"
#import "UIDevice+IdentifierAddition.h"
#import "Constants.h"
#import "ImageDownloadHelper.h"
#import "DownloadManager.h"
#import "FDProductModel.h"
#import "FDFileModel.h"
#import "NSURL+Download.h"

#define NOTINAME @"TABLEDOWN"
#define COMPLETION_TOTAL 3

#define ALERTVIEWIMAGESTAG 100001

@interface SyncViewController () <UIAlertViewDelegate, ImageDownloadHelperDelegate, DownloadManagerDelegate, FDProductModelDelegate, FDFileModelDelegate>

@property (retain, nonatomic) IBOutlet UIButton *syncButton;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicatorView;
@property (retain, nonatomic) IBOutlet UIProgressView *dataProgressView;
@property (retain, nonatomic) IBOutlet UIProgressView *imageProgressView;
@property (retain, nonatomic) IBOutlet UIProgressView *pdfProgressView;
@property (retain, nonatomic) IBOutlet UILabel *dataProgressLabel;
@property (retain, nonatomic) IBOutlet UILabel *imageProgressLabel;
@property (retain, nonatomic) IBOutlet UILabel *pdfProgressLabel;

@property (nonatomic) int dataTotal;
@property (nonatomic) int imageTotal;
@property (nonatomic) int fileTotal;
@property (nonatomic) int currentDataIndex;
@property (nonatomic) int currentImageIndex;
@property (nonatomic) int currentFileIndex;
@property (nonatomic) BOOL productHasSynced;

@property (nonatomic) int currentCompletionFlag;

@property (retain) NSMutableArray *imagesToDownload;
@property (retain) NSMutableArray *filesToDownload;

-(IBAction)syncButtonPressed:(id)sender;

@end

@implementation SyncViewController

@synthesize syncButton;
@synthesize activityIndicatorView;
@synthesize dataProgressView;
@synthesize imageProgressView;
@synthesize pdfProgressView;
@synthesize dataProgressLabel;
@synthesize imageProgressLabel;
@synthesize pdfProgressLabel;

@synthesize dataTotal;
@synthesize imageTotal;
@synthesize fileTotal;
@synthesize currentDataIndex;
@synthesize currentImageIndex;
@synthesize currentFileIndex;
@synthesize productHasSynced;

@synthesize currentCompletionFlag;

@synthesize imagesToDownload;
@synthesize filesToDownload;

#pragma mark - GUI interactions

-(IBAction)syncButtonPressed:(id)sender
{
    NSString *cid = [[FDWebservice sharedInstance] getClientId];
	[[FDWebservice sharedInstance] login:self delegate:@selector(userLoginFinished:) clientId:cid accountID:[[FDWebservice sharedInstance] getUserId] password:[[FDWebservice sharedInstance] getPassword]];
}

- (void)userLoginFinished:(id)loginData
{
    NSLog(@"%@", loginData);
    if (loginData != NULL && loginData != nil) {
		
		NSString *status=[[[loginData objectForKey:@"results"] objectAtIndex:0] objectForKey:@"status"];
        if ([status isEqualToString:@"217"]) {
            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"错误"
                                                             message:@"帐号已过期，请联系管理员！" 
                                                            delegate:self
                                                   cancelButtonTitle:nil
                                                   otherButtonTitles:@"确定", nil] autorelease];
            [alert show];
            return;
        }
		if ([status isEqualToString:@"200"]) {
            NSString *sessionid = [[loginData objectForKey:@"content"] objectForKey:@"sessionId"];
            NSString *lastSyncDate = [[[loginData objectForKey:@"content"] objectForKey:@"user"] objectForKey:@"lastSyncDate"];
            int inDate = [[[[loginData objectForKey:@"content"] objectForKey:@"user"] objectForKey:@"inDate"] intValue];
            NSString *userID = [[[loginData objectForKey:@"content"] objectForKey:@"user"] objectForKey:@"account"];
            NSString *password = [[[loginData objectForKey:@"content"] objectForKey:@"user"] objectForKey:@"password"];
            [[FDWebservice sharedInstance] setSesseionId:sessionid];
            [[FDWebservice sharedInstance] setLastSyncDate:lastSyncDate];
            [[FDWebservice sharedInstance] setInDate:inDate];
            [[FDWebservice sharedInstance] setUserId:userID];
            [[FDWebservice sharedInstance] setPassword:password];
		}
        else if ([status isEqualToString:@"208"]) {
            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"错误"
                                                             message:@"设备尚未激活，请及时查收邮件！" 
                                                            delegate:self
                                                   cancelButtonTitle:nil
                                                   otherButtonTitles:@"确定", nil] autorelease];
            [alert show];
            return;
        }
        else if ([status isEqualToString:@"201"]) {
            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"错误"
                                                             message:@"当前帐号不存在，请从新申请" 
                                                            delegate:self
                                                   cancelButtonTitle:nil
                                                   otherButtonTitles:@"确定", nil] autorelease];
            [alert setTag:19998];
            [alert show];
            return;
        }
        else {
            
		  //background sync failed,show login view
            [self triggerUIAlertView];
//            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"错误"
//                                                             message:@"帐号或密码错误！" 
//                                                            delegate:self
//                                                   cancelButtonTitle:nil
//                                                   otherButtonTitles:@"确定", nil] autorelease];
//            [alert show];
            return;
        }
        //login successfully then sync product data
        [self syncProducts];
        [self startIndictorView];
	}
}

#pragma mark - download data

- (void)syncFiles
{
    FDFileModel *model = [[[FDFileModel alloc] init] autorelease];
    [model setDelegate:self];
    [model syncFiles];
}

- (void)syncProducts
{
    FDProductModel *model = [[[FDProductModel alloc] init] autorelease];
    [model setDelegate:self];
    [model syncProducts];
}

#pragma mark - FDProductModelDelegate

- (void)productModelSyncFinished:(FDProductModel *)productModel withInfo:(BOOL)hasData andProductImagesToDownload:(NSMutableArray *)productImagesWithFullURL
{
    [self setCurrentDataIndex:[self currentDataIndex] + 1];
    NSLog(@"Products data sync finished.");
    if (hasData) {
        [self setProductHasSynced:YES];
        [self refreshDataProgressViewWithIndex:[self currentDataIndex]];
        [self setImagesToDownload:productImagesWithFullURL];
        if ([[self imagesToDownload] count]>0) {
            [self setImageTotal:[[self imagesToDownload] count]];
            NSString *imageName=[self.imagesToDownload objectAtIndex:0];
            imageName = [imageName stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            [ImageDownloadHelper sharedInstance].delegate=self;
            [ImageDownloadHelper download:[NSString stringWithString:imageName]];
        } else {
            [self checkIfSyncCompleted];
        }
    } else {
        [self checkIfSyncCompleted];
    }
    [self syncFiles];
}

- (void)productModel:(FDProductModel *)productModel syncErrorMessage:(NSString *)errorMessage
{
    NSLog(@"Sync error. %@", errorMessage); 
    [ModalAlert showAlertView:@"通知" withMessage:@"同步错误，请在设置中配置好服务器IP地址" withCancelBtn:Localized(@"确定")];	
    [self stopIndicatorView];
}

#pragma mark - FDFileModelDelegate

- (void)fileModelSyncFinished:(FDFileModel *)fileModel withInfo:(BOOL)hasData andFilesToDownload:(NSMutableArray *)filesWithFullURL
{
    NSLog(@"Files data sync finished. ");
    
    [self setCurrentDataIndex:[self currentDataIndex] + 1];    
    [self checkIfSyncCompleted];
    if (hasData) {
        [self refreshDataProgressViewWithIndex:[self currentDataIndex]];
        [self setFilesToDownload:filesWithFullURL];
        if ([[self filesToDownload] count] > 0) {
            [self setFileTotal:[[self filesToDownload] count]];
            NSString *strPath=[self.filesToDownload objectAtIndex:[self currentFileIndex]];
            strPath = [strPath stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSArray *fileArray = [strPath componentsSeparatedByString:@"/"];
            NSString *fileName = [fileArray lastObject];
            NSString *saveToPath = [FILE_SOURCE_PATH stringByAppendingPathComponent:fileName];
            NSURL *url=[NSURL URLWithString:strPath];
            [url downloadWithDelegate:self Title:@"downloadPics" WithToFileName:saveToPath];
        } else {
            [self checkIfSyncCompleted];
        }
    } else {
        if ([self productHasSynced]) {
            [self refreshDataProgressViewWithIndex:[self currentDataIndex]];
        } else {
            [ModalAlert showAlertView:@"通知" withMessage:@"当前资料已经是最新" withCancelBtn:Localized(@"确定")];
            [self stopIndicatorView];
            return;
        }
        [self checkIfSyncCompleted];
    }
}

- (void)fileModel:(FDFileModel *)fileModel syncError:(NSString *)errorMessage
{
    NSLog(@"Sync error. %@", errorMessage); 
    [ModalAlert showAlertView:@"通知" withMessage:@"同步错误，请在设置中配置好服务器IP地址" withCancelBtn:Localized(@"_ok")];	
    [[self syncButton] setEnabled:YES];
}

#pragma mark - Refresh progress view

- (void)resetProgressViews
{
    [self setCurrentDataIndex:0];
    [self setCurrentImageIndex:0];
    [self setCurrentFileIndex:0];
    [self setCurrentCompletionFlag:0];
    [self setDataTotal:2];
    [self refreshDataProgressViewWithIndex:0];
    [self refreshImageProgressViewWithIndex:0];
    [self refreshPDFProgressViewWithIndex:0];
    [self setProductHasSynced:NO];
}

- (void)refreshDataProgressViewWithIndex:(int)index
{
    if (0 == [self dataTotal]) return;
    float progress = (float)index / (float)[self dataTotal];
    [[self dataProgressView] setProgress:progress];
    [[self dataProgressLabel] setText:[NSString stringWithFormat:@"%0.0f", progress * 100]];
}

- (void)refreshImageProgressViewWithIndex:(int)index
{
    if (0 == [self imageTotal]) return;
    float progress = ((float)index) / (float)[self imageTotal];
    [[self imageProgressView] setProgress:progress];
    [[self imageProgressLabel] setText:[NSString stringWithFormat:@"%0.0f", progress * 100]];
}

- (void)refreshPDFProgressViewWithIndex:(int)index
{
    if (0 == [self fileTotal]) return;
    float progress = ((float)index) / (float)[self fileTotal];
    [[self pdfProgressView] setProgress:progress];
    [[self pdfProgressLabel] setText:[NSString stringWithFormat:@"%0.0f", progress * 100]];
}

#pragma mark - ImageDownloadHelperDelegate

- (void) didReceiveData: (NSData *) theData
{	
	if ([self currentImageIndex] < [self imageTotal]) {
		NSString *imageName=[[self imagesToDownload] objectAtIndex:[self currentImageIndex]];
        [ImageDownloadHelper download:[NSString stringWithString:imageName]];
		[self setCurrentImageIndex:[self currentImageIndex] + 1];
        [self refreshImageProgressViewWithIndex:[self currentImageIndex]];
	} else {
        [self checkIfSyncCompleted];
    }
}

- (void) didReceiveFilename: (NSString *) aName
{	
	
}

- (void) dataDownloadFailed: (NSString *) reason
{
    if ([self currentImageIndex] < [self imageTotal]) {
		NSString *imageName=[[self imagesToDownload] objectAtIndex:[self currentImageIndex]];
        [ImageDownloadHelper download:[NSString stringWithString:imageName]];
		[self setCurrentImageIndex:[self currentImageIndex] + 1];
        [self refreshImageProgressViewWithIndex:[self currentImageIndex]];
	} else {
        [self checkIfSyncCompleted];
    }

}

- (void) dataDownloadAtPercent: (NSNumber *) aPercent
{	
    
}

#pragma mark - DownloadManagerDelegate

- (void)downloadManagerDataDownloadFinished:(NSString *)fileName withData:(NSData *)data
{
    NSString *filePath=[NSString stringWithFormat:@"%@",fileName];
    NSError *error;
    if([[NSFileManager defaultManager] fileExistsAtPath:filePath]){
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:&error];
    }
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]==NO) {
        [[NSFileManager defaultManager] createFileAtPath:filePath contents:nil attributes:nil];
    }
    FILE *file = fopen([fileName UTF8String], [@"ab+" UTF8String]);
    if(file != NULL){
        fseek(file, 0, SEEK_END);
    }
    int readSize = [data length];
    fwrite((const void *)[data bytes], readSize, 1, file);
    fclose(file);
    
    [self setCurrentFileIndex:[self currentFileIndex] + 1];
    [self refreshPDFProgressViewWithIndex:[self currentFileIndex]];
    if ([self currentFileIndex] < [self fileTotal]) {
        // ....
        
        NSString *strPath=[self.filesToDownload objectAtIndex:[self currentFileIndex]];
        NSArray *fileArray = [strPath componentsSeparatedByString:@"/"];
		NSString *fileName = [fileArray lastObject];
		NSString *saveToPath = [FILE_SOURCE_PATH stringByAppendingPathComponent:fileName];
        strPath = [strPath stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
		NSURL *url=[NSURL URLWithString:strPath];
		[url downloadWithDelegate:self Title:@"downloadPics" WithToFileName:saveToPath];
	} else {
        [self checkIfSyncCompleted];
    }
}

- (void)downloadManagerDataDownloadFailed:(NSString *)reason
{
    
}

- (void)checkIfSyncCompleted
{
    [self setCurrentCompletionFlag:[self currentCompletionFlag] + 1];
    if (COMPLETION_TOTAL == [self currentCompletionFlag]) {
        UIAlertView *alertView = [[[UIAlertView alloc]	initWithTitle:@"资料更新" message:@"资料更新完毕" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil] autorelease];
        [alertView show];
        [self stopIndicatorView];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_FD_FINISHED_SYNC object:nil];
        [[FDWebservice sharedInstance] setUserHasSynced:YES];
        NSURL *urlData = [NSURL URLWithString:[[[FDWebservice sharedInstance] getDataURL]  stringByAppendingFormat:SYNC_FD_FINISHED, [[FDWebservice sharedInstance] sesseionId], [[FDWebservice sharedInstance] getClientId], [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"product"]];
        NSURLRequest *requestData = [NSURLRequest requestWithURL:urlData cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120.0];
        [[[NSURLConnection alloc] initWithRequest:requestData delegate:nil] autorelease];
        NSURL *urlFile = [NSURL URLWithString:[[[FDWebservice sharedInstance] getDataURL] stringByAppendingFormat:SYNC_FD_FINISHED, [[FDWebservice sharedInstance] sesseionId], [[FDWebservice sharedInstance] getClientId], [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"notice"]];
        NSURLRequest *requestFile = [NSURLRequest requestWithURL:urlFile cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120.0];
        [[[NSURLConnection alloc] initWithRequest:requestFile delegate:nil] autorelease];
    }
}

#pragma mark -  UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (19999==alertView.tag) {
        
        if (buttonIndex == 1) {
            //ok
            UITextField *password_text = (UITextField *)[alertView viewWithTag:10202];
            if (password_text&&![@"" isEqualToString:password_text.text]) {
                [[FDWebservice sharedInstance] login:self 
                                            delegate:@selector(userLoginFinished:) 
                                           accountID:[[FDWebservice sharedInstance] getUserId] 
                                            password:password_text.text];
            }else {
                [ModalAlert showAlertView:@"错误" withMessage:@"密码不能为空" withCancelBtn:@"知道了"];
            }
           
        }
        
    } else if (19998 == [alertView tag]) {
        NSLog(@"back");
        // set userHasRegistered to NO
        [[FDWebservice sharedInstance] setUserHasRegistered:NO];
        // delete current data in database
        [[DataManagerModel sharedDataModel] deleteAllDataAndImagesAndFiles]; 
        // reload data
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_FD_FINISHED_SYNC object:nil];
        // clean shoppingcart and compare
        [[[DataManagerModel sharedDataModel] arrayData] removeAllObjects];
        [[[DataManagerModel sharedDataModel] arrayCompareProducts] removeAllObjects];
        // set useHasSynced to NO
        [[FDWebservice sharedInstance] setUserHasSynced:NO];
        // back to homeViewController
        [[FDWebservice sharedInstance] setNeedToRegisterWithoutDeleteApp:YES];
        [[self navigationController] popToRootViewControllerAnimated:YES];
    } else {
        if (buttonIndex == 0) {
            [self stopIndicatorView];
        } 
    }
    
   
}

#pragma mark - View lifecycle

-(void)stopIndicatorView
{
    [self resetProgressViews];
	[[self syncButton] setEnabled:YES];
    [[self syncButton] setHidden:NO];
    [[self activityIndicatorView] stopAnimating];
}

-(void)startIndictorView
{
	[[self syncButton] setEnabled:NO];
    [[self syncButton] setHidden:YES];
    [[self activityIndicatorView] startAnimating];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    // Override to allow orientations other than the default portrait orientation.
	return  UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidLoad 
{
	[super viewDidLoad];
    
    NSMutableArray *tempMutableArray = [[NSMutableArray alloc] init];
	self.imagesToDownload = tempMutableArray;
	[tempMutableArray release];
    
    [self resetProgressViews];
}

- (void)viewDidUnload 
{
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
    [self setDataProgressView:nil];
    [self setImageProgressView:nil];
    [self setPdfProgressView:nil];
    [self setDataProgressLabel:nil];
    [self setImageProgressLabel:nil];
    [self setPdfProgressLabel:nil];
    [self setSyncButton:nil];
    [self setActivityIndicatorView:nil];
	[super viewDidUnload];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:NOTINAME  object:nil];
}

- (void)dealloc 
{
	[imagesToDownload release];
    [filesToDownload release];
    [dataProgressView release];
    [imageProgressView release];
    [pdfProgressView release];
    [dataProgressLabel release];
    [imageProgressLabel release];
    [pdfProgressLabel release];
    [syncButton release];
    [activityIndicatorView release];
    [super dealloc];
}

#pragma mark ---
#pragma mark login view
- (void)triggerUIAlertView {
    
    UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"密码错误重新输入密码"
                                                        message:@"\n\n\n"
                                                       delegate:self 
                                              cancelButtonTitle:@"取消" 
                                              otherButtonTitles:@"确定", nil];
    alertview.tag = 19999;
   
    UILabel *usernameLabel = [[UILabel alloc] initWithFrame:CGRectMake(12.0, 50.0, 260.0, 25.0)];
    usernameLabel.text = [[FDWebservice sharedInstance] getUserId];
    //usernameLabel.tag = 10201;
    [usernameLabel setBackgroundColor:[UIColor clearColor]];
    [usernameLabel setTextColor:[UIColor whiteColor]];
    usernameLabel.textAlignment = UITextAlignmentCenter;
    [usernameLabel setFont:[UIFont boldSystemFontOfSize:16]];
    [alertview addSubview:usernameLabel];
    [usernameLabel release];
    
    UITextField *portfield = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 85.0, 260.0, 25.0)];
    portfield.keyboardType = UIKeyboardTypeNumberPad;
    [portfield setBackgroundColor:[UIColor whiteColor]];
    //    portfield.text = @"";
    [portfield setSecureTextEntry:YES];
    portfield.placeholder = @"密码";
    portfield.tag = 10202;
    [alertview addSubview:portfield];
    [portfield release];
    
    CGAffineTransform moveUp = CGAffineTransformMakeTranslation(0.0, 110.0);
    [alertview setTransform: moveUp];
    [alertview show];
    [alertview release];
}

@end