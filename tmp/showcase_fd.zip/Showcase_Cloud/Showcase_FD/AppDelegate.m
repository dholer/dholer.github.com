//
//  AppDelegate.m
//  Showcase_FD
//
//  Created by august on 12-3-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//
 
#import "AppDelegate.h"
#import "Constants.h"
#import "FMDatabase.h" 
#import "ModalAlert.h"
#import "HomeViewController.h"
#import "FDWebservice.h"
#define DayDifference 30
@implementation AppDelegate
@synthesize window;
@synthesize homeViewController;

#pragma mark -
#pragma mark Application lifecycle
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    if (TARGET_OS_IPHONE) {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
         UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound];
    }
    
    NSString *writablePlistPath = [DOCUMENT_FOLDER_PATH stringByAppendingPathComponent:kDatabaseName];
     //copy db to document
    [self createEditableDatabaseOfDataCacheStoreIfNeeded:writablePlistPath];
    FMDatabase* db = [FMDatabase databaseWithPath:writablePlistPath];
    
    if (![db open]) {
        NSLog(@"Could not open db.");
    }
    // kind of experimentalish.
    [db setShouldCacheStatements:YES];
    //create imagepath
    [self createDirectoryifNeed:PRODUCTIMAGESPATH];
    [self createDirectoryifNeed:FILE_PATH];
   
    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    [self.window setBackgroundColor:[UIColor clearColor]];
    // Override point for customization after application launch.
    self.homeViewController = [[[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil] autorelease];    
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:self.homeViewController];
    [navController setNavigationBarHidden:YES];
    self.window.rootViewController = navController;
    [navController release];
    
    [self.window makeKeyAndVisible];

	return YES;
}


- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken 
{   
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (![defaults objectForKey:@"deviceTokenUploaded"]) {
        NSString *stringValue = deviceToken.description;
        if(stringValue && stringValue.length > 0)
        {
            stringValue = [stringValue substringFromIndex:1];
            int length = stringValue.length;
            stringValue = [stringValue substringToIndex:length - 1];
            
            [[FDWebservice sharedInstance] uploadDeviceToken:self selector:@selector(connectionResponse:) withDeviceToken:stringValue withAppVersion:[[UIDevice currentDevice] systemVersion]];
        }
        
    }else{
        
        [[FDWebservice sharedInstance] checkAppIfExpiration:self selector:@selector(checkAppIfExpirationResult:)];
    }
}


- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error 
{
    if (!TARGET_OS_IPHONE)return;
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{    
    if (!TARGET_OS_IPHONE)return;
    if ([[userInfo objectForKey:@"aps"] objectForKey:@"alert"]) 
    {
        NSString *alertStr = [[userInfo objectForKey:@"aps"] objectForKey:@"alert"];
        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"Warning"
                                                            message:alertStr
                                                           delegate:self 
                                                  cancelButtonTitle:@"Ok,got it!" 
                                                  otherButtonTitles:nil];
        [alertview show];
        [alertview release];
        
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.*/
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
	//release shared db to close the connection
	FMDatabase *db = [FMDatabase sharedDataBase];
	[db release];	
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}

- (void)dealloc {
    
    [homeViewController release];
    [window release];
    [super dealloc];
}

#pragma mark -----
#pragma mark function
-(void)createDirectoryifNeed:(NSString *)path
{
	BOOL isDir = YES;
	if (![[NSFileManager defaultManager] fileExistsAtPath:[DOCUMENT_FOLDER_PATH stringByAppendingPathComponent:path] isDirectory: &isDir]) {
        if ([[NSFileManager defaultManager] createDirectoryAtPath:[DOCUMENT_FOLDER_PATH stringByAppendingPathComponent:path] withIntermediateDirectories:YES attributes:nil error:nil]==NO) {
        }
	}
    
}


- (void)createEditableDatabaseOfDataCacheStoreIfNeeded:(NSString *)destPath
{
	//
    // First, test for existence.
	//
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL success = [fileManager fileExistsAtPath:destPath];
    if (success)return;
    
	// The writable plist does not exist, so copy the default to the appropriate location.
	NSString *defaultPlistPath = [[NSBundle mainBundle] pathForResource:@"furniture_db" ofType:@"sqlite"];
	
    NSError *error;
    success = [fileManager copyItemAtPath:defaultPlistPath toPath:destPath error:&error];
    if (!success) 
	{
        NSAssert1(0, @"Failed to create writable image cache plist file with message '%@'.", [error localizedDescription]);
    }
}

#pragma mark ----
#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag == 1001) {
        if (0 == buttonIndex) {
            //close the app
            exit(0); 
        }
    }    
}


#pragma mark---
#pragma mark connection callback
- (void)connectionResponse:(id)response{
    if (response!=NULL&&response!=nil) {
		NSString *status=[[[response objectForKey:@"results"] objectAtIndex:0] objectForKey:@"status"];
		if ([status isEqualToString:STATUSOFSUCCESS]) {
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            [defaults setBool:YES forKey:@"deviceTokenUploaded"];
            [defaults synchronize];
		}
	}
}

- (void)checkAppIfExpirationResult:(id)result{
    //do nothing
}

@end
