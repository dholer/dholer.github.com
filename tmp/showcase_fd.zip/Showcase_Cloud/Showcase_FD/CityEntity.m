//
//  CityEntity.m
//  Showcase_FD
//
//  Created by Yue Gu on 12-4-3.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "CityEntity.h"

@implementation CityEntity

@synthesize name = _name;
@synthesize provinceID = _provinceID;
@synthesize sort = _sort;

- (void)dealloc
{
    [_name release];
    [_provinceID release];
    [_sort release];
    [super dealloc];
}

@end
