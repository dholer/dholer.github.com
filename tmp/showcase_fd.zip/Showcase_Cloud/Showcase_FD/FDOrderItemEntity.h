//
//  FDOrderItemEntity.h
//  Showcase_FD
//
//  Created by Yue Gu on 4/5/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#define ORDER_ITEM_TABLE_NAME @"order_item"

#define ORDER_ITEM_TABLE_COLUMN_NAME_SERIAL @"serial"
#define ORDER_ITEM_TABLE_COLUMN_NAME_ORDER_ID @"order_id"
#define ORDER_ITEM_TABLE_COLUMN_NAME_PRODUCT_ID @"product_id"
#define ORDER_ITEM_TABLE_COLUMN_NAME_COUNT @"count"
#define ORDER_ITEM_TABLE_COLUMN_NAME_DISCOUNT @"discount"
#define ORDER_ITEM_TABLE_COLUMN_NAME_DISCOUNT_PRICE @"discount_price"
#define ORDER_ITEM_TABLE_COLUMN_NAME_NOTE @"note"
#define ORDER_ITEM_TABLE_COLUMN_NAME_FLAG @"flag"

@class FDProductEntity;

@interface FDOrderItemEntity : NSObject

@property (nonatomic, retain) NSString * serial;
@property (nonatomic, retain) NSString * orderID;
@property (nonatomic) int productID;
@property (nonatomic) int count;
@property (nonatomic) float discount;
@property (nonatomic) float discountPrice;
@property (nonatomic, retain) NSString * note;
@property (nonatomic) int flag;

@property (nonatomic, retain) FDProductEntity * product;

- (id)initWithProductEntity:(FDProductEntity *)productEntity;

@end
