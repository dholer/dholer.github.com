//
//  TitleTableViewCell.m
//  Showcase_FD
//
//  Created by Yue Gu on 12-3-23.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "NewsTitleTableViewCell.h"
#import "FDFileEntity.h"

@implementation NewsTitleTableViewCell

@synthesize fileEntity;

@synthesize flagImageView;
@synthesize titleLabel;
@synthesize dateLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setFileEntity:(FDFileEntity *)fileEntity_
{
    [[self flagImageView] setImage:([fileEntity_ flag] ? [UIImage imageNamed:@"icon-read.png"] : [UIImage imageNamed:@"icon-unread.png"])];
    [[self titleLabel] setText:[fileEntity_ title]];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    [[self dateLabel] setText:[[dateFormatter stringFromDate:[fileEntity_ createdTime]] substringToIndex:10]];
    [dateFormatter release];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    [self setSelectedBackgroundView:[[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"news-selectbg.png"]] autorelease]];
    if (selected) {
        [[self titleLabel] setTextColor:[UIColor whiteColor]];
        [[self dateLabel] setTextColor:[UIColor whiteColor]];
    } else {
        [[self titleLabel] setTextColor:[UIColor blackColor]];
        [[self dateLabel] setTextColor:[UIColor blackColor]];
    }

}

- (void)dealloc {
    [fileEntity release];
    
    [flagImageView release];
    [titleLabel release];
    [dateLabel release];
    [super dealloc];
}
@end
