//
//  FDImageModel.m
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "FDFileModel.h"
#import "FDFileEntity.h"
#import "FDWebservice.h"
#import "UIDevice+IdentifierAddition.h"

@interface FDFileModel()

@property (nonatomic, retain) NSURLConnection *theConnection;
@property (nonatomic, retain) NSMutableData *theData;

@end

@implementation FDFileModel

@synthesize delegate = _delegate;

@synthesize theConnection = _theConnection;
@synthesize theData = _theData;

- (void)dealloc
{
    [_theConnection release];
    [_theData release];
    [super dealloc];
}

- (BOOL)synchronizeWithFileEntities:(NSArray *)fileEntities
{
    BOOL flag = NO;
    for (FDFileEntity *fileEntity in fileEntities) {
        flag = [self addFileEntity:fileEntity];
        if (!flag) return NO;
    }
    return flag;
}

- (void)syncFiles
{
    NSString *isFull = nil;
    if ([[FDWebservice sharedInstance] userHasSynced]) isFull = @"false";
    else isFull = @"true";
    NSURL *url = [NSURL URLWithString:[[[FDWebservice sharedInstance] getDataURL] stringByAppendingFormat:SYNC_FD_PDF, [[FDWebservice sharedInstance] sesseionId], [[FDWebservice sharedInstance] getClientId], [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], isFull]];
    NSLog(@"%@", url);
    NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120.0];
    [self setTheConnection:[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease]];    
}

- (BOOL)addFileEntity:(FDFileEntity *)fileEntity
{
    NSString *sql = [NSString stringWithFormat:@"INSERT OR REPLACE INTO %@ (%@, %@, %@, %@, %@, %@, %@, %@, %@, %@) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", 
                     FILE_TABLE_NAME, 
                     FILE_COLUMN_NAME_FILE_ID, 
                     FILE_COLUMN_NAME_KIND, 
                     FILE_COLUMN_NAME_TITLE, 
                     FILE_COLUMN_NAME_NAME, 
                     FILE_COLUMN_NAME_CREATED_TIME, 
                     FILE_COLUMN_NAME_CREATED_BY, 
                     FILE_COLUMN_NAME_UPDATED_TIME, 
                     FILE_COLUMN_NAME_UPDATED_BY, 
                     FILE_COLUMN_NAME_DELETED, 
                     FILE_COLUMN_NAME_FLAG
                     ];
	NSArray *argArray = [NSArray arrayWithObjects: 
                         [NSNumber numberWithInt:[fileEntity fileID]], 
                         [fileEntity kind] ? [fileEntity kind] : @"", 
                         [fileEntity title] ? [fileEntity title] : @"", 
                         [fileEntity name] ? [fileEntity name] : @"", 
                         [fileEntity createdTime] ? [fileEntity createdTime] : @"",
                         [fileEntity createdBy] ? [fileEntity createdBy] : @"", 
                         [fileEntity updatedTime] ? [fileEntity updatedTime] : @"",
                         [fileEntity updatedBy] ? [fileEntity updatedBy] : @"", 
                         [NSNumber numberWithInt:[fileEntity deleted]], 
                         [NSNumber numberWithInt:0],
                         nil];
	FMDatabase *db = [FMDatabase sharedDataBase];
	BOOL result = [db executeUpdate:sql withArgumentsInArray:argArray];
	
	return result;
}

#pragma mark - 

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response  
{
    NSMutableData *t = [[NSMutableData alloc] initWithLength:0];
    [self setTheData:t];
    [t release];
}

- (void)connection:(NSURLConnection *)connection  didReceiveData:(NSData *)data 
{
	[[self theData] appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection 
{
	NSLock *lock1= [[NSLock alloc] init];
	[lock1 lock];
	NSString *JSONString=[[NSString alloc] initWithData:[self theData] encoding:NSUTF8StringEncoding];
	id JSON = [[JSONString JSONValue] retain];
    NSLog(@"%@", JSONString);
	[JSONString release];
    NSString *status = [[[JSON objectForKey:@"results"] objectAtIndex:0] objectForKey:@"status"];
    BOOL flag = NO;
    NSMutableArray *filesWithFullURL = [[[NSMutableArray alloc] init] autorelease];     
    if ([@"200" isEqualToString:status]) {
        NSArray *filesJSONArray = (NSArray *)[JSON objectForKey:@"content"];
        if (!filesJSONArray || [[NSNull null] isEqual:filesJSONArray] || 0 >= [filesJSONArray count]) {
            [[self delegate] fileModelSyncFinished:self withInfo:NO andFilesToDownload:nil];
            [lock1 unlock];
            [lock1 release];
            return;
        } else {
            NSMutableArray *filesArray = [[NSMutableArray alloc] init];
            for (id fileJSON in filesJSONArray) {
                FDFileEntity *fileEntity = [[FDFileEntity alloc] init];
                [fileEntity setFileID:[(NSNumber *)[fileJSON objectForKey:@"id"] intValue]];
                [fileEntity setKind:[fileJSON objectForKey:@"kind"]];
                [fileEntity setTitle:[fileJSON objectForKey:@"title"]];
                [fileEntity setName:[fileJSON objectForKey:@"fileName"]];
                [fileEntity setCreatedTime:[fileJSON objectForKey:@"createDateTime"]];
                [fileEntity setCreatedBy:[fileJSON objectForKey:@"createBy"]];
                [fileEntity setDeleted:[(NSNumber *)[fileJSON objectForKey:@"publish"] intValue]];
                [filesArray addObject:fileEntity];
                if ([fileEntity name] && ![@"" isEqualToString:[fileEntity name]])
                    [filesWithFullURL addObject:[[[FDWebservice sharedInstance] getFileURL] stringByAppendingString:[fileEntity name]]];
                [fileEntity release];
            }
            flag = [self synchronizeWithFileEntities:filesArray];
            [filesArray release];
        }
    }
    if (flag) [[self delegate] fileModelSyncFinished:self withInfo:YES andFilesToDownload:filesWithFullURL];
    else [[self delegate] fileModel:self syncError:nil];
	[lock1 unlock];
	[lock1 release];
    //    [JSON release];
    [self setTheConnection:nil];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	[self setTheConnection:nil];
}

@end
