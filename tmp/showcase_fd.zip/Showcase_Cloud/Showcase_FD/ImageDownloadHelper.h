/*
 Erica Sadun, http://ericasadun.com
 iPhone Developer's Cookbook, 3.0 Edition
 BSD License, Use at your own risk
 */
#import "Constants.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol ImageDownloadHelperDelegate <NSObject>
@optional
- (void) didReceiveData: (NSData *) theData;
- (void) didReceiveFilename: (NSString *) aName;
- (void) dataDownloadFailed: (NSString *) reason;
- (void) dataDownloadAtPercent: (NSNumber *) aPercent;
@end

@interface ImageDownloadHelper : NSObject 
{
	NSOutputStream					 *fileStream;
    NSHTTPURLResponse					 *response;
	NSMutableData					 *data;
	NSString						 *urlString;
	NSURLConnection					 *urlconnection;
	id <ImageDownloadHelperDelegate> delegate;
	BOOL							 isDownloading;
}
@property (retain) NSHTTPURLResponse   *response;
@property (retain) NSURLConnection *urlconnection;
@property (retain) NSMutableData   *data;
@property (retain) NSString        *urlString;
@property (retain) id              delegate;
@property (assign) BOOL            isDownloading;

- (void) start;
- (NSString *)getUrlBystrUrl:(NSString *)strpath;
+ (ImageDownloadHelper *) sharedInstance;
+ (void) download:(NSString *) aURLString;
+ (void) cancel;
@end
