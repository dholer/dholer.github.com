//
//  ProductCaseViewController.m
//  Showcase_FD
//
//  Created by august on 12-3-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ProductCaseViewController.h"
#import "Constants.h"
#import "UITabBarControllerEx.h"
#import "ModalAlert.h"
#import "ProductDetailViewController.h"
#define CATALOGVIEWSIZE CGSizeMake(188, 177.0)
#define NUMER_PRODUCTS_SLIDERIN 4
#define NUMER_PRODUCTS_SLIDEROUT 3
#define SliderSize 290.f
@implementation ProductCaseViewController
@synthesize all_case_Array;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)init
{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserverForName:NOTIFICATION_FD_FINISHED_SYNC object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note){
            [self.all_case_Array removeAllObjects];
            self.all_case_Array = [[DataManagerModel sharedDataModel] getAllProductByType:CASE];
            [caseView loadData:nil];
        }];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [all_case_Array release];
    [super dealloc];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.frame = VIEWFRAME;
    self.view.backgroundColor = [UIColor grayColor];
    // Do any additional setup after loading the view from its nib.
    [self.navigationController setNavigationBarHidden:YES];
    
    //set top bar
    UIImageView *topbar = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 1024.0, 45.0)];
    [topbar setImage:[UIImage imageNamed:@"topbar.png"]];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200.0, 45)];
    titleLabel.text = @"所有案例";
    [titleLabel setTextAlignment:UITextAlignmentCenter];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    titleLabel.font = [UIFont boldSystemFontOfSize:20];
    [titleLabel setCenter:topbar.center];
    [topbar addSubview:titleLabel];
    [titleLabel release];
    [self.view addSubview:topbar];
    [topbar release];
    //end
    
    //load product view
    caseView = [[MainProductView alloc] initWithFrame:CGRectMake(0, 0, 1024, 658)];
    caseView.delegate = self;
    caseView.view.frame = CGRectMake(0, 45, 1024, 658);
    [self.view addSubview:caseView.view];
    //load mainmenu view
    mainMenuView = [[FMainMenuViewController alloc] init];
    mainMenuView.delegate = self;
    mainMenuView.isShown = NO;
    CGRect frame = mainMenuView.view.frame;
    frame.origin.x = -(SliderSize-32);
    mainMenuView.view.frame = frame;
    self.all_case_Array = [[DataManagerModel sharedDataModel] getAllProductByType:CASE];
    
    //add mainmenu view to keywindow
    mainMenuView.view.tag = 11002;
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window) 
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    
    if (![[[window subviews] objectAtIndex:0] viewWithTag:11002]) {
        [[[window subviews] objectAtIndex:0] addSubview:mainMenuView.view];    
    }
    if ([all_case_Array count]) {
        [ModalAlert showBlockWait:@"正在读取信息,请稍等..."];
        [caseView loadData:nil];  
    }
    
    
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //add by august 2012-04-11
    [mainMenuView sliderAction:nil];
    //end
    [self hideOrShowMainMenuBar:NO];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if (mainMenuView.isShown) {
        [self hideOrShowMainMenuBar:YES];
        [mainMenuView sliderAction:nil];
    }
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self hideOrShowMainMenuBar:YES];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    [all_case_Array removeAllObjects];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (void)hideOrShowMainMenuBar:(BOOL)flag{
    
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window) 
        window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    UIView *menuView = [[[window subviews] objectAtIndex:0] viewWithTag:11002];
    [menuView setHidden:flag];
}


#pragma mark ---
#pragma mark FMainMenuView delegate
- (void)slideMenuAction:(BOOL)isShow{
    
    if (isShow) {
        
        [UIView animateWithDuration:0.25f delay:0.0 
                            options:UIViewAnimationOptionCurveEaseInOut 
                         animations:^(void){
                             [mainMenuView.view setFrame:CGRectMake(0, 0, 290, 768)];
                             
                         }
                         completion:^(BOOL finished){
                             
                         }];
        //slider in main product view
        [UIView animateWithDuration:0.25f animations:^(void){
            [caseView.view setFrame:CGRectMake(SliderSize-35, 45, 768.0, 658)];
            caseView.wideShow = YES;
            [caseView modifyProductListviewWidth];
            
        }completion:^(BOOL finished){
        }];
        
    }else{
        
        [UIView animateWithDuration:0.25f delay:0.0 
                            options:UIViewAnimationOptionCurveEaseInOut 
                         animations:^(void){
                             [mainMenuView.view setFrame:CGRectMake(-(SliderSize-32), 0, 290, 768)];
                             
                             
                         }
                         completion:^(BOOL finished){
                             
                         }];
        
        //slider out main product view
        [UIView animateWithDuration:0.25f animations:^(void){
            [caseView.view setFrame:CGRectMake(0, 45, 1024.0, 658)];
            caseView.wideShow = NO;
            [caseView modifyProductListviewWidth];
        }completion:^(BOOL finished){
        }];
        
    }
    
}

- (void)didselectedMenu:(NSMutableDictionary *)dic{
    NSNumber *roomCode = [dic objectForKey:ROOM];
    NSNumber *styleCode = [dic objectForKey:STYLE];
    NSLog(@"roomCode=%d,styleCode=%d",[roomCode intValue],[styleCode intValue]);
    //clean up
    [self.all_case_Array removeAllObjects];
    self.all_case_Array = [[DataManagerModel sharedDataModel] getAllProductByType:CASE withRoom:[roomCode intValue] withStyle:[styleCode intValue]];
    
    [caseView loadData:nil];
}

#pragma mark ----
#pragma mark mainproductshow delegate
- (CGSize)sizeOfCatalogsCell{
    return CATALOGVIEWSIZE;
}

- (NSUInteger)numberOfProdcutCatalogs:(NSString *)bigCatalogID{
    
    return [all_case_Array count];
}

- (id)productCatalogForIndex:(NSUInteger)index{
    
    return [all_case_Array objectAtIndex:index];
}

- (NSArray *)getArrayOfProductCatalogID:(int)smallcatalogID{
    return nil;
}

- (PAGETYPE)getCurrentPageType{
    return CasePage;
}

- (NSUInteger)numberOfColumnsForLandscape{
    if (mainMenuView.isShown) {
        return NUMER_PRODUCTS_SLIDEROUT;
    }else {
        return NUMER_PRODUCTS_SLIDERIN;  
    }
    
}

- (void)didProductSelect:(id)object{
    
    if ([object isKindOfClass:[FDProductEntity class]]) {
        
        ProductDetailViewController *detailView = [[ProductDetailViewController alloc] initWithType:CASE];
        //detailView.hidesBottomBarWhenPushed = YES;
        detailView.currentProduct = (FDProductEntity*)object;
        [self.navigationController pushViewController:detailView animated:YES];
        [detailView hiddenDetailInfoView:YES];
        [detailView release];
        
    }
}


@end
