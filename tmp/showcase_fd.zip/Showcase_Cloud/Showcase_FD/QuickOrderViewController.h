//
//  QuickOrderViewController.h
//  Showcase_FD
//
//  Created by august on 12-3-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuickOrderLeftPartViewController.h"
#import "FDProductEntity.h"
#import "QuickOrderProductDetailView.h"
#import "QuickOrderSearchViewController.h"

@class QuickOrderCompareViewController;

@interface QuickOrderViewController : UIViewController<QuickOrderLeftPartDelegate, QucikOrderSearchViewDelegate, QuickOrderProductDetailDelegate>
{
    UIWindow                            *sharedWindow;
    
    QuickOrderLeftPartViewController    *vcLeftPart;
    
    UIScrollView                        *svContent;
    
    NSMutableArray                      *arrayAllProducts;
    NSMutableArray                      *arrayDeep0Views;
    NSMutableArray                      *arrayDeep1Views;
    
    QuickOrderCompareViewController     *vcCompare;
    
    QuickOrderSearchViewController      *vcSearch;
    
    UITextField                         *tfInput;
    
    UIButton                            *btnBack;
    // added by Alex @ 2012.4.19
    UIButton *btnShort;
    UIImageView *ivSearchBG;
    UIImageView *ivSearchFlag;
    // 
    UIView                              *vDetailParent;
    QuickOrderProductDetailView         *vProductDetail;
    
    int                                 theDeep;
    int                                 theRoomCategoryID;
    int                                 theStyleCategoryID;
    
    //NSMutableArray                      *arrayCompareProducts;
    
    NSMutableArray                      *arrayShortCuts;
    
    UIAlertView                         *alertView;
    
    NSMutableDictionary                 *dictImages;
    UILabel                             *titleLabel;
    UIView                              *detailView;//存放detail界面的
    
    NSMutableArray                      *curProductList;
    
    BOOL                                backFlag;
}

@property (nonatomic, retain) NSMutableArray                      *arrayAllProducts;
@property (nonatomic, retain) NSMutableArray                        *curProductList;
@property (nonatomic, retain) NSMutableDictionary                        *dictImages;
@property (nonatomic) BOOL backFlag;

@end

@interface UIProductButton: UIButton 
{
    FDProductEntity     *productEntiry;
}
@property (nonatomic, retain) FDProductEntity     *productEntiry;
@end