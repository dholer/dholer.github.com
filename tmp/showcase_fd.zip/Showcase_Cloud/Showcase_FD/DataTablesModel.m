//
//  DataTablesModel.m
//  iPadSales
//
//  Created by Fjl on 11-2-23.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DataTablesModel.h"
#import <CommonCrypto/CommonDigest.h>


@implementation DataTablesModel
@synthesize tableName;
-(id)init
{
	self = [super init];
	
	dataCacheDictionary = [[NSMutableDictionary alloc] init];
	
	return self;
}

-(void )dealloc
{
    [tableName release];
	[dataCacheDictionary release];
	
	[super dealloc];
}
-(BOOL) saveEntity:(id) entity
{
    FMDatabase *db = [FMDatabase sharedDataBase];
    FMResultSet *rs = [db getTableSchema:tableName];
    NSMutableArray *columnArray=[NSMutableArray array];
    while ([rs next]) {
        [columnArray addObject:[rs resultDict]];
    }
	
	//get table information
	NSMutableString *strfrontsql=[[NSMutableString alloc] initWithFormat:@"insert or replace into %@(",self.tableName]; 
    NSMutableString *strbacksql=[[NSMutableString alloc] initWithString:@" values("]; 
    NSMutableArray  *argArray=[[NSMutableArray alloc] init];
    for (int j=0; j<[columnArray count]; j++) {
        NSString *columnName=[[columnArray objectAtIndex:j] objectForKey:@"name"];
        NSString *columnType=[[columnArray objectAtIndex:j] objectForKey:@"type"];
        if (j==0) {
            [strfrontsql appendString:columnName];
            [strbacksql appendString:@"?"];
        }else {
            [strfrontsql appendFormat:@",%@",columnName];
            [strbacksql appendFormat:@",%@",@"?"];
        }
        if ([columnType hasPrefix:@"int"]) {
            id anobject=[NSString stringWithFormat:@"%d",[[entity objectForKey:columnName] intValue]];
            if(anobject!=nil)
            {
                [argArray addObject:anobject];
            }
            else
            {
                [argArray addObject:@"0"]; 
            }
        }else if ([columnType hasPrefix:@"boolean"]) {
            id anobject=[NSString stringWithFormat:@"%d",[[entity objectForKey:columnName] boolValue]];
            if(anobject!=nil)
            {
                [argArray addObject:anobject];
            }
            else
            {
                [argArray addObject:@"0"]; 
            }
        }else if([columnType hasPrefix:@"numeric"]) {
            id anobject=[NSString stringWithFormat:@"%f",[[entity objectForKey:columnName] floatValue]];
            if(anobject!=nil)
            {
                [argArray addObject:anobject];
            }
            else
            {
                [argArray addObject:@"0.0"]; 
            }
            
        }else if([columnType hasPrefix:@"varchar"]) {
            id anobject=[entity objectForKey:columnName];
            if(anobject!=nil)
            {
                [argArray addObject:anobject];
            }
            else
            {
                [argArray addObject:@""];
            }
        }else if([columnType hasPrefix:@"char"]) {
            id anobject=[entity objectForKey:columnName];
            if(anobject!=nil)
            {
                [argArray addObject:anobject];
            }
            else
            {
                [argArray addObject:@""];
            }
        }else if([columnType hasPrefix:@"date"]) {
            id anobject=[entity objectForKey:columnName];
			NSDateFormatter *dateFormatter = [DataTablesModel getDateFormatter];
			
			if(anobject!=nil)
			{
				long time =	[anobject longLongValue];
				NSDate *date = [NSDate dateWithTimeIntervalSince1970:time];
				NSString *str_date = [dateFormatter stringFromDate:date];
				[argArray addObject:str_date];
			}
			else
			{
				NSString *str_date = [dateFormatter stringFromDate:[NSDate date]];
				[argArray addObject:str_date];
			}
        }			
    }
    [strfrontsql appendString:@")"];
    [strfrontsql appendString:strbacksql];
    [strfrontsql appendString:@")"];
    int result=[db executeUpdate:strfrontsql withArgumentsInArray:argArray];
    [strfrontsql release];
    [strbacksql release];
    [argArray release];	
	return result;
	
}
-(int) syncEntity:(id) retmotingData{
	int result=0;
	NSMutableArray *remotingDataList=[retmotingData objectForKey:@"content"];
	if(![remotingDataList isEqual:[NSNull null]]&&remotingDataList!=nil)
	{
		FMDatabase *db = [FMDatabase sharedDataBase];
		FMResultSet *rs = [db getTableSchema:tableName];
		NSMutableArray *columnArray=[NSMutableArray array];
		while ([rs next]) {
			[columnArray addObject:[rs resultDict]];
		}
		for (int i=0; i<[remotingDataList count]; i++) {
			//get table information
			
			NSMutableString *strfrontsql=[[NSMutableString alloc] initWithFormat:@"insert or replace into %@(",tableName]; 
			NSMutableString *strbacksql=[[NSMutableString alloc] initWithString:@" values("]; 
			NSMutableArray  *argArray=[[NSMutableArray alloc] init];
			for (int j=0; j<[columnArray count]; j++) {
				NSString *columnName=[[columnArray objectAtIndex:j] objectForKey:@"name"];
				NSString *columnType=[[columnArray objectAtIndex:j] objectForKey:@"type"];
				if (j==0) {
					[strfrontsql appendString:columnName];
					[strbacksql appendString:@"?"];
				}else {
					[strfrontsql appendFormat:@",%@",columnName];
					[strbacksql appendFormat:@",%@",@"?"];
				}
				if ([columnType hasPrefix:@"int"]) {
					id anobject=[NSString stringWithFormat:@"%d",[[[remotingDataList objectAtIndex:i] objectForKey:columnName] intValue]];
					if(anobject!=nil)
					{
						[argArray addObject:anobject];
					}
					else
					{
						[argArray addObject:@"0"]; 
					}
				}else if ([columnType hasPrefix:@"boolean"]) {
					id anobject=[NSString stringWithFormat:@"%d",[[[remotingDataList objectAtIndex:i] objectForKey:columnName] boolValue]];
					if(anobject!=nil)
					{
						[argArray addObject:anobject];
					}
					else
					{
						[argArray addObject:@"0"]; 
					}
				}else if([columnType hasPrefix:@"numeric"]) {
                    id anobject=[NSString stringWithFormat:@"%f",[[[remotingDataList objectAtIndex:i] objectForKey:columnName] floatValue]];
					if(anobject!=nil)
					{
						[argArray addObject:anobject];
					}
					else
					{
						[argArray addObject:@"0.0"]; 
					}

                }else if([columnType hasPrefix:@"varchar"]) {
					id anobject=[[remotingDataList objectAtIndex:i] objectForKey:columnName];
					if(anobject!=nil)
					{
						[argArray addObject:anobject];
					}
					else
					{
						[argArray addObject:@""];
					}
				}else if([columnType hasPrefix:@"char"]) {
					id anobject=[[remotingDataList objectAtIndex:i] objectForKey:columnName];
					if(anobject!=nil)
					{
						[argArray addObject:anobject];
					}
					else
					{
						[argArray addObject:@""];
					}
				}else if([columnType hasPrefix:@"date"]) {
					id anobject=[[remotingDataList objectAtIndex:i] objectForKey:columnName];
					NSDateFormatter *dateFormatter = [DataTablesModel getDateFormatter];
					
				//	NSArray *timeZoneNames = [NSTimeZone knownTimeZoneNames]; 
//					for (NSString *name  in  timeZoneNames ) {
						if(anobject!=nil)
						{
							long time =[anobject longLongValue];
							NSDate *date = [NSDate dateWithTimeIntervalSince1970:time];
							NSString *str_date = [dateFormatter stringFromDate:date];
							[argArray addObject:str_date];
						}
						else
						{
							NSString *str_date = [dateFormatter stringFromDate:[NSDate date]];
							[argArray addObject:str_date];
						}
					//}
					
				}else if([columnType hasPrefix:@"longtext"]) {
					id anobject=[[remotingDataList objectAtIndex:i] objectForKey:columnName];
					if(anobject!=nil)
					{
						[argArray addObject:anobject];
					}
					else
					{
						[argArray addObject:@""];						
					}
				}	
			}
			[strfrontsql appendString:@")"];
			[strfrontsql appendString:strbacksql];
			[strfrontsql appendString:@")"];
			if([db executeUpdate:strfrontsql withArgumentsInArray:argArray])
			{
				result++;
			}
			[strfrontsql release];
			[strbacksql release];
			[argArray release];
		}
	}
	return result;
}

+ (NSString *)getMD5FromString:(NSString *)source{
	const char *src = [source UTF8String];
	unsigned char result[CC_MD5_DIGEST_LENGTH];
	CC_MD5(src, strlen(src), result);
    NSString *ret = [[[NSString alloc] initWithFormat:@"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
					  result[0], result[1], result[2], result[3],
					  result[4], result[5], result[6], result[7],
					  result[8], result[9], result[10], result[11],
					  result[12], result[13], result[14], result[15]
					  ] autorelease];
    return [ret lowercaseString];
}

+ (NSString *)GetUUID
{
	CFUUIDRef theUUID = CFUUIDCreate(NULL);
	CFStringRef string = CFUUIDCreateString(NULL, theUUID);
	CFRelease(theUUID);
	return [(NSString *)string autorelease];
}

+(NSDateFormatter *)getDateFormatter{
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
	[dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
	return[dateFormatter autorelease];
}

+(id)getImagesByImageName:(NSString *)imageName tryToGetMain:(BOOL) tryMain{
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
	
	NSString *documentdirPath = [NSString stringWithFormat:@"%@/ProductImages/",basePath];
	NSString *bundledirPath = [NSString stringWithFormat:@"%@/ProductImages/",[[NSBundle mainBundle] bundlePath]];
	NSString *path = nil;
	BOOL isDir = NO;
	
	if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@%@",documentdirPath,imageName] isDirectory: &isDir]) {
		//尝试从documentdir获取图片
		path = [NSString stringWithFormat:@"%@%@",documentdirPath,imageName];
	}else if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@%@",bundledirPath,imageName] isDirectory: &isDir]){
		//若docuemntdir无图，尝试从bundledir获取图片
		path = [NSString stringWithFormat:@"%@%@",bundledirPath,imageName];
	}else{
		//若documentdir,bundledir都无图
		if (tryMain  == YES){
			//先尝试将图片解析成主产品图片
			NSArray *array = [imageName componentsSeparatedByString:@"-"];
			NSString *parentFileName = [NSString stringWithFormat:@"%@.jpg",[array objectAtIndex:0]];
			if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@%@",documentdirPath,parentFileName] isDirectory: &isDir]) {
				path = [NSString stringWithFormat:@"%@%@",documentdirPath,parentFileName];
			}else if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@%@",bundledirPath,parentFileName] isDirectory: &isDir]){
				path = [NSString stringWithFormat:@"%@%@",bundledirPath,parentFileName];
			}else{
				//从工程中加载
				path = nil;
			}
		}else{
			//从工程中加载
			path = nil;
		}
	}
	
	UIImage *tmpimage = nil;
	if (path != nil){
		//若检测到在目录里存在图片，加载进来，但图片可能是坏的，无法加载
		tmpimage = [UIImage imageWithContentsOfFile:path];
	}else{
		//若图片不存在，从工程中加载
		tmpimage = [UIImage imageNamed:imageName];
	}
	
	//若有图片无法加载，再次尝 试加载主产品
	if (tmpimage == nil && tryMain == YES){
		NSArray *array = [imageName componentsSeparatedByString:@"-"];
		NSString *parentFileName = [NSString stringWithFormat:@"%@.jpg",[array objectAtIndex:0]];
		if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@%@",documentdirPath,parentFileName] isDirectory: &isDir]) {
			path = [NSString stringWithFormat:@"%@%@",documentdirPath,parentFileName];
			tmpimage = [UIImage imageWithContentsOfFile:path];
		}else if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@%@",bundledirPath,parentFileName] isDirectory: &isDir]){
			path = [NSString stringWithFormat:@"%@%@",bundledirPath,parentFileName];
			tmpimage = [UIImage imageWithContentsOfFile:path];
		}else{
			return nil;
		}
	}
	return tmpimage;
}

@end
