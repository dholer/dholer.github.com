//
//  UIImage+Until.m
//  Showcase_FD
//
//  Created by august on 12-3-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UIImage+Until.h"
#import "FDProductModel.h"
#import "FDProductEntity.h"
#import "Constants.h"
@implementation UIImage (Until)
+(UIImage *)imageWithImage:(UIImage *)image borderImage:(UIImage *)borderImage{
    CGSize size = borderImage.size;
    UIGraphicsBeginImageContext(size);
    [borderImage drawInRect:CGRectMake( 0, 0, size.width, size.height )];
    [image drawInRect:CGRectMake( 2, 2, size.width - 8, size.height - 8)];
    UIImage *destImage = UIGraphicsGetImageFromCurrentImageContext();    
    UIGraphicsEndImageContext();
    return destImage;
}

+(UIImage *)imageWithQuickOrderImage:(UIImage *)image borderImage:(UIImage *)borderImage{
    CGSize size = borderImage.size;
    // modified by Alex @ 2012.5.3
    int widthQuotient = image.size.width / (size.width - 22 - 13);
    int heightQuotient = image.size.height / (size.height - 30 - 14);
    int quotient = MAX(widthQuotient, heightQuotient);
    int width = image.size.width / quotient;
    int height = image.size.height / quotient;
    UIGraphicsBeginImageContext(size);
    [borderImage drawInRect:CGRectMake( 0, 0, size.width, size.height )];
    [image drawInRect:CGRectMake((size.width - width) / 2, (size.height - height) / 2, width, height)];
    //
    UIImage *destImage = UIGraphicsGetImageFromCurrentImageContext();    
    UIGraphicsEndImageContext();
    return destImage;
}

+(BOOL)saveImageToLocal:(UIImage *)image filePath:(NSString *)path{
    if ([UIImagePNGRepresentation(image) writeToFile:path atomically:YES]) {
        return YES;
    }else {
        return NO;
    }
}

+ (UIImage *)getProductThumbImage:(FDProductEntity *)productEntity{
    
    NSString *thumbImagePath = [PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.thumbImage];
    NSString *fullImagepath = [PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.fullImage];
    if ([[NSFileManager defaultManager] fileExistsAtPath:thumbImagePath isDirectory:NO]&&productEntity.thumbImage&&![@"" isEqualToString:productEntity.thumbImage]) {
        UIImage *image_ = [[[UIImage alloc] initWithContentsOfFile:thumbImagePath] autorelease];
        return image_;
    }else {
        UIImage *image_ = [[UIImage alloc] initWithContentsOfFile:fullImagepath];
        UIImage *reslutImage = [UIImage imageWithImage:image_ borderImage:[UIImage imageNamed:@"productFrame.png"]];
        [image_ release];
        NSString *thumbImageName = [NSString stringWithFormat:@"thumb_%@",productEntity.fullImage];
        productEntity.thumbImage = thumbImageName;
        BOOL reslut =  [UIImage saveImageToLocal:reslutImage filePath:[PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.thumbImage]];
        if (reslut) {
            FDProductModel *productModel = [[FDProductModel alloc] init];
            [productModel addProductEntity:productEntity];
            [productModel release];
            return reslutImage;  
        }
    }
    return nil;
}

+ (UIImage *)getQuickOrderProductThumbImage:(FDProductEntity *)productEntity{
    
//    NSString *thumbImagePath = [PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.thumbImage];
//    NSString *fullImagepath = [PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.fullImage];
//    if ([[NSFileManager defaultManager] fileExistsAtPath:thumbImagePath isDirectory:NO]&&productEntity.thumbImage&&![@"" isEqualToString:productEntity.thumbImage]) {
//        UIImage *image_ = [[[UIImage alloc] initWithContentsOfFile:thumbImagePath] autorelease];
//        return image_;
//    }else {
//        UIImage *image_ = [[UIImage alloc] initWithContentsOfFile:fullImagepath];
//        UIImage *reslutImage = [UIImage imageWithQuickOrderImage:image_ borderImage:[UIImage imageNamed:@"img-frame.png"]];
//        [image_ release];
////        NSString *thumbImageName = [NSString stringWithFormat:@"thumb_%@",productEntity.fullImage];
////        productEntity.thumbImage = thumbImageName;
//        return reslutImage;
////        BOOL reslut =  [UIImage saveImageToLocal:reslutImage filePath:[PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.thumbImage]];
////        if (reslut) {
////            FDProductModel *productModel = [[FDProductModel alloc] init];
////            [productModel addProductEntity:productEntity];
////            [productModel release];
////            return reslutImage;  
////        }
//    }
    //NSString *thumbImagePath = [PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.thumbImage];
    NSLog(@"%@",productEntity);
    NSString *fullImagepath = [PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.fullImage];
    
    UIImage *image_ = [[UIImage alloc] initWithContentsOfFile:fullImagepath];
    UIImage *reslutImage = [UIImage imageWithQuickOrderImage:image_ borderImage:[UIImage imageNamed:@"img-frame.png"]];
    [image_ release];
    
    return reslutImage;
}

+ (UIImage *)productImageNamed:(NSString *)imageName
{
    
    NSString *path = [NSString stringWithFormat:@"%@/%@", PRODUCT_IMAGE_SOURCE_PATH, imageName];
    
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    
    //UIImage *image = [UIImage productImageNamed:imageName];
    UIImage *imageBG = [UIImage imageNamed:@"img-frame.png"];
    
    if(!image)
        return imageBG;
    
    float widthDraw = imageBG.size.width - 20;
    float heightDraw = imageBG.size.height - 24;
    float widthProduct = image.size.width;
    float heightProduct = image.size.height;
    
    float widthActual = widthDraw;
    float heightActual = heightDraw;
    if(widthDraw / widthProduct > heightDraw / heightProduct)
    {
        //Using height
        widthActual = widthProduct * (heightActual / heightProduct);
    }
    else
    {
        //using width
        heightActual = heightProduct * (widthActual / widthProduct);
    }
    
    UIGraphicsBeginImageContext(imageBG.size);
	[imageBG drawInRect:CGRectMake(0, 0, imageBG.size.width, imageBG.size.height)];	
    [image drawInRect:CGRectMake(12, 14, widthActual, heightActual)];
    
	UIImage *imageProduct = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
    
    
    return imageProduct;
}

+ (UIImage *)productImageName:(NSString *)name
{
    NSString *path = [NSString stringWithFormat:@"%@/%@", PRODUCT_IMAGE_SOURCE_PATH, name];
    
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    
    return image;
}

@end
