//
//  UITabBarButtonEx.h
//  Mauijim
//
//  Created by leo on 11-9-19.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBarButtonEx : UIView
{
    UIButton *_button;
    //UILabel         *_titleLabel;
    BOOL isShowBgView;
}

@property (nonatomic) BOOL isShowBgView;
- (id)initWithFrame:(CGRect)frame normalImage:(NSString *)normalImage highLightImage:(NSString *)highlightImage target:(id)target action:(SEL)action title:(NSString *)title tag:(int)tag_;
- (void)setBgView:(BOOL)flag;
@end
