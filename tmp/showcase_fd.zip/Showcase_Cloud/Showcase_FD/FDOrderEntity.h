//
//  FDOrderEntity.h
//  Showcase_FD
//
//  Created by Yue Gu on 4/5/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#define ORDER_TABLE_NAME @"order_info"

#define ORDER_TABLE_COLUMN_NAME_SERIAL @"serial"
#define ORDER_TABLE_COLUMN_NAME_STORE @"store"
#define ORDER_TABLE_COLUMN_NAME_CUSTOMER @"customer"
#define ORDER_TABLE_COLUMN_NAME_PHONE @"phone"
#define ORDER_TABLE_COLUMN_NAME_CELL_PHONE @"cell_phone"
#define ORDER_TABLE_COLUMN_NAME_SHOPPING_GUIDE @"shopping_guide"
#define ORDER_TABLE_COLUMN_NAME_HOME_PHONE @"home_phone"
#define ORDER_TABLE_COLUMN_NAME_PROVINCE @"province"
#define ORDER_TABLE_COLUMN_NAME_CITY @"city"
#define ORDER_TABLE_COLUMN_NAME_ZONE @"zone"
#define ORDER_TABLE_COLUMN_NAME_ADDRESS @"address"
#define ORDER_TABLE_COLUMN_NAME_DETAIL_PROVINCE @"detail_province"
#define ORDER_TABLE_COLUMN_NAME_DETAIL_CITY @"detail_city"
#define ORDER_TABLE_COLUMN_NAME_DETAIL_ZONE @"detail_zone"
#define ORDER_TABLE_COLUMN_NAME_DETAIL_ADDRESS @"detail_address"
#define ORDER_TABLE_COLUMN_NAME_ORDERING_DATE @"ordering_date"
#define ORDER_TABLE_COLUMN_NAME_DELIVER_DATE @"deliver_date"
#define ORDER_TABLE_COLUMN_NAME_DEPOSIT @"deposit"
#define ORDER_TABLE_COLUMN_NAME_BALANCE @"balance"
#define ORDER_TABLE_COLUMN_NAME_REQUIREMENTS @"requirements"
#define ORDER_TABLE_COLUMN_NAME_TOTAL @"total"
#define ORDER_TABLE_COLUMN_NAME_TOTAL_DISCOUNT @"total_discount"
#define ORDER_TABLE_COLUMN_NAME_FINAL_TOTAL @"final_total"
#define ORDER_TABLE_COLUMN_NAME_NOTE @"note"
#define ORDER_TABLE_COLUMN_NAME_CREATED_DATE @"created_date"

@interface FDOrderEntity : NSObject

@property (nonatomic, retain) NSString * serial;
@property (nonatomic, retain) NSString * store;
@property (nonatomic, retain) NSString * customer;
@property (nonatomic, retain) NSString * phone;
@property (nonatomic, retain) NSString * cellPhone;
@property (nonatomic, retain) NSString * shoppingGuide;
@property (nonatomic, retain) NSString * homePhone;
@property (nonatomic, retain) NSString * province;
@property (nonatomic, retain) NSString * city;
@property (nonatomic, retain) NSString * zone;
@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) NSString * detailProvince;
@property (nonatomic, retain) NSString * detailCity;
@property (nonatomic, retain) NSString * detailZone;
@property (nonatomic, retain) NSString * detailAddress;
@property (nonatomic, retain) NSDate * orderingDate;
@property (nonatomic, retain) NSDate * deliveringDate;
@property (nonatomic) float deposit;
@property (nonatomic) float balance;
@property (nonatomic, retain) NSString * requirements;
@property (nonatomic) float total;
@property (nonatomic) float totalDiscount;
@property (nonatomic) float finalTotal;
@property (nonatomic, retain) NSString * note;
@property (nonatomic, retain) NSDate * createdDate;

@property (nonatomic, retain) NSArray * orderItems;

@end
