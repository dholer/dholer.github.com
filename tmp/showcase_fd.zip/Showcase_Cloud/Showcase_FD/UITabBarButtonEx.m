//
//  UITabBarButtonEx.m
//  Mauijim
//
//  Created by leo on 11-9-19.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "UITabBarButtonEx.h"

@implementation UITabBarButtonEx
@synthesize isShowBgView;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (id)initWithFrame:(CGRect)frame normalImage:(NSString *)normalImage highLightImage:(NSString *)highlightImage target:(id)target action:(SEL)action title:(NSString *)title tag:(int)tag_
{
    self = [super initWithFrame:frame];
    
    if(self){
    
        UIImageView *btnBgView = [[UIImageView alloc] initWithFrame:CGRectMake(2, -4, frame.size.width+8, frame.size.height+6)];
        btnBgView.image = [UIImage imageNamed:@"tab_btn_select-bg.png"];
        btnBgView.tag = 19999;
        btnBgView.hidden = YES;
        [self addSubview:btnBgView];
        [btnBgView release];
        
		_button = [UIButton buttonWithType:UIButtonTypeCustom];
        _button.frame = CGRectMake(15.0, 0.0, frame.size.width-16.0, frame.size.height-5);//image size 54*53
        _button.contentMode = UIViewContentModeCenter;
		[_button setBackgroundColor:[UIColor clearColor]];
        _button.showsTouchWhenHighlighted = YES;
		_button.tag = tag_;
        [_button setBackgroundImage:[UIImage imageNamed:normalImage] forState:UIControlStateNormal];
        [_button setBackgroundImage:[UIImage imageNamed:highlightImage] forState:UIControlStateSelected];
        [_button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_button];
        
        /*_titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0, frame.size.height - 33.0, frame.size.width - 0.0, 25)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.textAlignment = UITextAlignmentCenter;
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.font = [UIFont systemFontOfSize:12];
        _titleLabel.text = title;
        _titleLabel.tag = tag_ + 1000;
        [self addSubview:_titleLabel];
        [_titleLabel release];*/
		
    }
    
    return self;
}

- (void)setBgView:(BOOL)flag{
    UIImageView *imageview = (UIImageView *)[self viewWithTag:19999];
    [imageview setHidden:flag];
    //NSLog(@"%@",imageview);
}

@end
