//
//  MainProductScrollview.h
//  Showcase_FD
//
//  Created by august on 12-3-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#define MIN_PINCH	8
#define UITouchPinchIn  0
#define UITouchPinchOut 1
@interface MainProductScrollview : UIScrollView{
    BOOL                                finished;
    BOOL                                multitouch;
    CGPoint                             startpoint;
    CGFloat                             firtdist;
    CGPoint                             touchCenter;
    int                                 touchtype;
}
-(void)viewTouchesMove:(int)touchPinchType lastdistance:(CGFloat)lastdistance;

@end
