//
//  FDProductCatalog.h
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FDProductCatalogEntity : NSObject

@property (nonatomic) int productCatalogID;
@property (nonatomic) int catalogID;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *code;
@property (nonatomic, retain) NSString *type;
@property (nonatomic) int order;
@property (nonatomic, retain) NSDate *createdTime;
@property (nonatomic, retain) NSString *createdBy;
@property (nonatomic, retain) NSDate *updatedTime;
@property (nonatomic, retain) NSString *updatedBy;

@end
