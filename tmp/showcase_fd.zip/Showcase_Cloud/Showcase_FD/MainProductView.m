//
//  MainProductView.m
//  Showcase_FD
//
//  Created by august on 12-3-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MainProductView.h"
#import "ModalAlert.h"

#define VIEWGAP 55.f
#define LEFTGAP 53.f
#define TOPGAP  35.f
#define SINGLEPRODUCTVIEWSIZE CGSizeMake(188, 177.0)


@implementation MainProductView
@synthesize delegate,catalogScrollView,currentpArray;
@synthesize wideShow,isHidden;

- (id)initWithFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        scrollviewFrame = frame; 
    }
    return self;
}

#pragma mark - View lifecycle
- (void)dealloc
{
    //[productlistview release];
    [currentpArray release];
    [catalogScrollView release];
    [super dealloc];
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    UIScrollView *tmpCatalogScrollview=[[UIScrollView alloc] initWithFrame:scrollviewFrame];
    tmpCatalogScrollview.backgroundColor=[UIColor whiteColor];
    self.wantsFullScreenLayout = YES;
    tmpCatalogScrollview.showsHorizontalScrollIndicator=NO;
    tmpCatalogScrollview.showsVerticalScrollIndicator=NO;
    self.catalogScrollView=tmpCatalogScrollview;
    [tmpCatalogScrollview release];
    [self.view addSubview:self.catalogScrollView];
	
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    catalogScrollView = nil;
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

#pragma mark----
#pragma mark function
- (NSUInteger)indexForColumn:(NSUInteger)column inRow:(NSUInteger)row
{
    return numberOfColumns*row + column;
}

- (CGRect)productSubviewChangeByIndex:(int)currentIndex{
    
    CGRect rect;
    if(wideShow)
        rect=CGRectMake((currentIndex % numberOfColumns)*(sizeOfProdcutCatalogsCell.width+54)+50, (sizeOfProdcutCatalogsCell.height+TOPGAP) *(currentIndex / numberOfColumns)+TOPGAP, sizeOfProdcutCatalogsCell.width, sizeOfProdcutCatalogsCell.height);
    else
        rect=CGRectMake((currentIndex % numberOfColumns)*(sizeOfProdcutCatalogsCell.width+VIEWGAP)+LEFTGAP, (sizeOfProdcutCatalogsCell.height +TOPGAP) *(currentIndex / numberOfColumns)+TOPGAP, sizeOfProdcutCatalogsCell.width, sizeOfProdcutCatalogsCell.height);
    return rect;
}

- (void)modifyProductListviewWidth{
    
    numberOfColumns = [self.delegate numberOfColumnsForLandscape];
    if (productlistview) {
        [productlistview modifySingleProductviewWidth];
    }
	self.catalogScrollView.frame = self.view.bounds;
	if (wideShow){
		catalogScrollView.contentSize=CGSizeMake(catalogScrollView.frame.size.width,(numberOfRows+1) *(sizeOfProdcutCatalogsCell.height +34.0));
	}else{
		catalogScrollView.contentSize=CGSizeMake(catalogScrollView.frame.size.width,(numberOfRows+1) *(sizeOfProdcutCatalogsCell.height +34.0));
	}
	
	NSArray *cellarray=[self.catalogScrollView subviews];
	
	for(int i = 0; i < [cellarray count]; i++){
		CatalogView *aCell = [cellarray objectAtIndex:i];
		CGRect rect = [self productSubviewChangeByIndex:i];
        //aCell.frame = rect;
        [UIView animateWithDuration:0.3 animations:^(void){
            aCell.alpha = 0.3;
        }completion:^(BOOL finished){
            aCell.frame = rect;
            aCell.alpha = 1.0f;
        }];
	}
    
}


#pragma mark -Load Data
- (void)fadIn:(id)sender
{
    //remove all subview in scrollview
    NSArray *cellarray=[self.catalogScrollView subviews];
	[cellarray makeObjectsPerformSelector:@selector(removeFromSuperview)];
    //end
    
    /*if (self.productlistview.view.superview) {
     [self.productlistview.view removeFromSuperview];
     }*/
    if (numberOfProductCatalog % numberOfColumns)
		numberOfRows += 1;
	
	if ((numberOfRows+1) *(sizeOfProdcutCatalogsCell.height +34.0)<=self.catalogScrollView.frame.size.height) {
		catalogScrollView.contentSize=CGSizeMake(catalogScrollView.frame.size.width,self.catalogScrollView.frame.size.height+1);
	}else{
		catalogScrollView.contentSize=CGSizeMake(catalogScrollView.frame.size.width,(numberOfRows+1) *(sizeOfProdcutCatalogsCell.height +34.0));
	}
    for (int i=0; i<numberOfProductCatalog; i++) {
        
        CGRect rect = [self productSubviewChangeByIndex:i];
        //load catalog entity 
        FDProductEntity *productCatalogEntity=[delegate productCatalogForIndex:i];
        CatalogView *oneCatalogview=[[CatalogView alloc] initWithFrame:rect productCatalogEntity:productCatalogEntity withPageType:pageType delegate:self];
        oneCatalogview.tag=i;
        [catalogScrollView addSubview:oneCatalogview];
        [oneCatalogview release];
        
    }
    [UIView animateWithDuration:0.3 animations:^(void){
        self.catalogScrollView.alpha=1.0;
        self.isHidden = NO;
         //productlistview.view.alpha=0.0;
    }];
}


- (void)loadData:(NSString *)bigCatalogID
{
    
    //first load all the catalog data
    [UIView animateWithDuration:0.3 delay:0.0f 
                        options:UIViewAnimationOptionAllowUserInteraction|UIViewAnimationOptionCurveLinear 
                     animations:^(void){
                         
                         //init data
                         numberOfColumns = [self.delegate numberOfColumnsForLandscape];
                         numberOfProductCatalog = [self.delegate numberOfProdcutCatalogs:bigCatalogID];  
                         sizeOfProdcutCatalogsCell=[self.delegate sizeOfCatalogsCell];
                         numberOfRows = numberOfProductCatalog / numberOfColumns;
                         pageType = [self.delegate getCurrentPageType];
                         //end
                         self.catalogScrollView.alpha=0.9;
                         self.isHidden = YES;
                     }completion:^(BOOL reslut){
                         //
                         [self fadIn:nil];
                         [ModalAlert stopBlockWait];
                         //remove productlistview
                         if (productlistview.view.superview) {
                             
                             [UIView animateWithDuration:0.3f animations:^(void){
                                 productlistview.view.alpha=0.0;   
                             }];
                             
                         }
                         
                     }];
    
}


- (void)didCatalogSelected:(id)object_ location:(CGPoint)location
{
    if (pageType==CasePage||pageType==ProdctShowPage) {
        
        [self.delegate didProductSelect:object_];
        
    }else {
        
        FDProductEntity *productEntity = (FDProductEntity *)object_;
        
        NSArray *tmpProducts=[self.delegate getArrayOfProductCatalogID:productEntity.style];
        self.currentpArray=tmpProducts;
        
        if(!productlistview){
            
            productlistview =[[MainProductListViewController alloc] initWithFrame:catalogScrollView.frame];
            productlistview.productlist_delegate=self;
            productlistview.view.backgroundColor = [UIColor whiteColor];
            
        }
        productlistview.view.frame = self.catalogScrollView.frame;	
        productlistview.wideShow = self.wideShow;
        [UIView animateWithDuration:0.3 animations:^(void){
            //load product list
            [self.view addSubview:productlistview.view];
            [productlistview updateView:nil location:location];
            self.catalogScrollView.alpha=0.9;
            self.isHidden = YES;
        }];
        
    }
}


#pragma mark ------
#pragma mark mainproductlist delegate
- (CGSize)getSizeOfProdcutView{
    return SINGLEPRODUCTVIEWSIZE;
}

- (NSUInteger)numberOfProdcutsInView{
    return [self.currentpArray count];
}

- (id)productEntityForIndex:(NSUInteger)index{
    return [self.currentpArray objectAtIndex:index];
}

- (NSUInteger)numberOfColumnsForProductListLandscape{
    return numberOfColumns;
}

- (void)jrxProductListController:(MainProductListViewController *)jrxProductListController 
                                doneProductSelect:(id)detailEntity_object{
    [UIView animateWithDuration:0.3 animations:^{
        self.catalogScrollView.alpha = 1.0;
        self.isHidden = NO;
    }];
}



#pragma mark ---
#pragma mark productcatalogview delegate
-(void)didSelected:(id)sender
{
    int tag=((CatalogView *)sender).tag;
    FDProductEntity *catalogEntity = [self.delegate productCatalogForIndex:tag];
    [self didCatalogSelected:catalogEntity location:((CatalogView *)sender).center]; 
}


//- (NSArray *)ArrayOfProductCatalogID:(NSString *)smallcatalogID
//{
//	return [self.delegate getArrayOfProductCatalogID:smallcatalogID];
//}


@end

