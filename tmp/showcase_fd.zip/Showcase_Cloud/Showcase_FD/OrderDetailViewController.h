//
//  OrderDetailViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 4/3/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol OrderDetailViewControllerDelegate <NSObject>

- (void)orderDidSaved;

@end

@class FDOrderEntity;

@interface OrderDetailViewController : UIViewController

@property (nonatomic, retain) FDOrderEntity * order;

@property (nonatomic, assign) id <OrderDetailViewControllerDelegate> delegate;

@end
