//
//  CityEntity.h
//  Showcase_FD
//
//  Created by Yue Gu on 12-4-3.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#define CITY_TABLE_NAME @"T_City"

#define CITY_TABLE_COLUMN_NAME_NAME @"CityName"
#define CITY_TABLE_COLUMN_NAME_PROVINCE_ID @"ProID"
#define CITY_TABLE_COLUMN_NAME_SORT @"CitySort"

@interface CityEntity : NSObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * provinceID;
@property (nonatomic, retain) NSString * sort;

@end
