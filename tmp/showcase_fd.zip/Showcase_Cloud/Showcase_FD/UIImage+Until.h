//
//  UIImage+Until.h
//  Showcase_FD
//
//  Created by august on 12-3-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//


@class FDProductEntity;
@interface UIImage (Until)
+(UIImage *)imageWithImage:(UIImage *)image borderImage:(UIImage *)borderImage;
+(BOOL)saveImageToLocal:(UIImage *)image filePath:(NSString *)path;
+ (UIImage *)getProductThumbImage:(FDProductEntity *)productEntity;
+ (UIImage *)productImageName:(NSString *)name;
+ (UIImage *)getQuickOrderProductThumbImage:(FDProductEntity *)productEntity;
@end
