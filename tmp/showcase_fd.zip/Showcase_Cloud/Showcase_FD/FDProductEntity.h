//
//  FDProductEntity.h
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FDProductEntity : NSObject

@property (nonatomic) int productID;
@property (nonatomic, retain) NSString *sku;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *type;
@property (nonatomic) int style;
@property (nonatomic) int room;
@property (nonatomic, retain) NSString *styleName;
@property (nonatomic, retain) NSString *styleCode;
@property (nonatomic, retain) NSString *roomName;
@property (nonatomic, retain) NSString *lwh;
@property (nonatomic, retain) NSString *shortcut;
@property (nonatomic, retain) NSString *material;
@property (nonatomic) float price;
@property (nonatomic, retain) NSString *currency;
@property (nonatomic, retain) NSString *thumbImage;
@property (nonatomic, retain) NSString *fullImage;
@property (nonatomic, retain) NSString *related;
@property (nonatomic) int publish;
@property (nonatomic, retain) NSString *attibute;
@property (nonatomic, retain) NSString *desc;
@property (nonatomic, retain) NSDate *createdTime;
@property (nonatomic, retain) NSString *createdBy;
@property (nonatomic, retain) NSDate *updatedTime;
@property (nonatomic, retain) NSString *updatedBy;
@property (nonatomic) int deleted;

@end
