//
//  HistoryOrderDetailViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 4/3/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FDOrderEntity;

@interface HistoryOrderDetailViewController : UIViewController

@property (retain, nonatomic) FDOrderEntity * order;

@end
