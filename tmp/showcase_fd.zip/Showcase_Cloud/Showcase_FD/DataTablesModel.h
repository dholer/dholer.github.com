//
//  DataTablesModel.h
//  iPadSales
//
//  Created by Fjl on 11-2-23.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"
#import "FMResultSet.h"
#import "JSON.h"


@interface DataTablesModel : NSObject {

	NSMutableDictionary			*dataCacheDictionary;
	NSMutableString             *tableName;

}
@property(nonatomic,retain)	NSMutableString             *tableName;
-(BOOL) saveEntity:(id) entity;
-(int)  syncEntity:(id) retmotingData;
+ (NSString *)getMD5FromString:(NSString *)source;
+ (NSString *)GetUUID;
+(NSDateFormatter *)getDateFormatter;
+(id)getImagesByImageName:(NSString *)imageName tryToGetMain:(BOOL) tryMain;
@end
