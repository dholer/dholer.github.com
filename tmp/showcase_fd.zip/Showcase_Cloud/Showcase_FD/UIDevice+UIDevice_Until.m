//
//  UIDevice+UIDevice_Until.m
//  Showcase_FD
//
//  Created by august on 12-3-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UIDevice+UIDevice_Until.h"

@implementation UIDevice (UIDevice_Until)

+ (NSString *)getUUID{
    NSString *uuid = nil;
    CFUUIDRef theUUID = CFUUIDCreate(kCFAllocatorDefault);
    if (theUUID) {
        uuid = NSMakeCollectable(CFUUIDCreateString(kCFAllocatorDefault, theUUID));
        [uuid autorelease];
        CFRelease(theUUID);
    } 
    return uuid;
}

@end
