//
//  SingleProductView.m
//  Showcase_FD
//
//  Created by august on 12-3-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "SingleProductView.h"
#import "FDProductEntity.h"
#import "Constants.h"
#import "UIImage+Until.h"
@implementation SingleProductView
@synthesize currentProduct;
@synthesize delegate;
- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		
		NSArray *nibObjects = [[self nib] instantiateWithOwner:self options:nil];
		
        UIView *view = [nibObjects objectAtIndex:0];
        [self addSubview:view];
		self.userInteractionEnabled=YES;
    }
	
    return self;
}

- (id)initWithFrame:(CGRect)frame withProductEntity:(FDProductEntity *)productEntity
{
    self = [self initWithFrame:frame];
    if (self) {
        // Initialization code
        //set Image
        self.currentProduct = productEntity;
        UIImage *image = [UIImage productImageName:productEntity.fullImage];
        [imageview setImage:image];
        titleLabel.text = productEntity.name;
        
        
        CGSize size = CGSizeMake(frame.size.width, frame.size.height-60);
        float scale = imageview.image.size.width/size.width>imageview.image.size.height/size.height?imageview.image.size.width/size.width:imageview.image.size.height/size.height;
        if (imageview.image) {
            imageview.frame = CGRectMake((size.width-imageview.image.size.width/scale)/2, (size.height-imageview.image.size.height/scale)/2, imageview.image.size.width/scale, imageview.image.size.height/scale); 
        }
        else {
            imageview.frame = CGRectMake(0, 0 ,0 ,0); 
        }
        //set sku
        skuLabel.text = productEntity.sku;
        //skuLabel.frame = CGRectMake(skuLabel.frame.origin.x, skuLabel.frame.origin.x+15, skuLabel.frame.size.width, skuLabel.frame.size.height);
        
        //cart button
        [shopCartBtn setImage:[UIImage imageNamed:@"icon-shopcart1-on.png"] forState:UIControlStateNormal];
        [shopCartBtn setImage:[UIImage imageNamed:@"icon-shopcart1.png"] forState:UIControlStateSelected];
        //shopCartBtn.frame = CGRectMake(shopCartBtn.frame.origin.x, shopCartBtn.frame.origin.x+15, shopCartBtn.frame.size.width, shopCartBtn.frame.size.height);
        //price label
        priceLabel.text = [NSString stringWithFormat:@"%@%.2f",[DataManagerModel currentPriceCurrency:productEntity],productEntity.price];
        //priceLabel.frame = CGRectMake(priceLabel.frame.origin.x, priceLabel.frame.origin.x+15, priceLabel.frame.size.width, priceLabel.frame.size.height);

    }
    return self;
}

- (UINib *)nib {
    NSBundle *classBundle = [NSBundle bundleForClass:[self class]];
    return [UINib nibWithNibName:[self nibName] bundle:classBundle];
}

- (NSString *)nibName {
    NSString *className = NSStringFromClass([self class]);
    return [NSString stringWithFormat:@"%@", className];
}

- (void)dealloc
{
    [currentProduct release];
    [super dealloc];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if ([touches count]==1) {
        isclick=YES;
    }
    
}
-(void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    isclick=NO;
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    isclick=NO;
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (isclick) {
        if ([delegate respondsToSelector:@selector(didSelectedSingleProduct:)]) {
            [delegate didSelectedSingleProduct:self.currentProduct];
        }
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
