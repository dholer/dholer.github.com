//
//  HomeViewController.m
//  Showcase_FD
//
//  Created by august on 11-10-18.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HomeViewController.h"
#import "Constants.h"
#import "FDWebservice.h"
#import "UIDevice+IdentifierAddition.h"

@implementation HomeViewController
{
    UIImageView *registerBackgroundImageView;
    UIImageView *logo;
    
    UIImageView *loginBackgroundImageView;
    UIImageView *loginlogo;
}
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.view.frame = CGRectMake(0, 0, 1024.0, 768.0);
    [self showLoginBackgroundView];
    if (NO == [[FDWebservice sharedInstance] userHasRegistered]) {
        // check whether the device has been registered
        [[FDWebservice sharedInstance] getDeviceStatus:self delegate:@selector(getDeviceStatusFinished:) deviceID:[[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]];
    } else {
        if ([[FDWebservice sharedInstance] getUserId]&&![@"" isEqualToString:[[FDWebservice sharedInstance] getUserId]]) {
            //show login view for the first, offline
            [self showLoginView:self online:NO];
        }else {
            //show login view for the first, online
            [self showLoginView:self online:YES];
        }
    }
    
    tabbarcontrollerEx = [[UITabBarControllerEx alloc] init];    
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    // added by Alex @ 2012.4.25
    if ([[FDWebservice sharedInstance] needToRegisterWithoutDeleteApp]) {
        [[FDWebservice sharedInstance] setNeedToRegisterWithoutDeleteApp:NO];
        [self showLoginBackgroundView];
        [self showRegisterBackgroundView];
        [self showRegisterView:self];
    }
    // 
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil; 
}


- (void)dealloc {
    [tabbarcontrollerEx release],tabbarcontrollerEx = nil;
    [super dealloc];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    return;
} 

- (void)getDeviceStatusFinished:(id)retData
{
    NSLog(@"%@", retData);
    NSString *status=[[[retData objectForKey:@"results"] objectAtIndex:0]objectForKey:@"status"];
    if ([status isEqualToString:@"200"]) {
        [self showRegisterBackgroundView];
        [self showRegisterView:self];
    } else if ([@"210" isEqualToString:status] || [@"218" isEqualToString:status]) {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"消息"
                                                         message:@"该设备已经注册，请联系供应商管理员获取用户名和密码" 
                                                        delegate:nil
                                               cancelButtonTitle:nil
                                               otherButtonTitles:@"确定", nil] autorelease];
        [alert show];
        [self showLoginView:self online:YES];
        [[FDWebservice sharedInstance] setUserHasRegistered:YES];
    } else if ([@"217" isEqualToString:status]) {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"警告"
                                                         message:@"帐号已过期，请联系供应商管理员" 
                                                        delegate:self
                                               cancelButtonTitle:nil
                                               otherButtonTitles:@"确定", nil] autorelease];
        //alert.tag = 1032;
        [alert show];
        
        [self showLoginView:self online:YES];
        [[FDWebservice sharedInstance] setUserHasRegistered:YES];
    }
    else if ([@"208" isEqualToString:status]) {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"警告"
                                                         message:@"设备尚未激活，请联系供应商管理员并及时查收邮件" 
                                                        delegate:self
                                               cancelButtonTitle:nil
                                               otherButtonTitles:@"确定", nil] autorelease];
        //alert.tag = 1032;
        [alert show];
        
        [self showLoginView:self online:YES];
        [[FDWebservice sharedInstance] setUserHasRegistered:YES];
    }
    else {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"错误"
                                                         message:@"网络故障，不能判断设备是否已经注册" 
                                                        delegate:nil
                                               cancelButtonTitle:nil
                                               otherButtonTitles:@"确定", nil] autorelease];
        [alert show];
        [self showRegisterBackgroundView];
        [self showRegisterView:self];
    }
}

- (void)showLoginView:(UIViewController *)viewcontroller online:(BOOL)online
{
	LoginViewController *loginview = [[[LoginViewController alloc]init] autorelease];
    [loginview setDelegate:self];
    [loginview setOnline:online];
    loginview.modalPresentationStyle = UIModalPresentationFormSheet;
    loginview.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [viewcontroller presentModalViewController:loginview animated:YES];
    loginview.view.superview.frame = CGRectMake(0, 0, 410, 305);
    loginview.view.superview.center = CGPointMake(512, 384);
}

- (void)showRegisterView:(UIViewController *)viewController
{
	RegisterViewController *registerViewController = [[[RegisterViewController alloc]init] autorelease];
    [registerViewController setDelegate:self];
    registerViewController.modalPresentationStyle = UIModalPresentationFormSheet;
    [viewController presentModalViewController:registerViewController animated:YES];
    registerViewController.view.superview.frame = CGRectMake(0, 0, 454, 476);
    registerViewController.view.superview.center = CGPointMake(512, 384);
    
}

- (void)showRegisterBackgroundView
{
    registerBackgroundImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"login-bg.jpg"]];
    [registerBackgroundImageView setFrame:CGRectMake(0, 0, 1024, 768)];
    [[self view] addSubview:registerBackgroundImageView];
    [registerBackgroundImageView release];
}
- (void)showLoginBackgroundView
{
    loginBackgroundImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"login-bg.jpg"]];
    [loginBackgroundImageView setFrame:CGRectMake(0, 0, 1024, 768)];
    [[self view] addSubview:loginBackgroundImageView];
    [loginBackgroundImageView release];
}

#pragma mark - RegisterViewControllerDelegate
- (void)dismissBackgroundViews
{
    if (self.modalViewController) {
        [self dismissModalViewControllerAnimated:NO];
    }
    
    [registerBackgroundImageView removeFromSuperview];
    [logo removeFromSuperview];
    [self showLoginView:self online:YES];
}

#pragma mark - LoginViewControllerDelegate
- (void)loginViewControllerDismissBackgroundViews
{
    if (self.modalViewController) {
        [self dismissModalViewControllerAnimated:NO];
    }
    
    [loginBackgroundImageView removeFromSuperview];
}

-(IBAction)didButtonSelected:(id)sender{
	
    UIButton *btn = (UIButton *)sender;
    if (tabbarcontrollerEx) {
        
        [self.navigationController pushViewController:tabbarcontrollerEx animated:YES];
        UIView *customTabbarview = [tabbarcontrollerEx.view viewWithTag:1001];
        UITabBarButtonEx *tabBtn = (UITabBarButtonEx *)[customTabbarview viewWithTag:btn.tag];
        UIButton *tempBtn = (UIButton *)[tabBtn viewWithTag:btn.tag];
        [tabbarcontrollerEx tabBarBtnPressed:tempBtn];
        
    }
}

@end
