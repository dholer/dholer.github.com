//
//  NSString+HTML.m
//  Showcase_FD
//
//  Created by Yue Gu on 4/18/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import "NSString+HTML.h"

@implementation NSString (HTML)

+ (NSString *)stringFromHTMLString:(NSString *)htmlString
{
    if (!htmlString) return nil;
    
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"<p>" withString:@"\n"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"</p>" withString:@"\n"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@" "];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"<br/>" withString:@"\n                      "];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
    
    return htmlString;
}

@end
