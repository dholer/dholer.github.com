//
//  FDImage.m
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "FDFileEntity.h"

@implementation FDFileEntity

@synthesize fileID = _fileID;
@synthesize kind = _kind;
@synthesize title = _title;
@synthesize name = _name;
@synthesize createdTime = _createdTime;
@synthesize createdBy = _createdBy;
@synthesize updatedTime = _updatedTime;
@synthesize updatedBy = _updatedBy;
@synthesize deleted = _deleted;
@synthesize flag = _flag;

- (void) dealloc
{
    [_kind release];
    [_title release];
	[_name release];
	[_createdTime release];
	[_createdBy release];
	[_updatedTime release];
	[_updatedBy release];
	
	[super dealloc];
}

@end
