//
//  ZoneEntity.h
//  Showcase_FD
//
//  Created by Yue Gu on 12-4-3.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#define ZONE_TABLE_NAME @"T_Zone"

#define ZONE_TABLE_COLUMN_NAME_ZONE_ID @"ZoneID"
#define ZONE_TABLE_COLUMN_NAME_NAME @"ZoneName"
#define ZONE_TABLE_COLUMN_NAME_CITY_ID @"CityID"

@interface ZoneEntity : NSObject

@property (nonatomic, retain) NSString * zoneID;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * cityID;

@end
