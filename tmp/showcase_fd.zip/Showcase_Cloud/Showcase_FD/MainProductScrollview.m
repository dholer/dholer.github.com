//
//  MainProductScrollview.m
//  Showcase_FD
//
//  Created by august on 12-3-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MainProductScrollview.h"

@implementation MainProductScrollview

float distance (CGPoint p1, CGPoint p2)
{
	float dx = p2.x - p1.x;
	float dy = p2.y - p1.y;
	
	return sqrt(dx*dx + dy*dy);
}


#pragma mark -Touch Event
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(touches.count==2)
    {
        // get touches
		UITouch *touch1 = [[touches allObjects] objectAtIndex:0];
		UITouch *touch2 = [[touches allObjects] objectAtIndex:1];
		
		// find current and previous points
		CGPoint cpoint1 = [touch1 locationInView:self];
		CGPoint cpoint2 = [touch2 locationInView:self];
		
		// calculate distances between the points
        firtdist = distance(cpoint1, cpoint2);
        touchCenter.x=ABS(cpoint1.x-cpoint2.x)/2;
        touchCenter.y=ABS(cpoint1.y-cpoint2.y)/2;
		finished = NO;
        multitouch=YES;
    }
}


-(void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    multitouch=NO;
}


-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(touches.count==2){
        // get touches
		UITouch *touch1 = [[touches allObjects] objectAtIndex:0];
		UITouch *touch2 = [[touches allObjects] objectAtIndex:1];
		
		// find current and previous points
		CGPoint cpoint1 = [touch1 locationInView:self];
        //	CGPoint ppoint1 = [touch1 previousLocationInView:self];
		CGPoint cpoint2 = [touch2 locationInView:self];
        //	CGPoint ppoint2 = [touch2 previousLocationInView:self];
		
		// calculate distances between the points
		CGFloat cdist = distance(cpoint1, cpoint2);
		//CGFloat pdist = distance(ppoint1, ppoint2);
        
		// The pinch has to exceed a minimum distance
		if (ABS(cdist - firtdist) < MIN_PINCH) return;
		
		if (cdist < firtdist)
        {
			touchtype = UITouchPinchIn;
            [self viewTouchesMove:UITouchPinchIn lastdistance:cdist];
		}
        else
        {
			touchtype = UITouchPinchOut;
            [self viewTouchesMove:UITouchPinchIn lastdistance:cdist];
		}
		finished = YES;
		return;
        
    }
}


-(void)viewTouchesMove:(int)touchPinchType lastdistance:(CGFloat)lastdistance
{
    if (touchPinchType==UITouchPinchIn) {
        CGFloat rate=(firtdist-lastdistance)/firtdist;
        for (int i=0;i<[self.subviews count]; i++) {
            UIView *cell=(UIView *)[self.subviews objectAtIndex:i];
            CGPoint lastPoint;
            CGFloat xdistance=ABS(cell.center.x -touchCenter.x)*rate;
            CGFloat ydistance=ABS(cell.center.y -touchCenter.y)*rate;
            if (cell.center.x>touchCenter.x) {
                lastPoint.x=cell.center.x -xdistance;
                lastPoint.y=cell.center.y -ydistance;
            }
            cell.center=lastPoint;
        }
        
    }
    else
    {
        CGFloat rate=(firtdist-lastdistance)/firtdist;
        for (int i=0;i<[self.subviews count]; i++) {
            UIView *cell=(UIView *)[self.subviews objectAtIndex:i];
            CGPoint lastPoint;
            CGFloat xdistance=ABS(cell.center.x -touchCenter.x)*rate;
            CGFloat ydistance=ABS(cell.center.y -touchCenter.y)*rate;
            if (cell.center.x>touchCenter.x) {
                lastPoint.x=cell.center.x +xdistance;
                lastPoint.y=cell.center.y +ydistance;
            }
            cell.center=lastPoint;
			
        }
    }
}


-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (touchtype == UITouchPinchIn){
        
        
    }else if (touchtype == UITouchPinchOut)
    {
        
    }
}


@end
