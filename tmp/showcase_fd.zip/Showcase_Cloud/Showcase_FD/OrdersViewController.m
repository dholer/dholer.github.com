//
//  OrdersViewController.m
//  Showcase_FD
//
//  Created by august on 12-3-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "OrdersViewController.h"


#import "DataManagerModel.h"
#import "FDProductEntity.h"
#import "HistoryOrderDetailViewController.h"
#import "Constants.h"
#import "ModalAlert.h"
#import "UIImage+Until.h"

#define KeyBoardHeight 352
#define DefaultSale 1.0

#define ORDER_ITEMS_TABLE_VIEW_COUNT_TAG 1000000
#define ORDER_ITEMS_TABLE_VIEW_PRICE_TAG 2000000
#define ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TAG 3000000
#define ORDER_ITEMS_TABLE_VIEW_DISCOUNT_PRICE_TAG 4000000
#define ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TOTAL_TAG 5000000
#define ORDER_ITEMS_TABLE_VIEW_NOTE_TAG 6000000
#define ORDER_ITEMS_TABLE_VIEW_FLAG_BUTTON_TAG 7000000
#define ORDER_ITEMS_TABLE_VIEW_DELETE_BUTTON_TAG 8000000

#define TOTAL_DISCOUNT_TEXT_FIELD_TAG 900000

@implementation OrdersViewController

@synthesize historyOrderViewController = _historyOrderViewController;
@synthesize currentOrderItems = _currentOrderItems;
@synthesize orderItemsTableView;

- (NSMutableArray *)currentOrderItems
{
    _currentOrderItems = [[[DataManagerModel sharedDataModel] arrayData] mutableCopy];
    return _currentOrderItems;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [_historyOrderViewController release];
    [_currentOrderItems release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark ------
#pragma mark GUI interactions

- (void)OrderSheetClick:(id)sender {
    
    //go to detail view directly
    [self showOrderDetailView:self];
    
    /*UIButton *btn = (UIButton *)sender;
     switch (btn.tag) {
     case 10300:
     
     break;
     case 10301:
     [self showOrderDetailView:self];
     break;
     case 10302: {
     
     }
     break;
     default:
     break;
     }*/
}

- (void)historyOrderButtonPressed
{
    [UIView animateWithDuration:0.3 animations:^{
        [[[self historyOrderViewController] view] setHidden:![[[self historyOrderViewController] view] isHidden]];
    }];
}

-(void)showOrderDetailView:(UIViewController *)viewController
{
	OrderDetailViewController *orderDetailViewController = [[[OrderDetailViewController alloc] init] autorelease];
    FDOrderEntity * anOrder = [[FDOrderEntity alloc] init];
    [anOrder setOrderItems:[self currentOrderItems]];
    [anOrder setTotal:[[totalMoney text] floatValue]];
    [anOrder setTotalDiscount:[[totalDiscountTextField text] floatValue]];
    [anOrder setFinalTotal:[[totalTextField text] floatValue]];
    [anOrder setNote:[noteTextField text]];
    [anOrder setCreatedDate:[NSDate date]];
    [orderDetailViewController setOrder:anOrder];
    
    [anOrder release];
    [orderDetailViewController setDelegate:self];
    orderDetailViewController.modalPresentationStyle = UIModalPresentationFormSheet;
    orderDetailViewController.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [viewController presentModalViewController:orderDetailViewController animated:YES];
	
    orderDetailViewController.view.superview.frame = CGRectMake(0, 0, 884, 645);   
    orderDetailViewController.view.superview.backgroundColor = [UIColor clearColor];
	orderDetailViewController.view.superview.center = viewController.view.center;
    
}

- (void)orderItemFlagButtonPressed:(id)sender
{
    int cellRow = [sender tag] - ORDER_ITEMS_TABLE_VIEW_FLAG_BUTTON_TAG;
    FDOrderItemEntity *orderItemEntity = [[self currentOrderItems] objectAtIndex:cellRow];
    if (![orderItemEntity flag]) {
        [orderItemEntity setFlag:1];
        [[orderItemEntity product] setSku:[NSString stringWithFormat:@"%@-D", [[orderItemEntity product] sku]]];
    } else {
        [orderItemEntity setFlag:0];
        [[orderItemEntity product] setSku:[[[orderItemEntity product] sku] substringToIndex:[[[orderItemEntity product] sku] length] - 2]];
        [orderItemEntity setDiscount:[[totalDiscountTextField text] floatValue]];
        [orderItemEntity setDiscountPrice:[[orderItemEntity product] price] * [orderItemEntity discount]];
        [self calculateTotal];
    }
    [self.orderItemsTableView reloadData];
}

- (void)orderItemDeleteButtonPressed:(id)sender
{
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"消息"
                                                     message:@"确定要删除当前订单条目么？" 
                                                    delegate:self
                                           cancelButtonTitle:@"确定"
                                           otherButtonTitles:@"取消", nil] autorelease];
    [alert setTag:([sender tag] - ORDER_ITEMS_TABLE_VIEW_DELETE_BUTTON_TAG)];
    [alert show];
}

- (void)calculateTotal
{
    float total = 0.00;
    float discountTotal = 0.00;
    for (FDOrderItemEntity *item in [[DataManagerModel sharedDataModel] arrayData]) {
        total += [[item product] price] * [item count];
        discountTotal += [item discountPrice] * [item count];
    }
    [totalMoney setText:[NSString stringWithFormat:@"%.2lf", total]];
    [totalTextField setText:[NSString stringWithFormat:@"%.2lf", discountTotal]];
}

#pragma mark - HistoryOrderViewControllerDelegate

- (void)didSelectOrder:(FDOrderEntity *)order
{
    HistoryOrderDetailViewController *historyOrderDetailViewController = [[[HistoryOrderDetailViewController alloc] init] autorelease];
    [historyOrderDetailViewController setOrder:order];
    [[self navigationController] pushViewController:historyOrderDetailViewController animated:YES];
}

#pragma mark - OrderDetailViewControllerDelegate

- (void)orderDidSaved
{
    [[[DataManagerModel sharedDataModel] arrayData] removeAllObjects];
    [self.orderItemsTableView reloadData]; 
    [[[self historyOrderViewController] historyOrderTableView] reloadData];
    [totalDiscountTextField setText:@"1.00"];
    [noteTextField setText:@""];
    [totalDiscountView setHidden:YES];
    [self calculateTotal];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    // delete the current cell data
    if (0 == buttonIndex) {
        int cellRow = [alertView tag];
        [[[DataManagerModel sharedDataModel] arrayData] removeObjectAtIndex:cellRow];
        [self.orderItemsTableView reloadData];
        [self calculateTotal];
    }
}

#pragma mark - UITextFieldDelegate

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self.view];
    [super touchesBegan:touches withEvent:event];
    
    ruleHeight = location.y;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{        
    // When the user presses return, take focus away from the text field so that the keyboard is dismissed.        
    
    [textField resignFirstResponder];
    return YES;        
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{        
    if (textField.tag < 500) {
        return;
    }
    else if (textField.tag < 600 || textField == totalDiscountTextField){
        NSTimeInterval animationDuration = 0.30f;                
        [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];                
        [UIView setAnimationDuration:animationDuration];
        float width = self.view.frame.size.width;                
        float height = self.view.frame.size.height; 
        CGRect rect = CGRectMake(0.0f, 60-KeyBoardHeight,width,height);                
        self.view.frame = rect;        
        
        [UIView commitAnimations];  
    }
    else {
        // Do certain check if need to raise the view
        NSArray *visibaleCells = [orderItemsTableView indexPathsForVisibleRows];
        // Get the first visible row
        int topRow = [(NSIndexPath *)[visibaleCells objectAtIndex:0] row];
        UITableViewCell *parentCell = (UITableViewCell *)textField.superview.superview.superview;
        NSIndexPath *currentCellIndexPath = [orderItemsTableView indexPathForCell:parentCell];
        int currentRow = [currentCellIndexPath row];
        if (currentRow-topRow>=2) {
            NSTimeInterval animationDuration = 0.30f;                
            [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];                
            [UIView setAnimationDuration:animationDuration];
            float width = self.view.frame.size.width;                
            float height = self.view.frame.size.height; 
            CGRect rect = CGRectMake(0.0f, 60-KeyBoardHeight,width,height);                
            self.view.frame = rect;        
            
            [UIView commitAnimations];
        }
    }
    
    
    
    //   if (textField.tag % 10000 > 1) {
    //        NSTimeInterval animationDuration = 0.30f;                
    //        [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];                
    //        [UIView setAnimationDuration:animationDuration];
    //        float width = self.view.frame.size.width;                
    //        float height = self.view.frame.size.height; 
    //        CGRect rect = CGRectMake(0.0f, 60-KeyBoardHeight,width,height);                
    //        self.view.frame = rect;        
    //        
    //        [UIView commitAnimations];  
    //    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    // a, when discount textfield changed, update the discount price
    // and discount total
    // b, when count textfield changed, update the discount total
    // c, when total discount changed, update all the discount price and discount total
    // except flaged ones
    if (textField.tag >= ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TAG && textField.tag < ORDER_ITEMS_TABLE_VIEW_DISCOUNT_PRICE_TAG) {
        int cellRow = [textField tag] - ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TAG;
        UITableViewCell *cell = (UITableViewCell *)[(UIView *)textField superview];
        UITextField *countTF = (UITextField *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_COUNT_TAG + cellRow)];
        UILabel *priceLabel = (UILabel *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_PRICE_TAG + cellRow)];
        UITextField *discountTF = (UITextField *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TAG + cellRow)];
        UITextField *discountPriceTF = (UITextField *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_DISCOUNT_PRICE_TAG + cellRow)];
        UILabel *discountTotalLabel = (UILabel *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TOTAL_TAG + cellRow)];
        float newDiscountPrice = [[discountTF text] floatValue] * [[priceLabel text] floatValue];
        float newDiscountTotal = newDiscountPrice * [[countTF text] floatValue];
        [discountPriceTF setText:[NSString stringWithFormat:@"%.2lf", newDiscountPrice]];
        [discountTotalLabel setText:[NSString stringWithFormat:@"%.2lf", newDiscountTotal]];
        FDOrderItemEntity *itemToEdit = [[[DataManagerModel sharedDataModel] arrayData] objectAtIndex:cellRow];
        [itemToEdit setFlag:1];
        [itemToEdit setDiscount:[[discountTF text] floatValue]];
        [itemToEdit setDiscountPrice:[[discountPriceTF text] floatValue]];
        // calculate total 
        [self calculateTotal];
    } else if (textField.tag >= ORDER_ITEMS_TABLE_VIEW_COUNT_TAG && textField.tag < ORDER_ITEMS_TABLE_VIEW_PRICE_TAG) {
        int cellRow = [textField tag] - ORDER_ITEMS_TABLE_VIEW_COUNT_TAG;
        UITableViewCell *cell = (UITableViewCell *)[[(UIView *)textField superview] superview];
        UITextField *countTF = (UITextField *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_COUNT_TAG + cellRow)];
        UITextField *discountPriceTF = (UITextField *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_DISCOUNT_PRICE_TAG + cellRow)];
        UILabel *discountTotalLabel = (UILabel *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TOTAL_TAG + cellRow)];
        float newDiscountTotal = [[discountPriceTF text] floatValue] * [[countTF text] floatValue];
        [discountTotalLabel setText:[NSString stringWithFormat:@"%.2lf", newDiscountTotal]];
        FDOrderItemEntity *itemToEdit = [[[DataManagerModel sharedDataModel] arrayData] objectAtIndex:cellRow];
        [itemToEdit setCount:[[countTF text] intValue]];
        // calculate total 
        [self calculateTotal];
    } else if (textField == totalDiscountTextField) {
        for (int i = 0; i < [self.currentOrderItems count]; ++i) {
            FDOrderItemEntity *itemToEdit = [[[DataManagerModel sharedDataModel] arrayData] objectAtIndex:i];
            if (!itemToEdit.flag) { 
                UITableViewCell *cell = [orderItemsTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]]; 
                UITextField *countTF = (UITextField *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_COUNT_TAG + i)];
                UILabel *priceLabel = (UILabel *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_PRICE_TAG + i)];
                UITextField *discountTF = (UITextField *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TAG + i)];
                UITextField *discountPriceTF = (UITextField *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_DISCOUNT_PRICE_TAG + i)];
                UILabel *discountTotalLabel = (UILabel *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TOTAL_TAG + i)];
                float newDiscount = [[totalDiscountTextField text] floatValue];
                float newDiscountPrice = newDiscount * [[priceLabel text] floatValue];
                float newDiscountTotal = newDiscountPrice * [[countTF text] floatValue];
                [discountTF setText:[NSString stringWithFormat:@"%.2lf", newDiscount]];
                [discountPriceTF setText:[NSString stringWithFormat:@"%.2lf", newDiscountPrice]];
                [discountTotalLabel setText:[NSString stringWithFormat:@"%.2lf", newDiscountTotal]];
                [itemToEdit setDiscount:[[discountTF text] floatValue]];
                [itemToEdit setDiscountPrice:[[discountPriceTF text] floatValue]];
                // calculate total 
                [self calculateTotal];
            }
        }
    }
    NSTimeInterval animationDuration = 0.30f;        
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];        
    [UIView setAnimationDuration:animationDuration];        
    CGRect rect = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height);        
    self.view.frame = rect;        
    [UIView commitAnimations];        
    //    [textField resignFirstResponder];
}


#pragma mark - UITextViewDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if (textView.tag % 10000 > 1) {
        NSTimeInterval animationDuration = 0.30f;                
        [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];                
        [UIView setAnimationDuration:animationDuration];
        float width = self.view.frame.size.width;                
        float height = self.view.frame.size.height; 
        CGRect rect = CGRectMake(0.0f, 60-KeyBoardHeight,width,height);                
        self.view.frame = rect;        
        
        [UIView commitAnimations];  
    }
}
- (void)textViewDidEndEditing:(UITextView *)textView
{
    if (textView.tag >= ORDER_ITEMS_TABLE_VIEW_NOTE_TAG && textView.tag < ORDER_ITEMS_TABLE_VIEW_FLAG_BUTTON_TAG) {
        int cellRow = [textView tag] - ORDER_ITEMS_TABLE_VIEW_NOTE_TAG;
        UITableViewCell *cell = (UITableViewCell *)[(UIView *)textView superview];
        UITextView *noteTV = (UITextView *)[cell viewWithTag:(ORDER_ITEMS_TABLE_VIEW_NOTE_TAG + cellRow)];
        FDOrderItemEntity *itemToEdit = [[[DataManagerModel sharedDataModel] arrayData] objectAtIndex:cellRow];
        [itemToEdit setNote:[noteTV text]];
    }
    NSTimeInterval animationDuration = 0.30f;        
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];        
    [UIView setAnimationDuration:animationDuration];        
    CGRect rect = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height);        
    self.view.frame = rect;        
    [UIView commitAnimations];        
    [textView resignFirstResponder];
}

#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated 
{
    [super viewWillAppear:animated];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.orderItemsTableView setRowHeight:103];
    float total=0;
    float discountTotal = 0;
    for (int i = 0; i < [self.currentOrderItems count]; ++i) {
        FDOrderItemEntity *fd = [self.currentOrderItems objectAtIndex:i];
        if (fd.flag == 0) {
            fd.discount = [totalDiscountTextField.text floatValue];
        }
        total += fd.count*fd.product.price;
        discountTotal += fd.count*fd.product.price*fd.discount;
    }
    totalMoney.text = [NSString stringWithFormat:@"%.2lf", total];
    [totalTextField setText:[NSString stringWithFormat:@"%.2lf", discountTotal]];
    [self.orderItemsTableView reloadData];
    [[[self historyOrderViewController] historyOrderTableView] reloadData];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.superview.backgroundColor = [UIColor clearColor];
    
    self.orderItemsTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 130, 1024, 523) style:UITableViewStylePlain];
	self.orderItemsTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
	self.orderItemsTableView.backgroundColor = [UIColor clearColor];
	self.orderItemsTableView.delegate = self;
	self.orderItemsTableView.dataSource = self;
    
    [self.view addSubview:self.orderItemsTableView];
    //[self.orderItemsTableView reloadData];
    ///////////////////first bar////////////////////////////////////// 
    whiteBar = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"topbar.png"]];
    whiteBar.frame = CGRectMake(0, 0, 1024, 45);
    [self.view addSubview:whiteBar];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 1024, 45)]; 
    titleLabel.text = @"订单中心";
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont boldSystemFontOfSize:20];
    titleLabel.textAlignment = UITextAlignmentCenter;
    [self.view addSubview:titleLabel];
    
    
    
    UIButton *historyOrderButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [historyOrderButton setImage:[UIImage imageNamed:@"btn-history.png"] forState:UIControlStateNormal];
    [historyOrderButton setImage:[UIImage imageNamed:@"btn-history-on.png"] forState:UIControlStateHighlighted];
    historyOrderButton.frame = CGRectMake(15, 6, 84, 33);
    [self.view addSubview:historyOrderButton];
    [historyOrderButton addTarget:self action:@selector(historyOrderButtonPressed) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *historyLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 84, 33)]; 
    historyLabel.text = @"历史报价单";
    historyLabel.backgroundColor = [UIColor clearColor];
    historyLabel.font = [UIFont systemFontOfSize:13];
    historyLabel.textAlignment = UITextAlignmentCenter;
    [historyOrderButton addSubview:historyLabel];
    
    ///////////////////second bar//////////////////////////////////////
    blackbar = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bar-black.png"]];
    blackbar.frame = CGRectMake(0, 45, 1024, 40);
    [self.view addSubview:blackbar];
    
    UILabel *noteLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 50, 45, 30)]; 
    noteLabel.text = @"备注";
    noteLabel.textColor = [UIColor whiteColor];
    noteLabel.backgroundColor = [UIColor clearColor];
    noteLabel.font = [UIFont systemFontOfSize:16];
    noteLabel.textAlignment = UITextAlignmentRight;
    [self.view addSubview:noteLabel];
    
    UIButton *input = [UIButton buttonWithType:UIButtonTypeCustom];
    [input setImage:[UIImage imageNamed:@"input-other.png"] forState:UIControlStateNormal];
    input.frame = CGRectMake(50, 50, 726, 30);
    [self.view addSubview:input];
    
    noteTextField = [[UITextField alloc] init];
    noteTextField.frame = CGRectMake(15, 3.5, 696, 30);
    noteTextField.delegate = self;
    noteTextField.tag = 499;
    noteTextField.font = [UIFont boldSystemFontOfSize:18];
    noteTextField.textAlignment = UITextAlignmentLeft;
    [input addSubview:noteTextField];
    [noteTextField release];
    
    UILabel *makeLabel = [[UILabel alloc] initWithFrame:CGRectMake(781, 50, 1024-781, 30)]; 
    orderCreatedDate = [NSDate date];
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"制表日期: YYYY-MM-dd HH:mm:ss"];
    NSString* str = [formatter stringFromDate:orderCreatedDate];
    [formatter release];
    makeLabel.text = str;
    makeLabel.tag = 300;
    makeLabel.textColor = [UIColor whiteColor];
    makeLabel.backgroundColor = [UIColor clearColor];
    makeLabel.font = [UIFont systemFontOfSize:16];
    makeLabel.textAlignment = UITextAlignmentCenter;
    [self.view addSubview:makeLabel];
    
    [noteLabel release];
    [makeLabel release];
    ///////////////////third bar//////////////////////////////////////
    greenBar = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bar-green.png"]];
    greenBar.frame = CGRectMake(0, 85, 1024, 45);
    [self.view addSubview:greenBar];
    
    
    NSMutableArray *nameList = [[NSMutableArray alloc] initWithObjects:@"序号",@"名称",@"编号",@"图片",@"规格",@"数量",@"零售价",@"折扣",@"折扣单价",@"折扣总金额",@"备注", nil];
    float width[11] = {50, 95, 103, 90, 120, 65, 78, 70, 82, 91, 100};
    float x = 0;
    for (int i = 0; i < 11; ++i) {
        
        UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(x, 90, width[i], 35)]; 
        label1.text = [nameList objectAtIndex:i];
        label1.textColor = [UIColor whiteColor];
        label1.backgroundColor = [UIColor clearColor];
        label1.font = [UIFont boldSystemFontOfSize:16];
        label1.textAlignment = UITextAlignmentCenter;
        [self.view addSubview:label1];
        
        UIImageView *line1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shortline.png"]];
        line1.frame = CGRectMake(x+width[i], 94.5, 2, 26);
        [self.view addSubview:line1];
        
        [label1 release];
        [line1 release];
        
        x = x+width[i]+2;
    }
    [nameList release];
    
    //////////////////////last bar///////////////////////
    lastBar = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bar-white.png"]];
    lastBar.frame = CGRectMake(0, 653, 1024, 55);
    [self.view addSubview:lastBar];
    
    UILabel *totalLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, 48, 45)]; 
    totalLabel.text = @"总价";
    totalLabel.textColor = [UIColor blackColor];
    totalLabel.backgroundColor = [UIColor clearColor];
    totalLabel.font = [UIFont systemFontOfSize:16];
    totalLabel.textAlignment = UITextAlignmentRight;
    [lastBar addSubview:totalLabel];
    
    totalMoney = [[UILabel alloc] initWithFrame:CGRectMake(50, 5, 90, 45)]; 
    totalMoney.text = @"0";
    totalMoney.textColor = [UIColor blackColor];
    totalMoney.backgroundColor = [UIColor clearColor];
    totalMoney.font = [UIFont boldSystemFontOfSize:18];
    totalMoney.textAlignment = UITextAlignmentCenter;
    [lastBar addSubview:totalMoney];
    
    UIButton *totalSaleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [totalSaleBtn setImage:[UIImage imageNamed:@"btn-sale.png"] forState:UIControlStateNormal];
    totalSaleBtn.frame = CGRectMake(200, 666, 29, 29);
    [self.view addSubview:totalSaleBtn];
    [totalSaleBtn addTarget:self action:@selector(TotalSaleClick) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *saleLabel = [[UILabel alloc] initWithFrame:CGRectMake(280, 5, 90, 45)]; 
    saleLabel.text = @"折后总金额";
    saleLabel.textColor = [UIColor blackColor];
    saleLabel.backgroundColor = [UIColor clearColor];
    saleLabel.font = [UIFont systemFontOfSize:16];
    saleLabel.textAlignment = UITextAlignmentRight;
    [lastBar addSubview:saleLabel];
    
    UIButton *inputSale = [UIButton buttonWithType:UIButtonTypeCustom];
    [inputSale setImage:[UIImage imageNamed:@"input-sale.png"] forState:UIControlStateNormal];
    inputSale.frame = CGRectMake(385, 665.5, 230, 30);
    [self.view addSubview:inputSale];
    
    totalTextField = [[UITextField alloc] init];
    totalTextField.frame = CGRectMake(15, 6.5, 200, 30);
    totalTextField.delegate = self;
    totalTextField.text = @"1.00";
    totalTextField.tag = 501;
    totalTextField.font = [UIFont boldSystemFontOfSize:18];
    totalTextField.textAlignment = UITextAlignmentLeft;
    totalTextField.keyboardType = UIKeyboardTypeNumberPad;
    [inputSale addSubview:totalTextField];
    [totalTextField release];
    
    
    NSMutableArray *nameArray = [[NSMutableArray alloc] initWithObjects:@"打印订单", @"保存订单", @"发送Email", nil];
    
    for (int i = 0; i < 3; ++i) {
        UIButton *newBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [newBtn setImage:[UIImage imageNamed:@"btn-history.png"] forState:UIControlStateNormal];
        newBtn.tag = 10300+i;
        newBtn.frame = CGRectMake(724+100*i, 655.5, 82, 40);
        [self.view addSubview:newBtn];
        [newBtn addTarget:self action:@selector(OrderSheetClick:) forControlEvents:UIControlEventTouchUpInside];
        
        UILabel *newLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 82, 40)]; 
        newLabel.text = [nameArray objectAtIndex:i];
        newLabel.backgroundColor = [UIColor clearColor];
        newLabel.font = [UIFont systemFontOfSize:13];
        newLabel.textAlignment = UITextAlignmentCenter;
        [newBtn addSubview:newLabel];
        
    }
    [nameArray release];
    ///////////////////sale 弹框/////////////////////////
    totalDiscountView = [[UIView alloc] initWithFrame:CGRectMake(163, 576, 322, 97)];
    [self.view addSubview:totalDiscountView];
    
    totalDiscountView.hidden = YES;
    
    UIImageView *backImage2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"discountpop-bg.png"]];
    backImage2.frame = CGRectMake(0, 0, 322, 97);
    [totalDiscountView addSubview:backImage2];
    [backImage2 release];
    
    UIButton *inputSale2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [inputSale2 setImage:[UIImage imageNamed:@"input-sale.png"] forState:UIControlStateNormal];
    inputSale2.frame = CGRectMake(70, 27, 230, 30);
    [totalDiscountView addSubview:inputSale2];
    
    totalDiscountTextField = [[UITextField alloc] init];
    totalDiscountTextField.frame = CGRectMake(15, 6.5, 200, 30);
    totalDiscountTextField.delegate = self;
    totalDiscountTextField.text = @"1.00";
    totalDiscountTextField.tag = 100000000;
    totalDiscountTextField.font = [UIFont boldSystemFontOfSize:18];
    totalDiscountTextField.textAlignment = UITextAlignmentLeft;
    totalDiscountTextField.keyboardType = UIKeyboardTypeNumberPad;
    [inputSale2 addSubview:totalDiscountTextField];
    [totalDiscountTextField release];
    
    UILabel *newSaleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 27, 67, 30)]; 
    newSaleLabel.textColor = [UIColor whiteColor];
    newSaleLabel.text = @"折扣";
    newSaleLabel.backgroundColor = [UIColor clearColor];
    newSaleLabel.font = [UIFont boldSystemFontOfSize:18];
    newSaleLabel.textAlignment = UITextAlignmentRight;
    [totalDiscountView addSubview:newSaleLabel];
    
    ////////////历史弹框/////////////////////////
    HistoryOrderViewController *aHistoryOrderViewController = [[HistoryOrderViewController alloc] init];
    [[aHistoryOrderViewController view] setFrame:CGRectMake(8, 32, 900, 558)];
    [[aHistoryOrderViewController view] setBackgroundColor:[UIColor clearColor]];
    [[aHistoryOrderViewController view] setHidden:YES];
    [aHistoryOrderViewController setDelegate:self];
    [self setHistoryOrderViewController:aHistoryOrderViewController];
    [[self view] addSubview:[[self historyOrderViewController] view]];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (void)TotalSaleClick 
{
    BOOL flag = totalDiscountView.hidden;
    totalDiscountView.hidden = !flag;
}

#pragma mark -
#pragma mark UITableView data source and delegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{	
	return 1;	
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self currentOrderItems] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"CellIdentifier";
    
    UITableViewCell *cell = nil; //[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    //分别具体的加载11＋1条数据的信息
    float width[11] = {50, 95, 103, 90, 120, 65, 78, 70, 82, 91, 100};
    float x = 0;
    int index = 0;
    FDOrderItemEntity *orderItemEntity = [[self currentOrderItems] objectAtIndex:[indexPath row]];
    
    //1、序号
    {
        UILabel *Label1 = [[UILabel alloc] initWithFrame:CGRectMake(x, 36.5, width[index], 30)]; 
        Label1.textColor = [UIColor blackColor];
        Label1.text = [NSString stringWithFormat:@"%d", indexPath.row+1];
        Label1.backgroundColor = [UIColor clearColor];
        Label1.font = [UIFont boldSystemFontOfSize:18];
        Label1.textAlignment = UITextAlignmentCenter;
        [cell.contentView addSubview:Label1];
        [Label1 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //2、名称
    {
        UILabel *Label2 = [[UILabel alloc] initWithFrame:CGRectMake(x, 30, width[index], 43)]; 
        Label2.textColor = [UIColor blackColor];
        Label2.text = orderItemEntity.product.name;
        Label2.numberOfLines = 2;
        Label2.backgroundColor = [UIColor clearColor];
        Label2.font = [UIFont boldSystemFontOfSize:18];
        Label2.textAlignment = UITextAlignmentCenter;
        [cell.contentView addSubview:Label2];
        [Label2 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //3、编号
    {
        UILabel *Label3 = [[UILabel alloc] initWithFrame:CGRectMake(x, 30, width[index], 43)]; 
        Label3.textColor = [UIColor blackColor];
        if (orderItemEntity.flag) {
            if (![[orderItemEntity.product.sku substringFromIndex:[orderItemEntity.product.sku length] - 2] isEqualToString:@"-D"])
                Label3.text = [NSString stringWithFormat:@"%@-D", orderItemEntity.product.sku];
            else Label3.text = orderItemEntity.product.sku;
        }
        else Label3.text = orderItemEntity.product.sku;
        Label3.numberOfLines = 0;
        Label3.backgroundColor = [UIColor clearColor];
        Label3.font = [UIFont boldSystemFontOfSize:16];
        Label3.textAlignment = UITextAlignmentCenter;
        [cell.contentView addSubview:Label3];
        [Label3 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //4、图片
    {
        CGSize size = CGSizeMake(90, 103);
        UIImage *image = [UIImage imageWithContentsOfFile:[PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:orderItemEntity.product.fullImage]];
        NSLog(@"%lf, %lf", image.size.width, image.size.height);
        float scale = image.size.width/size.width>image.size.height/size.height?image.size.width/size.width:image.size.height/size.height;
        UIImageView *image4 = [[UIImageView alloc] initWithImage:image];
        if (image) {
           image4.frame = CGRectMake(x+(size.width-image.size.width/scale)/2, (size.height-image.size.height/scale)/2, image.size.width/scale, image.size.height/scale); 
        }
        else {
            image4.frame = CGRectMake(0, 0, 0, 0);
        }
		
        //image4.frame = CGRectMake(x+18.5, 17, 53, 69);
        [cell.contentView addSubview:image4];
        [image4 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //5、规格
    {
        UILabel *Label5 = [[UILabel alloc] initWithFrame:CGRectMake(x, 36.5, width[index], 30)]; 
        Label5.textColor = [UIColor blackColor];
        Label5.text = orderItemEntity.product.lwh;
        Label5.backgroundColor = [UIColor clearColor];
        Label5.font = [UIFont systemFontOfSize:14];
        Label5.textAlignment = UITextAlignmentCenter;
        [cell.contentView addSubview:Label5];
        [Label5 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //6、数量
    {
        UIButton *Btn6 = [UIButton buttonWithType:UIButtonTypeCustom];
        [Btn6 setImage:[UIImage imageNamed:@"inputbox-number.png"] forState:UIControlStateNormal];
        Btn6.frame = CGRectMake(x+4.5, 29, 56, 45);
        [cell.contentView addSubview:Btn6];
        
        UITextField *tView6 = [[UITextField alloc] init];
        tView6.frame = CGRectMake(5, 7.5, 46, 30);
        tView6.delegate = self;
        tView6.tag = ORDER_ITEMS_TABLE_VIEW_COUNT_TAG + indexPath.row;
        tView6.text = [NSString stringWithFormat:@"%d", [orderItemEntity count]];
        tView6.font = [UIFont boldSystemFontOfSize:18];
        tView6.textAlignment = UITextAlignmentCenter;
        tView6.keyboardType = UIKeyboardTypeNumberPad;
        [Btn6 addSubview:tView6];
        [tView6 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //7、零售价
    {
        UILabel *Label7 = [[UILabel alloc] initWithFrame:CGRectMake(x+3, 36.5, width[index], 30)]; 
        Label7.textColor = [UIColor blackColor];
        Label7.text = [NSString stringWithFormat:@"%.2lf", orderItemEntity.product.price];
        Label7.backgroundColor = [UIColor clearColor];
        Label7.font = [UIFont boldSystemFontOfSize:14];
        Label7.textAlignment = UITextAlignmentCenter;
        Label7.tag = ORDER_ITEMS_TABLE_VIEW_PRICE_TAG + indexPath.row;
        [cell.contentView addSubview:Label7];
        [Label7 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //8、折扣
    {
        
        
        UITextField *tView8 = [[UITextField alloc] init];
        if (orderItemEntity.flag == 1) {
            [tView8 setBackground:[UIImage imageNamed:@"inputbox-number.png"]];
            [tView8 setEnabled:YES];
        }
        else {
            [orderItemEntity setDiscount:[totalDiscountTextField.text floatValue]];
            [tView8 setBackground:nil];
            [tView8 setEnabled:NO];
        }
        tView8.frame = CGRectMake(x+7, 29, 56, 45);
        tView8.delegate = self;
        [tView8 setEnabled:orderItemEntity.flag];
        tView8.tag = ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TAG + indexPath.row;
        tView8.font = [UIFont boldSystemFontOfSize:18];
        tView8.text = [NSString stringWithFormat:@"%.2lf", [orderItemEntity discount]];
        tView8.textAlignment = UITextAlignmentCenter;
        tView8.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        tView8.keyboardType = UIKeyboardTypeNumberPad;
        [cell.contentView addSubview:tView8];
        [tView8 release];
        
        
        
        x = x+width[index]+2;
        index++;
    }
    
    //9、折扣单价
    {
        UILabel *Label9 = [[UILabel alloc] initWithFrame:CGRectMake(x, 36.5, width[index], 30)]; 
        Label9.textColor = [UIColor blackColor];
        Label9.text = [NSString stringWithFormat:@"%.2lf", orderItemEntity.product.price*orderItemEntity.discount];
        orderItemEntity.discountPrice = orderItemEntity.product.price*orderItemEntity.discount;
        Label9.tag = ORDER_ITEMS_TABLE_VIEW_DISCOUNT_PRICE_TAG + indexPath.row;
        Label9.backgroundColor = [UIColor clearColor];
        Label9.font = [UIFont boldSystemFontOfSize:14];
        Label9.textAlignment = UITextAlignmentCenter;
        [cell.contentView addSubview:Label9];
        [Label9 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //10、折扣总金额
    {
        UILabel *Label10 = [[UILabel alloc] initWithFrame:CGRectMake(x, 36.5, width[index], 30)]; 
        Label10.textColor = [UIColor blackColor];
        Label10.text = [NSString stringWithFormat:@"%.2lf", orderItemEntity.product.price *orderItemEntity.discount* [orderItemEntity count]];
        Label10.tag = ORDER_ITEMS_TABLE_VIEW_DISCOUNT_TOTAL_TAG + indexPath.row;
        Label10.backgroundColor = [UIColor clearColor];
        Label10.font = [UIFont boldSystemFontOfSize:14];
        Label10.textAlignment = UITextAlignmentCenter;
        [cell.contentView addSubview:Label10];
        [Label10 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //11、备注
    {
        UIButton *Btn11 = [UIButton buttonWithType:UIButtonTypeCustom];
        [Btn11 setImage:[UIImage imageNamed:@"inputbox-other.png"] forState:UIControlStateNormal];
        Btn11.frame = CGRectMake(x, 11.5, 91, 80);
        [cell.contentView addSubview:Btn11];        
        
        UITextView *tView11 = [[UITextView alloc] init];
        
        tView11.frame = CGRectMake(5, 5, 81, 70);
        tView11.delegate = self;
        tView11.tag = ORDER_ITEMS_TABLE_VIEW_NOTE_TAG + indexPath.row;
        tView11.text = orderItemEntity.note;
        tView11.font = [UIFont boldSystemFontOfSize:18];
        tView11.textAlignment = UITextAlignmentLeft;
        [Btn11 addSubview:tView11];
        [tView11 release];
        
        x = x+width[index]+2;
        index++;
    }
    
    //12、其他
    {
        UIButton *Btn12_1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [Btn12_1 setImage:nil forState:UIControlStateNormal];
        Btn12_1.frame = CGRectMake(x, 11.5, 100, 30);
        [cell.contentView addSubview:Btn12_1];
        Btn12_1.tag = ORDER_ITEMS_TABLE_VIEW_FLAG_BUTTON_TAG + indexPath.row;
        [Btn12_1 addTarget:self action:@selector(orderItemFlagButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        
        UIImageView *image12_1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon-pen.png"]];
        image12_1.frame = CGRectMake(2, 2.5, 17, 25);
        [Btn12_1 addSubview:image12_1];
        [image12_1 release];
        
        UILabel *Label12_1 = [[UILabel alloc] initWithFrame:CGRectMake(22, 2.5, 60, 25)];
        if (orderItemEntity.flag)
            Label12_1.textColor = [UIColor greenColor];
        else
            Label12_1.textColor = [UIColor blackColor];
        Label12_1.text = @"定制";
        Label12_1.tag = 9110;
        Label12_1.backgroundColor = [UIColor clearColor];
        Label12_1.font = [UIFont systemFontOfSize:14];
        Label12_1.textAlignment = UITextAlignmentLeft;
        [Btn12_1 addSubview:Label12_1];
        [Label12_1 release];
        
        UIButton *Btn12_2 = [UIButton buttonWithType:UIButtonTypeCustom];
        [Btn12_2 setImage:nil forState:UIControlStateNormal];
        // Btn12_2.backgroundColor = [UIColor redColor];
        Btn12_2.frame = CGRectMake(x, 56, 100, 30);
        [cell.contentView addSubview:Btn12_2];
        Btn12_2.tag = ORDER_ITEMS_TABLE_VIEW_DELETE_BUTTON_TAG + indexPath.row;
        [Btn12_2 addTarget:self action:@selector(orderItemDeleteButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        
        UIImageView *image12_2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon-delet.png"]];
        image12_2.frame = CGRectMake(2, 7, 17, 16);
        [Btn12_2 addSubview:image12_2];
        [image12_2 release];
        
        UILabel *Label12_2 = [[UILabel alloc] initWithFrame:CGRectMake(22, 2.5, 60, 25)]; 
        Label12_2.textColor = [UIColor blackColor];
        Label12_2.text = @"删除";
        Label12_2.backgroundColor = [UIColor clearColor];
        Label12_2.font = [UIFont systemFontOfSize:14];
        Label12_2.textAlignment = UITextAlignmentLeft;
        [Btn12_2 addSubview:Label12_2];
        [Label12_2 release];            
    }
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}

#pragma Label -
- (void)PrintTime {
    UILabel *label = (UILabel *)[self.view viewWithTag:300];
    NSDate* date = [NSDate date];
    
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateFormat:@"制表日期: YYYY-MM-dd HH:mm:ss"];
    
    NSString* str = [formatter stringFromDate:date];
    
    //    NSLog(@"%@",str);
    
	label.text = str;
	
	
    [formatter release];
}



@end
