//
//  DataModel.h
//  FlashCard
//
//  Created by FJlMacMini on 10-11-24.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ProvinceEntity.h"
#import "CityEntity.h"
#import "ZoneEntity.h"
#import "FDOrderEntity.h"
#import "FDOrderItemEntity.h"

@class FDProductCatalogEntity;
@class FDFileEntity;
@class FDProductEntity;

@interface DataManagerModel : NSObject{
   NSMutableArray          *arrayData;
   NSMutableArray          *arrayCompareProducts;
}
@property (nonatomic, retain) NSMutableArray        *arrayData;
@property (nonatomic, retain) NSMutableArray        *arrayCompareProducts;
+ (DataManagerModel*)sharedDataModel;
+ (void)destoryDataModel;
+ (NSString *)localizestr:(NSString *)str;
+ (BOOL)whichLanguageIs;
+ (NSString *)currentPriceCurrency:(FDProductEntity *)product;
+ (NSString *)autoGenerateId;

#pragma mark - All

- (void)deleteAllDataAndImagesAndFiles;

#pragma mark - Quick Order
#pragma mark - shortcuts
- (NSMutableArray *)getProductShortcuts;

#pragma mark---
#pragma mark product catalog
- (NSMutableDictionary *)getAllCatagoriesToDictionary;
- (FDProductCatalogEntity *)getCatalogEntityByRoomORStyleCode:(int)code_;
#pragma mark---
#pragma mark product
- (NSMutableArray *)getAllProductByType:(NSString *)productType;
- (NSMutableArray *)getAllProductByType:(NSString *)productType withRoom:(int)roomCode withStyle:(int)styleCode;
- (NSMutableArray *)getRelatedProductEntities:(FDProductEntity *)productEntity;

#pragma mark - News
#pragma mark file

- (NSArray *)getFileEntities;

- (BOOL)setFileRead:(FDFileEntity *)fileEntity;

#pragma mark - Order
- (NSString *)generatePrintHtml:(FDOrderEntity *)orderEntity;
- (NSString *)generatePdfHtml:(FDOrderEntity *)orderEntity;
- (BOOL)addToCompare:(FDProductEntity *)product;
- (BOOL)addToChart:(FDProductEntity *)product;
- (NSArray *)getOrderItemEntitiesByOrderEntity:(FDOrderEntity *)orderEntity;
- (NSArray *)getOrderEntitiesFilteredBySearchString:(NSString *)searchString;
- (BOOL)saveOrderEntity:(FDOrderEntity *)orderEntity;
- (BOOL)removeOrderEntity:(FDOrderEntity *)orderEntity;

#pragma mark province, city, zone

- (NSArray *)getProvinceEntities;
- (NSArray *)getCityEntitiesByProvinceEntity:(ProvinceEntity *)provinceEntity;
- (NSArray *)getZoneEntitiesByCityEntity:(CityEntity *)cityEntity;

- (NSMutableArray *)getFirstProductOfRoomCategory:(int)roomCategoryID;

@end
