//
//  UITabBarControllerEx.h
//  Mauijim
//
//  Created by leo on 11-9-19.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITabBarButtonEx.h"

@interface UITabBarControllerEx : UITabBarController
{
    
}

- (void)hideTabBar;
- (IBAction)tabBarBtnPressed:(id)sender;
- (void)removeCustomTabbarView;
@end
