//
//  RegisterViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 3/28/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import "RegisterViewController.h"
#import "FDWebservice.h"
#import "HomeViewController.h"

@implementation RegisterViewController
#define HeadX 68
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

@synthesize delegate;

#pragma mark - GUI interactions

- (void)registerButtonPressed:(id)sender
{
    UIViewController *controller = nil;
    if (SYSTEM_VERSION_LESS_THAN(@"5.0")) {
        controller = [self parentViewController];
    } else {
        controller = [self presentingViewController];
    }
	if (controller) {
        NSString *cId = [[cIdTextField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSString *name = [[nameTextField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSString *number = [[numberTextField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSString *person = [[personTextField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSString *phone = [[phoneTextField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSString *email = [[emailTextField text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if ([cId length]!=0 && [name length] != 0 && [number length] != 0 && [person length] != 0 && [phone length] != 0 && [email length] != 0)
            [[FDWebservice sharedInstance] signUp:self delegate:@selector(signUpFinished:) clientId:cId userName:name userCode:number contact:person email:email phone:phone];
        else {
            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"警告"
                                                             message:@"任何一项不能为空！" 
                                                            delegate:nil
                                                   cancelButtonTitle:@"确定"
                                                   otherButtonTitles:nil] autorelease];
            [alert show];
        }
	}
}

- (void)signUpFinished:(id)retData 
{
    NSString *status=[[[retData objectForKey:@"results"] objectAtIndex:0]objectForKey:@"status"];
    if ([status isEqualToString:@"200"]) {
        [[FDWebservice sharedInstance] setUserHasRegistered:YES];
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"提示"
                                                         message:@"注册成功，请注意查收电子邮件以获取用户名和密码"
                                                        delegate:self
                                               cancelButtonTitle:@"确定"
                                               otherButtonTitles:nil] autorelease];
        [alert show];
        [[FDWebservice sharedInstance] setClientId:cIdTextField.text];
    } else {
        [[FDWebservice sharedInstance] setUserHasRegistered:NO];
        NSString *str = [[[retData objectForKey:@"results"] objectAtIndex:0]objectForKey:@"message"];
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"提示"
                                                         message:str
                                                        delegate:nil
                                               cancelButtonTitle:@"确定"
                                               otherButtonTitles:nil] autorelease];
        [alert show];
    }
}

#pragma mark -  UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
       //mod by august 2012-04-12
        [[self delegate] dismissBackgroundViews];
        //end
    }
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"%@", [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier]);
    // Do any additional setup after loading the view from its nib.
    UIImageView *registerFormBackgroundImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"loginpop-bg.png"]];
    [registerFormBackgroundImageView setFrame:CGRectMake(0, 0, 454, 476)];
    registerFormBackgroundImageView.tag = 1001;
    [[self view] addSubview:registerFormBackgroundImageView];
    [registerFormBackgroundImageView release];
    
    UIView *registerFormView = [[UIView alloc] init];
    
    registerFormView.frame = CGRectMake(0, 0, 454, 476);
    
    
    UIButton *save = [UIButton buttonWithType:UIButtonTypeCustom];
    [save setImage:[UIImage imageNamed:@"btn-saveorder.png"] forState:UIControlStateNormal];
    save.frame = CGRectMake(153.5, 400, 147, 44);
    [registerFormView addSubview:save];
    [save addTarget:self action:@selector(registerButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *back = [UIButton buttonWithType:UIButtonTypeCustom];
    [back setImage:[UIImage imageNamed:@"btn-close.png"] forState:UIControlStateNormal];
    back.frame = CGRectMake(419, 0, 35, 35);
    [registerFormView addSubview:back];
    [back addTarget:self action:nil forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *saveLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 4, 147, 36)]; 
    saveLabel.text = @"发送申请";
    saveLabel.textColor = [UIColor whiteColor];
    saveLabel.backgroundColor = [UIColor clearColor];
    saveLabel.font = [UIFont boldSystemFontOfSize:22];
    saveLabel.textAlignment = UITextAlignmentCenter;
    [save addSubview:saveLabel];
    [saveLabel release];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(167, 18, 120, 50)]; 
    titleLabel.text = @"用户申请";
    titleLabel.textColor = [UIColor greenColor];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont systemFontOfSize:26];
    titleLabel.textAlignment = UITextAlignmentCenter;
    [registerFormView addSubview:titleLabel];
    [titleLabel release];
    
    
    float offset = 54;
    //0、
    {
        UILabel *clientIdLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, HeadX, 120, 36)]; 
        clientIdLabel.text = @"企业编号：";
        clientIdLabel.textColor = [UIColor blackColor];
        clientIdLabel.backgroundColor = [UIColor clearColor];
        clientIdLabel.font = [UIFont systemFontOfSize:18];
        clientIdLabel.textAlignment = UITextAlignmentRight;
        [registerFormView addSubview:clientIdLabel];
        [clientIdLabel release];
        
        cIdTextField = [[UITextField alloc] init];
        cIdTextField.frame = CGRectMake(130, HeadX+3, 290, 30);
        cIdTextField.borderStyle = UITextBorderStyleRoundedRect;
        //        nameTextField.delegate = self;
        cIdTextField.font = [UIFont boldSystemFontOfSize:18];
        cIdTextField.textAlignment = UITextAlignmentLeft;
        [registerFormView addSubview:cIdTextField]; 
    }
    
    
    //1、
    {
        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, HeadX+offset, 120, 36)]; 
        nameLabel.text = @"用户名称：";
        nameLabel.textColor = [UIColor blackColor];
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = [UIFont systemFontOfSize:18];
        nameLabel.textAlignment = UITextAlignmentRight;
        [registerFormView addSubview:nameLabel];
        [nameLabel release];
        
        nameTextField = [[UITextField alloc] init];
        nameTextField.frame = CGRectMake(130, HeadX+3+1*offset, 290, 30);
        nameTextField.borderStyle = UITextBorderStyleRoundedRect;
//        nameTextField.delegate = self;
        nameTextField.font = [UIFont boldSystemFontOfSize:18];
        nameTextField.textAlignment = UITextAlignmentLeft;
        [registerFormView addSubview:nameTextField]; 
    }
    
    //2、
    {
        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, HeadX+2*offset, 120, 36)]; 
        nameLabel.text = @"用户编号：";
        nameLabel.textColor = [UIColor blackColor];
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = [UIFont systemFontOfSize:18];
        nameLabel.textAlignment = UITextAlignmentRight;
        [registerFormView addSubview:nameLabel];
        [nameLabel release];
        
        numberTextField = [[UITextField alloc] init];
        numberTextField.frame = CGRectMake(130, HeadX+3+2*offset, 290, 30);
        numberTextField.borderStyle = UITextBorderStyleRoundedRect;
//        numberTextField.delegate = self;
        numberTextField.font = [UIFont boldSystemFontOfSize:18];
        numberTextField.textAlignment = UITextAlignmentLeft;
        [registerFormView addSubview:numberTextField];
    }
    
    //3、
    {
        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, HeadX+3*offset, 120, 36)]; 
        nameLabel.text = @"联系人员：";
        nameLabel.textColor = [UIColor blackColor];
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = [UIFont systemFontOfSize:18];
        nameLabel.textAlignment = UITextAlignmentRight;
        [registerFormView addSubview:nameLabel];
        [nameLabel release];
        
        personTextField = [[UITextField alloc] init];
        personTextField.frame = CGRectMake(130, HeadX+3+3*offset, 290, 30);
        personTextField.borderStyle = UITextBorderStyleRoundedRect;
//        personTextField.delegate = self;
        personTextField.font = [UIFont boldSystemFontOfSize:18];
        personTextField.textAlignment = UITextAlignmentLeft;
        [registerFormView addSubview:personTextField];
    }
    
    //4、
    {
        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, HeadX+4*offset, 120, 36)]; 
        nameLabel.text = @"联系电话：";
        nameLabel.textColor = [UIColor blackColor];
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = [UIFont systemFontOfSize:18];
        nameLabel.textAlignment = UITextAlignmentRight;
        [registerFormView addSubview:nameLabel];
        [nameLabel release];
        
        phoneTextField = [[UITextField alloc] init];
        phoneTextField.frame = CGRectMake(130, HeadX+3+4*offset, 290, 30);
        phoneTextField.borderStyle = UITextBorderStyleRoundedRect;
//        phoneTextField.delegate = self;
        phoneTextField.font = [UIFont boldSystemFontOfSize:18];
        phoneTextField.textAlignment = UITextAlignmentLeft;
        [registerFormView addSubview:phoneTextField];
    }
    
    //5、
    {
        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, HeadX+5*offset, 120, 36)]; 
        nameLabel.text = @"联系邮箱：";
        nameLabel.textColor = [UIColor blackColor];
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = [UIFont systemFontOfSize:18];
        nameLabel.textAlignment = UITextAlignmentRight;
        [registerFormView addSubview:nameLabel];
        [nameLabel release];
        
        emailTextField = [[UITextField alloc] init];
        emailTextField.frame = CGRectMake(130, HeadX+3+5*offset, 290, 30);
        emailTextField.borderStyle = UITextBorderStyleRoundedRect;
        emailTextField.keyboardType = UIKeyboardTypeEmailAddress;
//        emailTextField.delegate = self;
        emailTextField.font = [UIFont boldSystemFontOfSize:18];
        emailTextField.textAlignment = UITextAlignmentLeft;
        [registerFormView addSubview:emailTextField];
    }

    [self.view addSubview:registerFormView];
    [registerFormView release];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

#pragma mark ---
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    if ([[touches anyObject] view].tag = 1001) {
        for (UIView *subview_ in [[[touches anyObject] view] subviews]) {
            if ([subview_ isKindOfClass:[UITextField class]]) {
                [subview_ resignFirstResponder];
            }
        }
    }
}

-(BOOL)disablesAutomaticKeyboardDismissal  
{  
    return NO;  
}


@end
