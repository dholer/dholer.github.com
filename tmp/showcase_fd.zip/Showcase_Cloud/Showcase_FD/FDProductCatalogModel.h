//
//  FDProductCatalogModel.h
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "DataTablesModel.h"
#import "FDProductCatalogEntity.h"

@class FDProductCatalogModel;

@protocol FDProductCatalogModelDelegate <NSObject>

- (void)productCatalogModelSyncFinished:(FDProductCatalogModel *)productCatalogModel;
- (void)productCatalogModel:(FDProductCatalogModel *) syncError:(NSError *)error;

@end

@interface FDProductCatalogModel : DataTablesModel

@property (nonatomic, assign) id <FDProductCatalogModelDelegate> delegate;

- (BOOL)synchronizeWithProductCatalogEntities:(NSArray *)productCatalogEntities;

- (BOOL)synchronizeWithRemoteJson:(id)remoteJson;

- (BOOL)addProductCatalogEntity:(FDProductCatalogEntity *)productCatalogEntity;


@end
