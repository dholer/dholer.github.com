//
//  DataModel.m
//  FlashCard
//
//  Created by FJlMacMini on 10-11-24.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "DataManagerModel.h"
#import "FMDatabase.h"
#import "JSON.h"
#import "FDProductCatalogEntity.h"
#import "FDProductEntity.h"
#import "Constants.h"
#import "FDFileEntity.h"
#import "FDOrderEntity.h"

DataManagerModel	*g_pDataModel = nil;

@implementation DataManagerModel
@synthesize arrayData;
@synthesize arrayCompareProducts;
#pragma mark -
#pragma mark Init And Dealloc 
- (id)init
{
    self = [super init];
    if(self)
    {
        arrayData = [[NSMutableArray alloc] init];
        arrayCompareProducts = [[NSMutableArray alloc] init];
    }
    
    return self;
}

+(DataManagerModel*)sharedDataModel
{
	if (!g_pDataModel){
        g_pDataModel = [[DataManagerModel alloc] init];
    }
    
	
	return g_pDataModel;
}


-(void)dealloc
{
    [arrayCompareProducts release];
    [arrayData release];
	[super dealloc];
}


+(void)destoryDataModel
{
	if (g_pDataModel)
		[g_pDataModel release];
	
	g_pDataModel = nil;
}


//language set
+ (NSString *)localizestr:(NSString *)str
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString * pLanguage = [defaults stringForKey:@"lan_perference"];
	if (pLanguage == nil)
		pLanguage = LANGUAGE_EN;
	NSString *result_str;
	
	if ([pLanguage isEqualToString:LANGUAGE_ZH])
		result_str = NSLocalizedStringFromTable(str, @"Localizable_Zh", nil);
	else if ([pLanguage isEqualToString:LANGUAGE_EN])
		result_str = NSLocalizedStringFromTable(str, @"Localizable_En", nil);
	else 
		result_str = @"no translation";
	
    return result_str;
}

+ (BOOL)whichLanguageIs{
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *language_str=[defaults stringForKey:@"lan_perference"];
	if(language_str==nil){
		
		language_str = LANGUAGE_EN;
		return NO;
	}else if ([language_str isEqualToString:LANGUAGE_ZH]) {
		return YES;
	}else if ([language_str isEqualToString:LANGUAGE_EN]) {
		return NO;
	}
	
	return YES;
}

+ (NSString *)currentPriceCurrency:(FDProductEntity *)product{
    
    if ([@"USD" isEqualToString:product.currency]) {
        return @"￥";
    }else if([@"CNY" isEqualToString:product.currency]){
        return @"￥";
    }else if([@"GBP" isEqualToString:product.currency]){
        return @"£";
    }else if([@"AUD" isEqualToString:product.currency]){
        return @"$";
    }else if([@"NZD" isEqualToString:product.currency]){
        return @"$";
    }else if([@"CAD" isEqualToString:product.currency]){
        return @"C$";
    }else if([@"AED" isEqualToString:product.currency]){
        return @"د.إ";
    }else if([@"MXP" isEqualToString:product.currency]){
        return @"Mex$";
    }else if([@"HKD" isEqualToString:product.currency]){
        return @"$";
    }else if([@"SEK" isEqualToString:product.currency]){
        return @"kr";
    }else if([@"CHF" isEqualToString:product.currency]){
        return @"SFr";
    }else if([@"PLN" isEqualToString:product.currency]){
        return @"zł";
    }else if([@"KWD" isEqualToString:product.currency]){
        return @"دينار";
    }else if([@"SAR" isEqualToString:product.currency]){
        return @"ريال,";
    }else if([@"DKK" isEqualToString:product.currency]){
        return @"kr";
    }else if([@"NOK" isEqualToString:product.currency]){
        return @"kr";
    }else if([@"INR" isEqualToString:product.currency]){
        return @"₹";
    }else if([@"IN1" isEqualToString:product.currency]){
        return @"₹";
    }else if([@"IN2" isEqualToString:product.currency]){
        return @"₹";
    }else if([@"EUR" isEqualToString:product.currency]){
        return @"€";
    }
    return @"￥";
}

+ (NSString *)autoGenerateId
{
	CFUUIDRef theUUID = CFUUIDCreate(NULL);
	CFStringRef string = CFUUIDCreateString(NULL, theUUID);
	CFRelease(theUUID);
	return [(NSString *)string autorelease];
}

#pragma mark - All

- (void)deleteAllDataAndImagesAndFiles
{
    FMDatabase *db = [FMDatabase sharedDataBase];
    [db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@", ORDER_ITEM_TABLE_NAME]];
    [db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@", ORDER_TABLE_NAME]];
    [db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@", CATALOG_TABLE_NAME]];    
    [db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@", PRODUCT_TABLE_NAME]];    
    [db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@", FILE_TABLE_NAME]];    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error = nil;
    NSArray *imageDirContents = [fileManager contentsOfDirectoryAtPath:PRODUCT_IMAGE_SOURCE_PATH error:&error];
    if (error == nil) {
        for (NSString *path in imageDirContents) {
            NSString *fullPath = [PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:path];
            [fileManager removeItemAtPath:fullPath error:&error];
        }
    }
    NSArray *fileDirContents = [fileManager contentsOfDirectoryAtPath:FILE_SOURCE_PATH error:&error];
    if (error == nil) {
        for (NSString *path in fileDirContents) {
            NSString *fullPath = [FILE_SOURCE_PATH stringByAppendingPathComponent:path];
            [fileManager removeItemAtPath:fullPath error:&error];
        }
    }
}

#pragma mark - Quick Order
#pragma mark - shortcuts
- (NSMutableArray *)getProductShortcuts
{
    NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:10];
    FMDatabase *db = [FMDatabase sharedDataBase];
    NSString *sql = [NSString stringWithFormat:@"SELECT DISTINCT %@ FROM %@ WHERE publish = 1", PRODUCT_COLUMN_NAME_SHORTCUT, PRODUCT_TABLE_NAME];
    FMResultSet *rs = [db executeQuery:sql];
    while ([rs next]) {
        [tempArray addObject:[rs stringForColumn:PRODUCT_COLUMN_NAME_SHORTCUT]];
    }
    return tempArray;
}

#pragma mark ----
#pragma mark product catalog 
- (NSMutableDictionary *)getAllCatagoriesToDictionary{
    
    NSMutableDictionary *tempDic = [NSMutableDictionary dictionaryWithCapacity:0];
    FMDatabase *db = [FMDatabase sharedDataBase];
    NSString *sql = @"select * from fd_product_catalog order by ordering";
    FMResultSet *rs = [db executeQuery:sql];
    while ([rs next]) {
        
        FDProductCatalogEntity *catalog = [[FDProductCatalogEntity alloc] init];
        catalog.catalogID = [rs intForColumn:CATALOG_COLUMN_NAME_CATALOG_ID];
        catalog.name = [rs stringForColumn:CATALOG_COLUMN_NAME_NAME];
        catalog.type = [rs stringForColumn:CATALOG_COLUMN_NAME_TYPE];
        catalog.code = [rs stringForColumn:CATALOG_COLUMN_NAME_CODE];
        catalog.order = [rs intForColumn:CATALOG_COLUMN_NAME_ORDER];
        catalog.createdTime = [rs dateForColumn:CATALOG_COLUMN_NAME_CREATED_TIME];
        catalog.createdBy = [rs stringForColumn:CATALOG_COLUMN_NAME_CREATED_BY];
        catalog.updatedTime = [rs dateForColumn:CATALOG_COLUMN_NAME_UPDATED_TIME];
        catalog.updatedBy = [rs stringForColumn:CATALOG_COLUMN_NAME_UPDATED_BY];
        
        if ([ROOM isEqualToString:catalog.type]){
            NSMutableArray *tempArray = [tempDic objectForKey:ROOM];
            if (!tempArray) {
                tempArray = [NSMutableArray arrayWithCapacity:0];
                [tempDic setObject:tempArray forKey:ROOM];  
            }
            [tempArray addObject:catalog];
            
        }else if([STYLE isEqualToString:catalog.type]){
            NSMutableArray *tempArray = [tempDic objectForKey:STYLE];
            if (!tempArray) {
                tempArray = [NSMutableArray arrayWithCapacity:0];
                [tempDic setObject:tempArray forKey:STYLE];  
            }
            [tempArray addObject:catalog];
        }
        [catalog release];
    }
    
    return tempDic;
}

- (FDProductCatalogEntity *)getCatalogEntityByRoomORStyleCode:(int)code_{
    
    FDProductCatalogEntity *catalog = [[FDProductCatalogEntity alloc] init];
    FMDatabase *db = [FMDatabase sharedDataBase];
    NSString *sql = [NSString stringWithFormat:@"select * from fd_product_catalog where catalog_id = %d",code_];
    FMResultSet *rs = [db executeQuery:sql];
    while ([rs next]) {
        catalog.catalogID = [rs intForColumn:CATALOG_COLUMN_NAME_CATALOG_ID];
        catalog.name = [rs stringForColumn:CATALOG_COLUMN_NAME_NAME];
        catalog.type = [rs stringForColumn:CATALOG_COLUMN_NAME_TYPE];
        catalog.code = [rs stringForColumn:CATALOG_COLUMN_NAME_CODE];
        catalog.order = [rs intForColumn:CATALOG_COLUMN_NAME_ORDER];
        catalog.createdTime = [rs dateForColumn:CATALOG_COLUMN_NAME_CREATED_TIME];
        catalog.createdBy = [rs stringForColumn:CATALOG_COLUMN_NAME_CREATED_BY];
        catalog.updatedTime = [rs dateForColumn:CATALOG_COLUMN_NAME_UPDATED_TIME];
        catalog.updatedBy = [rs stringForColumn:CATALOG_COLUMN_NAME_UPDATED_BY];
    }
    return [catalog autorelease];
}

#pragma mark -
#pragma mark order
- (NSString *)generatePrintHtml:(FDOrderEntity *)orderEntity{
    
    NSString *headImg = [@"file:" stringByAppendingString:[[NSBundle mainBundle] pathForResource:@"login-logo" ofType:@"png"]];
    NSString *htmlHeader = [NSString stringWithFormat:@"<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\
                            <title>我的订单</title>\
                            <style>\
                            table,table td,table th {\
                            border:1px solid #000;\
                            border-collapse:collapse;\
                            text-align:center;\
                            } \
                            table th {\
                            font-weight:normal\
                            }\
                            .table1 th,.table1 td {\
                            width: 85px;\
                            height:30px;\
                            }\
                            .table2 th ,.table2 td{\
                            width: 85px;\
                            height:50px;\
                            }\
                            .heigh1\
                            {\
                            height:50px;\
                            }\
                            .heigh2{height:80px;}\
                            </style>\
                            </head>\
                            <body><table class=\"table2\" width=\"700px\">\
                            <tr><td colspan=\"8\"><div style=\"float:left;width:250px;text-align:left\">\
                            <img src=\"%@\">&nbsp;&nbsp;<br/>\
                            <span style=\"font-size:12px;color:#555\">Shanghai FD Enterprise Co Ltd</span></div>\
                            <div style=\"float:right;margin-top:20px;\">\
                            <span style=\"font-size:12px;color:#555\">中美合作</span>上海艾芙迪实业有限公司</div></td></tr>\
                            <tr><th>名称</th><th>编号</th><th>图片</th><th>数量</th><th>零售价</th><th>折扣单价</th><th>折后总金额</th><th>备注</th></tr>",headImg];
    NSString *body = @"";
    
    float total = 0.0;
    
    NSArray *orderItems = orderEntity.orderItems;
    
    for (int i=0; i<[orderItems count]; i++) {
        
        FDOrderItemEntity *itemEntity = [orderItems objectAtIndex:i];
        
        FDProductEntity *productEntity = itemEntity.product;
        if (!productEntity) {
            break;
        }
        total = total + itemEntity.discountPrice*itemEntity.count;
        body = [NSString stringWithFormat:@"<tr><td>%@</td><td>%@</td><td style=\"height:122px;width:122px\"><img src=\"%@\"></td><td>%d</td><td>%.2f</td><td>%.2f</td><td>%.2f</td><td>%@</td></tr>",productEntity.name,itemEntity.flag ? [[itemEntity.product.sku substringFromIndex:[itemEntity.product.sku length] - 2] isEqualToString:@"-D"] ? productEntity.sku : [NSString stringWithFormat:@"%@-D", productEntity.sku] : productEntity.sku,[@"file:" stringByAppendingString:[PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.fullImage]],itemEntity.count,productEntity.price,itemEntity.discountPrice,itemEntity.discountPrice*itemEntity.count,ISNULLSTRING(itemEntity.note)];
        htmlHeader = [htmlHeader stringByAppendingString:body];
    }
    
    NSString *storeAddress = [NSString stringWithFormat:@"%@%@%@%@", orderEntity.province, orderEntity.city, orderEntity.zone, orderEntity.address];
    NSString *customerAddress = [NSString stringWithFormat:@"%@%@%@%@", orderEntity.detailProvince, orderEntity.detailCity, orderEntity.detailZone, orderEntity.detailAddress];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *deliverDateString = [dateFormatter stringFromDate:orderEntity.deliveringDate];
    NSString *orderingDateString = [dateFormatter stringFromDate:orderEntity.orderingDate];
    [dateFormatter release];
    NSString *html1 = [NSString stringWithFormat:@"<tr><td colspan='6'>合计</td><td>%.2f</td><td>%@</td></tr>\
     <tr><td colspan='6'>总计货款(大写):佰拾万仟佰拾元整  ￥%.2f</td><td>定金%.2f</td><td>尾款%.2f</td></tr>\
     <tr><td>专卖店</td><td>%@</td><td>电话</td><td>%@</td><td>店面地址</td><td></td><td>导购</td><td>%@</td></tr>\
     <tr><td>客户姓名</td><td>%@</td><td>移动电话</td><td>%@</td><td>住宅地址</td><td>%@</td><td>详细地址</td><td>%@</td></tr>\
     <tr><td>订货日期</td><td>%@</td><td>交货日期</td><td>%@</td><td>客户签字</td><td></td><td>导购签字</td><td></td></tr>\
     <tr><td colspan=\"8\" style=\"text-align:left\">具体要求: %@\
     </td></tr>\
     </table>\
     </body>\
     </html>",
                       orderEntity.finalTotal,                                   // 合计
                       ISNULLSTRING(orderEntity.note),          // 备注
                       orderEntity.finalTotal,                                   // 总计货款
                       orderEntity.deposit,                     // 定金
                       orderEntity.balance,                     // 尾款
                       ISNULLSTRING(orderEntity.store),         // 专卖店
                       ISNULLSTRING(orderEntity.phone),         // 电话
                       ISNULLSTRING(orderEntity.shoppingGuide), // 导购员
                       ISNULLSTRING(orderEntity.customer),      // 客户姓名
                       ISNULLSTRING(orderEntity.cellPhone),     // 移动电话
                       ISNULLSTRING(storeAddress),          // 地址
//                       ISNULLSTRING(orderEntity.homePhone),     // 住宅电话
                       ISNULLSTRING(customerAddress),       // 详细地址
                       ISNULLSTRING(orderingDateString),        // 订货日期
                       ISNULLSTRING(deliverDateString),         // 交货日期
                       ISNULLSTRING(orderEntity.requirements)]; // 具体要求
    
    htmlHeader = [htmlHeader stringByAppendingString:html1];
    
    return htmlHeader;
}

- (NSString *)generatePdfHtml:(FDOrderEntity *)orderEntity{
    
    NSString *htmlHeader = @"<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\
                            <title>我的订单</title>\
                            <style>\
                            table,table td,table th {\
                            border:1px solid #000;\
                            border-collapse:collapse;\
                            text-align:center;\
                            } \
                            table th {\
                            font-weight:normal\
                            }\
                            .table1 th,.table1 td {\
                            width: 85px;\
                            height:30px;\
                            }\
                            .table2 th ,.table2 td{\
                            width: 85px;\
                            height:50px;\
                            }\
                            .heigh1\
                            {\
                            height:50px;\
                            }\
                            .heigh2{height:80px;}\
                            </style>\
                            </head>\
                            <body><div id=\"div\"><table width=\"950px\" class=\"table1\">\
                            <tr><th>序号</th><th>名称</th><th>编号</th><th>图片</th>\
                            <th>规格</th><th>数量</th><th>零售价</th><th>折扣单价</th><th>折后总金额</th><th colspan='2'>备 注</th></tr>";
    NSString *body = @"";
    
    float total = 0.0;
    
    NSArray *orderItems = orderEntity.orderItems;
    
    for (int i=0; i<[orderItems count]; i++) {
        
        FDOrderItemEntity *itemEntity = [orderItems objectAtIndex:i];
        
        FDProductEntity *productEntity = itemEntity.product;
        if (!productEntity) {
            break;
        }
        UIImage *image = [UIImage imageWithContentsOfFile:[PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.fullImage]];
        int quotient = MAX(image.size.width / 100, image.size.height / 100);
        int width = image.size.width / quotient;
        int height = image.size.height / quotient;
        total = total + itemEntity.discountPrice*itemEntity.count;
        body = [NSString stringWithFormat:@"<tr><td>%d</td><td>%@</td><td>%@</td><td style=\"height:122px;width:122px\"><img src=\"%@\" width=\"%d\" height=\"%d\"></td><td>%@</td><td>%d</td><td>%.2f</td><td>%.2f</td><td>%.2f</td><td colspan='2'>%@</td></tr>",i+1,productEntity.name,itemEntity.flag ? [[itemEntity.product.sku substringFromIndex:[itemEntity.product.sku length] - 2] isEqualToString:@"-D"] ? productEntity.sku : [NSString stringWithFormat:@"%@-D", productEntity.sku] : productEntity.sku,[@"file:" stringByAppendingString:[PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.fullImage]],width,height,productEntity.lwh,itemEntity.count,productEntity.price,itemEntity.discountPrice,itemEntity.discountPrice*itemEntity.count,ISNULLSTRING(itemEntity.note)];
        htmlHeader = [htmlHeader stringByAppendingString:body];
    }
    
    NSString *storeAddress = [NSString stringWithFormat:@"%@%@%@%@", orderEntity.province, orderEntity.city, orderEntity.zone, orderEntity.address];
    NSString *customerAddress = [NSString stringWithFormat:@"%@%@%@%@", orderEntity.detailProvince, orderEntity.detailCity, orderEntity.detailZone, orderEntity.detailAddress];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *deliverDateString = [dateFormatter stringFromDate:orderEntity.deliveringDate];
    NSString *orderingDateString = [dateFormatter stringFromDate:orderEntity.orderingDate];
    [dateFormatter release];
    NSString *html1 = [NSString stringWithFormat:@"<tr><td colspan='8'>合计</td><td>%.2f</td>\
                       <td colspan='2'>%@</td></tr>\
                       <tr><td colspan='7'>总计货款(大写):佰   拾   万   仟   佰   拾元整  ￥%.2f</td>\
                       <td>定金</td><td>%.2f</td><td style=\"width:100px;\">尾款</td><td>%.2f</td></tr>\
                       <tr class=\"heigh1\"><td>专卖店</td><td>%@</td><td>电话</td><td>%@</td><td>导购员</td><td>%@</td><td>地址</td>\
                       <td colspan='4'>%@</td></tr>\
                       <tr class=\"heigh1\"><td>客户姓名</td><td>%@</td>\
                       <td>移动电话</td><td>%@</td><td>住宅电话</td><td>%@</td><td>详细地址</td><td colspan='4'>%@</td></tr>\
                       <tr class=\"heigh1\"><td>订货日期</td><td>%@</td><td>交货日期</td><td>%@</td><td>最后确认</td><td></td>\
                       <td colspan='5' style=\"text-align:left;font-size:12px;\">具体要求：%@</td></tr>\
                       </table></div>\
                       </body>\
                       </html>",
                       orderEntity.finalTotal,                                   // 合计
                       ISNULLSTRING(orderEntity.note),          // 备注
                       orderEntity.finalTotal,                                   // 总计货款
                       orderEntity.deposit,                     // 定金
                       orderEntity.balance,                     // 尾款
                       ISNULLSTRING(orderEntity.store),         // 专卖店
                       ISNULLSTRING(orderEntity.phone),         // 电话
                       ISNULLSTRING(orderEntity.shoppingGuide), // 导购员
                       ISNULLSTRING(storeAddress),          // 地址
                       ISNULLSTRING(orderEntity.customer),      // 客户姓名
                       ISNULLSTRING(orderEntity.cellPhone),     // 移动电话
                       ISNULLSTRING(orderEntity.homePhone),     // 住宅电话
                       ISNULLSTRING(customerAddress),       // 详细地址
                       ISNULLSTRING(orderingDateString),        // 订货日期
                       ISNULLSTRING(deliverDateString),         // 交货日期
                       ISNULLSTRING(orderEntity.requirements)]; // 具体要求
    
    htmlHeader = [htmlHeader stringByAppendingString:html1];
    
    return htmlHeader;
}

- (BOOL)addToCompare:(FDProductEntity *)product
{
    BOOL flag = NO;
    for (FDProductEntity *existProduct in arrayCompareProducts)
    {
        if(existProduct == product || existProduct.productID == product.productID){
            flag = NO;
            return flag;
        }
        
    }
    flag = YES;
    [arrayCompareProducts addObject:product];
    return flag;
}

- (BOOL)addToChart:(FDProductEntity *)product
{
    BOOL flag = NO;
    for (FDOrderItemEntity *existProduct in [self arrayData])
    {
        if(existProduct.product == product || existProduct.product.productID == product.productID){
            flag = NO;
            return flag;
        }
        
    }
    flag = YES;
    FDOrderItemEntity *orderItemEntity = [[FDOrderItemEntity alloc] initWithProductEntity:product];
    [[self arrayData] addObject:orderItemEntity];
    [orderItemEntity release];
    
    return flag;
}

#pragma mark ---
#pragma mark product data mangager
- (NSMutableArray *)getAllProduct{
    
    NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:0];
    FMDatabase *db = [FMDatabase sharedDataBase];
    NSString *sql = @"select * from fd_product where publish = 1";
    FMResultSet *rs = [db executeQuery:sql];
    
    while ([rs next]) {
        
        FDProductEntity *productEntity = [[FDProductEntity alloc] init];
        productEntity.productID = [rs intForColumn:PRODUCT_COLUMN_NAME_PRODUCT_ID];
        productEntity.sku = [rs stringForColumn:PRODUCT_COLUMN_NAME_SKU];
        productEntity.name = [rs stringForColumn:PRODUCT_COLUMN_NAME_NAME];
        productEntity.type = [rs stringForColumn:PRODUCT_COLUMN_NAME_TYPE];
        productEntity.style = [rs intForColumn:PRODUCT_COLUMN_NAME_STYLE];
        productEntity.room = [rs intForColumn:PRODUCT_COLUMN_NAME_ROOM];
        productEntity.lwh = [rs stringForColumn:PRODUCT_COLUMN_NAME_LWH];
        productEntity.shortcut = [rs stringForColumn:PRODUCT_COLUMN_NAME_SHORTCUT];
        productEntity.material = [rs stringForColumn:PRODUCT_COLUMN_NAME_MATERIAL];
        productEntity.price = [rs doubleForColumn:PRODUCT_COLUMN_NAME_PRICE];
        productEntity.currency = [rs stringForColumn:PRODUCT_COLUMN_NAME_CURRENCY];
        productEntity.thumbImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_THUMB_IMAGE];
        productEntity.fullImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_FULL_IMAGE];
        productEntity.publish = [rs intForColumn:PRODUCT_COLUMN_NAME_PUBLISH];
        productEntity.attibute = [rs stringForColumn:PRODUCT_COLUMN_NAME_ATTRIBUTE];
        productEntity.desc = [rs stringForColumn:PRODUCT_COLUMN_NAME_DESC];
        productEntity.related = [rs stringForColumn:PRODUCT_COLUMN_NAME_RELATED];
        productEntity.createdTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_CREATED_TIME];
        productEntity.createdBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_CREATED_BY];
        productEntity.updatedTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_UPDATED_TIME];
        productEntity.updatedBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_UPDATED_BY];
        productEntity.deleted = [rs intForColumn:PRODUCT_COLUMN_NAME_DELETED];
        
        //set style name and room
        //        FDProductCatalogModel *catalogModel = [[FDProductCatalogModel alloc] init];
        //        FDProductCatalogEntity *catalogEntity = [catalogModel getCatalogEntityByRoomORStyleCode:productEntity.room];
        //        productEntity.roomName = catalogEntity.name;
        //        catalogEntity = [catalogModel getCatalogEntityByRoomORStyleCode:productEntity.style];
        //        productEntity.styleCode = catalogEntity.code;
        //        productEntity.styleName = catalogEntity.name;
        //        [catalogModel release];
        //end
        
        [tempArray addObject:productEntity];
        [productEntity release];
    }
    return tempArray;
}


- (NSMutableArray *)getAllProductByType:(NSString *)productType{
    
    NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:0];
    FMDatabase *db = [FMDatabase sharedDataBase];
    NSString *sql = [NSString stringWithFormat:@"select * from fd_product where type = '%@' and publish = 1",productType];
    FMResultSet *rs = [db executeQuery:sql];
    
    while ([rs next]) {
        
        FDProductEntity *productEntity = [[FDProductEntity alloc] init];
        productEntity.productID = [rs intForColumn:PRODUCT_COLUMN_NAME_PRODUCT_ID];
        productEntity.sku = [rs stringForColumn:PRODUCT_COLUMN_NAME_SKU];
        productEntity.name = [rs stringForColumn:PRODUCT_COLUMN_NAME_NAME];
        productEntity.type = [rs stringForColumn:PRODUCT_COLUMN_NAME_TYPE];
        productEntity.style = [rs intForColumn:PRODUCT_COLUMN_NAME_STYLE];
        productEntity.room = [rs intForColumn:PRODUCT_COLUMN_NAME_ROOM];
        productEntity.lwh = [rs stringForColumn:PRODUCT_COLUMN_NAME_LWH];
        productEntity.shortcut = [rs stringForColumn:PRODUCT_COLUMN_NAME_SHORTCUT];
        productEntity.material = [rs stringForColumn:PRODUCT_COLUMN_NAME_MATERIAL];
        productEntity.price = [rs doubleForColumn:PRODUCT_COLUMN_NAME_PRICE];
        productEntity.currency = [rs stringForColumn:PRODUCT_COLUMN_NAME_CURRENCY];
        productEntity.thumbImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_THUMB_IMAGE];
        productEntity.fullImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_FULL_IMAGE];
        productEntity.publish = [rs intForColumn:PRODUCT_COLUMN_NAME_PUBLISH];
        productEntity.attibute = [rs stringForColumn:PRODUCT_COLUMN_NAME_ATTRIBUTE];
        productEntity.desc = [rs stringForColumn:PRODUCT_COLUMN_NAME_DESC];
        productEntity.related = [rs stringForColumn:PRODUCT_COLUMN_NAME_RELATED];
        productEntity.createdTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_CREATED_TIME];
        productEntity.createdBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_CREATED_BY];
        productEntity.updatedTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_UPDATED_TIME];
        productEntity.updatedBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_UPDATED_BY];
        productEntity.deleted = [rs intForColumn:PRODUCT_COLUMN_NAME_DELETED];
        //set style name and room
        FDProductCatalogEntity *catalogEntity = [self getCatalogEntityByRoomORStyleCode:productEntity.room];
        productEntity.roomName = catalogEntity.name;
        catalogEntity = [self getCatalogEntityByRoomORStyleCode:productEntity.style];
        productEntity.styleCode = catalogEntity.code;
        productEntity.styleName = catalogEntity.name;
        
        //end
        
        [tempArray addObject:productEntity];
        [productEntity release];
    }
    
    //    NSLog(@"%d, %@", [tempArray count], tempArray);
    
    return tempArray;
}

- (NSMutableArray *)getAllProductByType:(NSString *)productType withRoom:(int)roomCode withStyle:(int)styleCode{
    
    NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:0];
    FMDatabase *db = [FMDatabase sharedDataBase];
    NSString *sql;
    if (roomCode==0&&styleCode==0) {
        sql = [NSString stringWithFormat:@"select * from fd_product where type = '%@' and publish = 1",productType];   
    }else if(roomCode==0&&styleCode!=0){
        
        sql =  [NSString stringWithFormat:@"select * from fd_product where type = '%@' and style = '%d' and publish = 1",productType,styleCode];
    }else if(roomCode!=0&&styleCode==0){
        sql = [NSString stringWithFormat:@"select * from fd_product where type = '%@' and room = '%d' and publish = 1",productType,roomCode];
    }else if(roomCode!=0&&styleCode!=0){
        sql = [NSString stringWithFormat:@"select * from fd_product where type = '%@' and room = '%d' and style = '%d' and publish = 1",productType,roomCode,styleCode];
    }
    //NSLog(@"sql===>%@",sql);
    FMResultSet *rs = [db executeQuery:sql];
    
    while ([rs next]) {
        
        FDProductEntity *productEntity = [[FDProductEntity alloc] init];
        productEntity.productID = [rs intForColumn:PRODUCT_COLUMN_NAME_PRODUCT_ID];
        productEntity.sku = [rs stringForColumn:PRODUCT_COLUMN_NAME_SKU];
        productEntity.name = [rs stringForColumn:PRODUCT_COLUMN_NAME_NAME];
        productEntity.type = [rs stringForColumn:PRODUCT_COLUMN_NAME_TYPE];
        productEntity.style = [rs intForColumn:PRODUCT_COLUMN_NAME_STYLE];
        productEntity.room = [rs intForColumn:PRODUCT_COLUMN_NAME_ROOM];
        productEntity.lwh = [rs stringForColumn:PRODUCT_COLUMN_NAME_LWH];
        productEntity.shortcut = [rs stringForColumn:PRODUCT_COLUMN_NAME_SHORTCUT];
        productEntity.material = [rs stringForColumn:PRODUCT_COLUMN_NAME_MATERIAL];
        productEntity.price = [rs doubleForColumn:PRODUCT_COLUMN_NAME_PRICE];
        productEntity.currency = [rs stringForColumn:PRODUCT_COLUMN_NAME_CURRENCY];
        productEntity.thumbImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_THUMB_IMAGE];
        productEntity.fullImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_FULL_IMAGE];
        productEntity.publish = [rs intForColumn:PRODUCT_COLUMN_NAME_PUBLISH];
        productEntity.attibute = [rs stringForColumn:PRODUCT_COLUMN_NAME_ATTRIBUTE];
        productEntity.desc = [rs stringForColumn:PRODUCT_COLUMN_NAME_DESC];
        productEntity.related = [rs stringForColumn:PRODUCT_COLUMN_NAME_RELATED];
        productEntity.createdTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_CREATED_TIME];
        productEntity.createdBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_CREATED_BY];
        productEntity.updatedTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_UPDATED_TIME];
        productEntity.updatedBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_UPDATED_BY];
        productEntity.deleted = [rs intForColumn:PRODUCT_COLUMN_NAME_DELETED];
        //set style name and room
        
        FDProductCatalogEntity *catalogEntity = [self getCatalogEntityByRoomORStyleCode:productEntity.room];
        productEntity.roomName = catalogEntity.name;
        catalogEntity = [self getCatalogEntityByRoomORStyleCode:productEntity.style];
        productEntity.styleCode = catalogEntity.code;
        productEntity.styleName = catalogEntity.name;
        //end
        
        [tempArray addObject:productEntity];
        [productEntity release];
    }
    
    return tempArray;
}

- (FDProductEntity *)getProductEntityBySKU:(NSString *)sku
{
    if (!sku) return nil;
    
    NSMutableArray *tempArray = [[[NSMutableArray alloc] init] autorelease];
    
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ = '%@'", PRODUCT_TABLE_NAME, PRODUCT_COLUMN_NAME_SKU, sku];
    
    FMDatabase *db = [FMDatabase sharedDataBase];
    FMResultSet *rs = [db executeQuery:sql];
    
    while ([rs next]) {
        FDProductEntity *productEntity = [[FDProductEntity alloc] init];
        productEntity.productID = [rs intForColumn:PRODUCT_COLUMN_NAME_PRODUCT_ID];
        productEntity.sku = [rs stringForColumn:PRODUCT_COLUMN_NAME_SKU];
        productEntity.name = [rs stringForColumn:PRODUCT_COLUMN_NAME_NAME];
        productEntity.type = [rs stringForColumn:PRODUCT_COLUMN_NAME_TYPE];
        productEntity.style = [rs intForColumn:PRODUCT_COLUMN_NAME_STYLE];
        productEntity.room = [rs intForColumn:PRODUCT_COLUMN_NAME_ROOM];
        productEntity.lwh = [rs stringForColumn:PRODUCT_COLUMN_NAME_LWH];
        productEntity.shortcut = [rs stringForColumn:PRODUCT_COLUMN_NAME_SHORTCUT];
        productEntity.material = [rs stringForColumn:PRODUCT_COLUMN_NAME_MATERIAL];
        productEntity.price = [rs doubleForColumn:PRODUCT_COLUMN_NAME_PRICE];
        productEntity.currency = [rs stringForColumn:PRODUCT_COLUMN_NAME_CURRENCY];
        productEntity.thumbImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_THUMB_IMAGE];
        productEntity.fullImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_FULL_IMAGE];
        productEntity.publish = [rs intForColumn:PRODUCT_COLUMN_NAME_PUBLISH];
        productEntity.attibute = [rs stringForColumn:PRODUCT_COLUMN_NAME_ATTRIBUTE];
        productEntity.desc = [rs stringForColumn:PRODUCT_COLUMN_NAME_DESC];
        productEntity.related = [rs stringForColumn:PRODUCT_COLUMN_NAME_RELATED];
        productEntity.createdTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_CREATED_TIME];
        productEntity.createdBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_CREATED_BY];
        productEntity.updatedTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_UPDATED_TIME];
        productEntity.updatedBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_UPDATED_BY];
        productEntity.deleted = [rs intForColumn:PRODUCT_COLUMN_NAME_DELETED];
        //set style name and room
        FDProductCatalogEntity *catalogEntity = [self getCatalogEntityByRoomORStyleCode:productEntity.room];
        productEntity.roomName = catalogEntity.name;
        catalogEntity = [self getCatalogEntityByRoomORStyleCode:productEntity.style];
        productEntity.styleCode = catalogEntity.code;
        productEntity.styleName = catalogEntity.name;
        
        //end
        
        [tempArray addObject:productEntity];
        [productEntity release];
    }
    
    return (FDProductEntity *)[tempArray lastObject];
}

- (NSMutableArray *)getRelatedProductEntities:(FDProductEntity *)productEntity
{
    if (!productEntity || ![productEntity related]) return nil;
    NSArray *skuArray = [[productEntity related] componentsSeparatedByString:@";"];
    NSMutableArray *tempArray = [[[NSMutableArray alloc] init] autorelease];
    for (NSString *sku in skuArray) {
        FDProductEntity *productEntity = [self getProductEntityBySKU:sku];
        if (productEntity) [tempArray addObject:productEntity];
    }
    return tempArray;
}

- (FDProductEntity *)getProductEntityByProductID:(int)productID
{
    NSMutableArray *tempArray = [[[NSMutableArray alloc] init] autorelease];
    
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ = %d", PRODUCT_TABLE_NAME, PRODUCT_COLUMN_NAME_PRODUCT_ID, productID];
    
    FMDatabase *db = [FMDatabase sharedDataBase];
    FMResultSet *rs = [db executeQuery:sql];
    
    while ([rs next]) {
        FDProductEntity *productEntity = [[FDProductEntity alloc] init];
        productEntity.productID = [rs intForColumn:PRODUCT_COLUMN_NAME_PRODUCT_ID];
        productEntity.sku = [rs stringForColumn:PRODUCT_COLUMN_NAME_SKU];
        productEntity.name = [rs stringForColumn:PRODUCT_COLUMN_NAME_NAME];
        productEntity.type = [rs stringForColumn:PRODUCT_COLUMN_NAME_TYPE];
        productEntity.style = [rs intForColumn:PRODUCT_COLUMN_NAME_STYLE];
        productEntity.room = [rs intForColumn:PRODUCT_COLUMN_NAME_ROOM];
        productEntity.lwh = [rs stringForColumn:PRODUCT_COLUMN_NAME_LWH];
        productEntity.shortcut = [rs stringForColumn:PRODUCT_COLUMN_NAME_SHORTCUT];
        productEntity.material = [rs stringForColumn:PRODUCT_COLUMN_NAME_MATERIAL];
        productEntity.price = [rs doubleForColumn:PRODUCT_COLUMN_NAME_PRICE];
        productEntity.currency = [rs stringForColumn:PRODUCT_COLUMN_NAME_CURRENCY];
        productEntity.thumbImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_THUMB_IMAGE];
        productEntity.fullImage = [rs stringForColumn:PRODUCT_COLUMN_NAME_FULL_IMAGE];
        productEntity.publish = [rs intForColumn:PRODUCT_COLUMN_NAME_PUBLISH];
        productEntity.attibute = [rs stringForColumn:PRODUCT_COLUMN_NAME_ATTRIBUTE];
        productEntity.desc = [rs stringForColumn:PRODUCT_COLUMN_NAME_DESC];
        productEntity.related = [rs stringForColumn:PRODUCT_COLUMN_NAME_RELATED];
        productEntity.createdTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_CREATED_TIME];
        productEntity.createdBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_CREATED_BY];
        productEntity.updatedTime = [rs dateForColumn:PRODUCT_COLUMN_NAME_UPDATED_TIME];
        productEntity.updatedBy = [rs stringForColumn:PRODUCT_COLUMN_NAME_UPDATED_BY];
        productEntity.deleted = [rs intForColumn:PRODUCT_COLUMN_NAME_DELETED];
        //set style name and room
        FDProductCatalogEntity *catalogEntity = [self getCatalogEntityByRoomORStyleCode:productEntity.room];
        productEntity.roomName = catalogEntity.name;
        catalogEntity = [self getCatalogEntityByRoomORStyleCode:productEntity.style];
        productEntity.styleCode = catalogEntity.code;
        productEntity.styleName = catalogEntity.name;
        
        //end
        
        [tempArray addObject:productEntity];
        [productEntity release];
    }
        
    return (FDProductEntity *)[tempArray lastObject];
}

#pragma mark - News
#pragma mark file

- (NSArray *)getFileEntities
{
    NSMutableArray *fileEntities = [[[NSMutableArray alloc] init] autorelease];
    
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE deleted = 1 ORDER BY %@ DESC", FILE_TABLE_NAME, FILE_COLUMN_NAME_CREATED_TIME];
    FMDatabase *db = [FMDatabase sharedDataBase];
    FMResultSet *resultSet = [db executeQuery:sql];
    while ([resultSet next]) {
        FDFileEntity *fileEntity = [[FDFileEntity alloc] init];
        [fileEntity setFileID:[resultSet intForColumn:FILE_COLUMN_NAME_FILE_ID]];
        [fileEntity setTitle:[resultSet stringForColumn:FILE_COLUMN_NAME_TITLE]];
        [fileEntity setName:[resultSet stringForColumn:FILE_COLUMN_NAME_NAME]];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSDate *date = [dateFormatter dateFromString:[resultSet stringForColumn:FILE_COLUMN_NAME_CREATED_TIME]];
        [fileEntity setCreatedTime:date];
        [dateFormatter release];
        [fileEntity setCreatedBy:[resultSet stringForColumn:FILE_COLUMN_NAME_CREATED_BY]];
        [fileEntity setUpdatedTime:[resultSet dateForColumn:FILE_COLUMN_NAME_UPDATED_TIME]];
        [fileEntity setUpdatedBy:[resultSet stringForColumn:FILE_COLUMN_NAME_UPDATED_BY]];
        [fileEntity setDeleted:[resultSet intForColumn:FILE_COLUMN_NAME_DELETED]];
        [fileEntity setFlag:[resultSet intForColumn:FILE_COLUMN_NAME_FLAG]];
        [fileEntities addObject:fileEntity];
        [fileEntity release];
    }
    
    return fileEntities;
}

- (BOOL)setFileRead:(FDFileEntity *)fileEntity
{
    if ([fileEntity flag]) return YES;
    NSString *sql = [NSString stringWithFormat:@"UPDATE %@ SET %@ = 1 WHERE %@ = %d", FILE_TABLE_NAME, FILE_COLUMN_NAME_FLAG, FILE_COLUMN_NAME_FILE_ID, [fileEntity fileID]];
    FMDatabase *db = [FMDatabase sharedDataBase];
    return ([db executeUpdate:sql]);
}

#pragma mark - Order

#pragma mark order item

- (NSArray *)getOrderItemEntitiesByOrderEntity:(FDOrderEntity *)orderEntity
{
    if (!orderEntity || ![orderEntity serial]) return nil;
    
    NSMutableArray *orderItemEntities = [[[NSMutableArray alloc] init] autorelease];
    
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ = '%@'", ORDER_ITEM_TABLE_NAME, ORDER_ITEM_TABLE_COLUMN_NAME_ORDER_ID, [orderEntity serial]];
    FMDatabase *db = [FMDatabase sharedDataBase];
    FMResultSet *resultSet = [db executeQuery:sql];
    while ([resultSet next]) {
        FDOrderItemEntity * orderItemEntity = [[FDOrderItemEntity alloc] init];
        [orderItemEntity setSerial:[resultSet stringForColumn:ORDER_ITEM_TABLE_COLUMN_NAME_SERIAL]];
        [orderItemEntity setOrderID:[resultSet stringForColumn:ORDER_ITEM_TABLE_COLUMN_NAME_ORDER_ID]];
        [orderItemEntity setProductID:[resultSet intForColumn:ORDER_ITEM_TABLE_COLUMN_NAME_PRODUCT_ID]];
        [orderItemEntity setCount:[resultSet intForColumn:ORDER_ITEM_TABLE_COLUMN_NAME_COUNT]];
        [orderItemEntity setDiscount:[resultSet doubleForColumn:ORDER_ITEM_TABLE_COLUMN_NAME_DISCOUNT]];
        [orderItemEntity setDiscountPrice:[resultSet doubleForColumn:ORDER_ITEM_TABLE_COLUMN_NAME_DISCOUNT_PRICE]];
        [orderItemEntity setNote:[resultSet stringForColumn:ORDER_ITEM_TABLE_COLUMN_NAME_NOTE]];
        [orderItemEntity setFlag:[resultSet intForColumn:ORDER_ITEM_TABLE_COLUMN_NAME_FLAG]];
        
        [orderItemEntity setProduct:[self getProductEntityByProductID:[orderItemEntity productID]]];
        
        [orderItemEntities addObject:orderItemEntity];
        [orderItemEntity release];
    }
    
    return orderItemEntities;
}

- (BOOL)saveOrderItemEntity:(FDOrderItemEntity *)orderItemEntity
{
    if (!orderItemEntity) return YES;
    NSString *sql = [NSString stringWithFormat:@"INSERT OR REPLACE INTO %@ (%@, %@, %@, %@, %@, %@, %@, %@) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", 
                     ORDER_ITEM_TABLE_NAME, 
                     ORDER_ITEM_TABLE_COLUMN_NAME_SERIAL, 
                     ORDER_ITEM_TABLE_COLUMN_NAME_ORDER_ID, 
                     ORDER_ITEM_TABLE_COLUMN_NAME_PRODUCT_ID, 
                     ORDER_ITEM_TABLE_COLUMN_NAME_COUNT, 
                     ORDER_ITEM_TABLE_COLUMN_NAME_DISCOUNT, 
                     ORDER_ITEM_TABLE_COLUMN_NAME_DISCOUNT_PRICE, 
                     ORDER_ITEM_TABLE_COLUMN_NAME_NOTE, 
                     ORDER_ITEM_TABLE_COLUMN_NAME_FLAG
                     ];
	NSArray *argArray = [NSArray arrayWithObjects:
                         [orderItemEntity serial] ? [orderItemEntity serial] : [DataManagerModel autoGenerateId],
                         [orderItemEntity orderID] ? [orderItemEntity orderID] : @"", 
                         [NSNumber numberWithInt:[[orderItemEntity product] productID]],
                         [NSNumber numberWithInt:[orderItemEntity count]],
                         [NSNumber numberWithFloat:[orderItemEntity discount]],
                         [NSNumber numberWithFloat:[orderItemEntity discountPrice]],
                         [orderItemEntity note] ? [orderItemEntity note] : @"", 
                         [NSNumber numberWithInt:[orderItemEntity flag]],
                         nil];
	FMDatabase *db = [FMDatabase sharedDataBase];
	BOOL result = [db executeUpdate:sql withArgumentsInArray:argArray];
    
    return result;
}

- (BOOL)removeOrderItemEntity:(FDOrderItemEntity *)orderItemEntity
{
    if (!orderItemEntity || ![orderItemEntity serial]) return YES;
    
    NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@ WHERE %@ = '%@'", ORDER_ITEM_TABLE_NAME, ORDER_ITEM_TABLE_COLUMN_NAME_SERIAL, [orderItemEntity serial]];
    FMDatabase *db = [FMDatabase sharedDataBase];
    return [db executeUpdate:sql];
}

#pragma mark order

- (NSArray *)getOrderEntitiesFilteredBySearchString:(NSString *)searchString
{
    if (!searchString) searchString = @"";
    
    NSMutableArray * orderEntities = [[[NSMutableArray alloc] init] autorelease];
    
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ LIKE '%%%@%%' OR %@ LIKE '%%%@%%' OR %@ LIKE '%%%@%%' OR %@ LIKE '%%%@%%'", ORDER_TABLE_NAME, ORDER_TABLE_COLUMN_NAME_CUSTOMER, searchString, ORDER_TABLE_COLUMN_NAME_PHONE, searchString, ORDER_TABLE_COLUMN_NAME_CELL_PHONE, searchString, ORDER_TABLE_COLUMN_NAME_HOME_PHONE, searchString];
    FMDatabase *db = [FMDatabase sharedDataBase];
    FMResultSet *resultSet = [db executeQuery:sql];
    while ([resultSet next]) {
        FDOrderEntity * orderEntity = [[FDOrderEntity alloc] init];
        [orderEntity setSerial:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_SERIAL]];
        [orderEntity setStore:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_STORE]];
        [orderEntity setCustomer:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_CUSTOMER]];
        [orderEntity setPhone:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_PHONE]];
        [orderEntity setCellPhone:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_CELL_PHONE]];
        [orderEntity setShoppingGuide:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_SHOPPING_GUIDE]];
        [orderEntity setHomePhone:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_HOME_PHONE]];
        [orderEntity setProvince:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_PROVINCE]];
        [orderEntity setCity:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_CITY]];
        [orderEntity setZone:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_ZONE]];
        [orderEntity setAddress:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_ADDRESS]];
        [orderEntity setDetailProvince:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_DETAIL_PROVINCE]];
        [orderEntity setDetailCity:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_DETAIL_CITY]];
        [orderEntity setDetailZone:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_DETAIL_ZONE]];
        [orderEntity setDetailAddress:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_DETAIL_ADDRESS]];
        [orderEntity setOrderingDate:[resultSet dateForColumn:ORDER_TABLE_COLUMN_NAME_ORDERING_DATE]];
        [orderEntity setDeliveringDate:[resultSet dateForColumn:ORDER_TABLE_COLUMN_NAME_DELIVER_DATE]];
        [orderEntity setDeposit:[resultSet doubleForColumn:ORDER_TABLE_COLUMN_NAME_DEPOSIT]];
        [orderEntity setBalance:[resultSet doubleForColumn:ORDER_TABLE_COLUMN_NAME_BALANCE]];
        [orderEntity setRequirements:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_REQUIREMENTS]];
        [orderEntity setTotal:[resultSet doubleForColumn:ORDER_TABLE_COLUMN_NAME_TOTAL]];
        [orderEntity setTotalDiscount:[resultSet doubleForColumn:ORDER_TABLE_COLUMN_NAME_TOTAL_DISCOUNT]];
        [orderEntity setFinalTotal:[resultSet doubleForColumn:ORDER_TABLE_COLUMN_NAME_FINAL_TOTAL]];
        [orderEntity setNote:[resultSet stringForColumn:ORDER_TABLE_COLUMN_NAME_NOTE]];
        [orderEntity setCreatedDate:[resultSet dateForColumn:ORDER_TABLE_COLUMN_NAME_CREATED_DATE]];
        [orderEntities addObject:orderEntity];
        [orderEntity release];
    }
    
    return orderEntities;
}

- (BOOL)saveOrderEntity:(FDOrderEntity *)orderEntity
{
    if (!orderEntity) return YES;
    NSString *sql = [NSString stringWithFormat:@"INSERT OR REPLACE INTO %@ (%@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", 
                     ORDER_TABLE_NAME, 
                     ORDER_TABLE_COLUMN_NAME_SERIAL,
                     ORDER_TABLE_COLUMN_NAME_STORE, 
                     ORDER_TABLE_COLUMN_NAME_CUSTOMER, 
                     ORDER_TABLE_COLUMN_NAME_PHONE, 
                     ORDER_TABLE_COLUMN_NAME_CELL_PHONE, 
                     ORDER_TABLE_COLUMN_NAME_SHOPPING_GUIDE, 
                     ORDER_TABLE_COLUMN_NAME_HOME_PHONE, 
                     ORDER_TABLE_COLUMN_NAME_PROVINCE, 
                     ORDER_TABLE_COLUMN_NAME_CITY, 
                     ORDER_TABLE_COLUMN_NAME_ZONE, 
                     ORDER_TABLE_COLUMN_NAME_ADDRESS,
                     ORDER_TABLE_COLUMN_NAME_DETAIL_PROVINCE, 
                     ORDER_TABLE_COLUMN_NAME_DETAIL_CITY, 
                     ORDER_TABLE_COLUMN_NAME_DETAIL_ZONE, 
                     ORDER_TABLE_COLUMN_NAME_DETAIL_ADDRESS, 
                     ORDER_TABLE_COLUMN_NAME_ORDERING_DATE, 
                     ORDER_TABLE_COLUMN_NAME_DELIVER_DATE, 
                     ORDER_TABLE_COLUMN_NAME_DEPOSIT, 
                     ORDER_TABLE_COLUMN_NAME_BALANCE, 
                     ORDER_TABLE_COLUMN_NAME_REQUIREMENTS, 
                     ORDER_TABLE_COLUMN_NAME_TOTAL, 
                     ORDER_TABLE_COLUMN_NAME_TOTAL_DISCOUNT, 
                     ORDER_TABLE_COLUMN_NAME_FINAL_TOTAL, 
                     ORDER_TABLE_COLUMN_NAME_NOTE, 
                     ORDER_TABLE_COLUMN_NAME_CREATED_DATE
                     ];
	NSArray *argArray = [NSArray arrayWithObjects:
                         [orderEntity serial] ? [orderEntity serial] : @"",
                         [orderEntity store] ? [orderEntity store] : @"", 
                         [orderEntity customer] ? [orderEntity customer] : @"", 
                         [orderEntity phone] ? [orderEntity phone] : @"", 
                         [orderEntity cellPhone] ? [orderEntity cellPhone] : @"", 
                         [orderEntity shoppingGuide] ? [orderEntity shoppingGuide] : @"", 
                         [orderEntity homePhone] ? [orderEntity homePhone] : @"", 
                         [orderEntity province] ? [orderEntity province] : @"",
                         [orderEntity city] ? [orderEntity city] : @"",
                         [orderEntity zone] ? [orderEntity zone] : @"",
                         [orderEntity address] ? [orderEntity address] : @"",
                         [orderEntity detailProvince] ? [orderEntity detailProvince] : @"",
                         [orderEntity detailCity] ? [orderEntity detailCity] : @"",
                         [orderEntity detailZone] ? [orderEntity detailZone] : @"",
                         [orderEntity detailAddress] ? [orderEntity detailAddress] : @"",
                         [orderEntity orderingDate] ? [orderEntity orderingDate] : @"", 
                         [orderEntity deliveringDate] ? [orderEntity deliveringDate] : @"", 
                         [NSNumber numberWithFloat:[orderEntity deposit]], 
                         [NSNumber numberWithFloat:[orderEntity balance]], 
                         [orderEntity requirements] ? [orderEntity requirements] : @"", 
                         [NSNumber numberWithFloat:[orderEntity total]],
                         [NSNumber numberWithFloat:[orderEntity totalDiscount]],
                         [NSNumber numberWithFloat:[orderEntity finalTotal]],
                         [orderEntity note] ? [orderEntity note] : @"",
                         [orderEntity createdDate] ? [orderEntity createdDate] : @"",
                         nil];
	FMDatabase *db = [FMDatabase sharedDataBase];
	BOOL result = [db executeUpdate:sql withArgumentsInArray:argArray];
    if (result && [[orderEntity orderItems] count] > 0)
        for (FDOrderItemEntity *orderItemEntity in [orderEntity orderItems]) {
            result = [self saveOrderItemEntity:orderItemEntity];
            if (!result) return NO;
        }
	
	return result;
}

- (BOOL)removeOrderEntity:(FDOrderEntity *)orderEntity
{
    if (!orderEntity || ![orderEntity serial]) return YES;
    
    NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@ WHERE %@ = '%@'", ORDER_TABLE_NAME, ORDER_TABLE_COLUMN_NAME_SERIAL, [orderEntity serial]];
    FMDatabase *db = [FMDatabase sharedDataBase];
    if ([db executeUpdate:sql]) {
        NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@ WHERE %@ = '%@'", ORDER_ITEM_TABLE_NAME, ORDER_ITEM_TABLE_COLUMN_NAME_ORDER_ID, [orderEntity serial]];
        FMDatabase *db = [FMDatabase sharedDataBase];
        return [db executeUpdate:sql];
    }
    else return NO;
}

#pragma mark province, city, zone

- (NSArray *)getProvinceEntities
{
    NSMutableArray *provinceEntities = [[[NSMutableArray alloc] init] autorelease];
    
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@", PROVINCE_TABLE_NAME];
    FMDatabase *db = [FMDatabase sharedDataBase];
    FMResultSet *resultSet = [db executeQuery:sql];
    while ([resultSet next]) {
        ProvinceEntity *provinceEntity = [[ProvinceEntity alloc] init];
        [provinceEntity setName:[resultSet stringForColumn:PROVINCE_TABLE_COLUMN_NAME_NAME]];
        [provinceEntity setSort:[resultSet stringForColumn:PROVINCE_TABLE_COLUMN_NAME_SORT]];
        [provinceEntity setRemark:[resultSet stringForColumn:PROVINCE_TABLE_COLUMN_NAME_REMARK]];
        [provinceEntities addObject:provinceEntity];
        [provinceEntity release];
    }
    
    return provinceEntities;
}
- (NSArray *)getCityEntitiesByProvinceEntity:(ProvinceEntity *)provinceEntity
{
    if (!provinceEntity || ![provinceEntity sort]) return nil;
    
    NSMutableArray *cityEntities = [[[NSMutableArray alloc] init] autorelease];
    
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ = %@", CITY_TABLE_NAME, CITY_TABLE_COLUMN_NAME_PROVINCE_ID, [provinceEntity sort]];
    FMDatabase *db = [FMDatabase sharedDataBase];
    FMResultSet *resultSet = [db executeQuery:sql];
    while ([resultSet next]) {
        CityEntity *cityEntity = [[CityEntity alloc] init];
        [cityEntity setName:[resultSet stringForColumn:CITY_TABLE_COLUMN_NAME_NAME]];
        [cityEntity setProvinceID:[resultSet stringForColumn:CITY_TABLE_COLUMN_NAME_PROVINCE_ID]];
        [cityEntity setSort:[resultSet stringForColumn:CITY_TABLE_COLUMN_NAME_SORT]];
        [cityEntities addObject:cityEntity];
        [cityEntity release];
    }
    
    return cityEntities;
}
- (NSArray *)getZoneEntitiesByCityEntity:(CityEntity *)cityEntity
{
    if (!cityEntity || ![cityEntity sort]) return nil;
    
    NSMutableArray *zoneEntities = [[[NSMutableArray alloc] init] autorelease];
    
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ = %@", ZONE_TABLE_NAME, ZONE_TABLE_COLUMN_NAME_CITY_ID, [cityEntity sort]];
    FMDatabase *db = [FMDatabase sharedDataBase];
    FMResultSet *resultSet = [db executeQuery:sql];
    while ([resultSet next]) {
        ZoneEntity *zoneEntity = [[ZoneEntity alloc] init];
        [zoneEntity setZoneID:[resultSet stringForColumn:ZONE_TABLE_COLUMN_NAME_ZONE_ID]];
        [zoneEntity setName:[resultSet stringForColumn:ZONE_TABLE_COLUMN_NAME_NAME]];
        [zoneEntity setCityID:[resultSet stringForColumn:ZONE_TABLE_COLUMN_NAME_CITY_ID]];
        [zoneEntities addObject:zoneEntity];
        [zoneEntity release];
    }
    
    return zoneEntities;
}

- (NSMutableArray *)getFirstProductOfRoomCategory:(int)roomCategoryID
{
    NSMutableArray *arrayProducts = [NSMutableArray array];
    
    NSMutableDictionary *dictCategory = [self getAllCatagoriesToDictionary];
    NSMutableArray *arrayStyle = [dictCategory objectForKey:STYLE];
    for (FDProductCatalogEntity *categoryStyle in arrayStyle)
    {
        NSMutableArray *arrayAll = [self getAllProductByType:SINGLE withRoom:roomCategoryID withStyle:categoryStyle.catalogID];
        
        if(arrayAll && [arrayAll count] > 0)
        {
            [arrayProducts addObject:[arrayAll objectAtIndex:0]];
        }
    }
    
    return arrayProducts;
}


@end
