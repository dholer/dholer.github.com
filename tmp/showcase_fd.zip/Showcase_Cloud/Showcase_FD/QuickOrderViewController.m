//
//  QuickOrderViewControllerViewController.m
//  Showcase_FD
//
//  Created by august on 12-3-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "QuickOrderViewController.h"
#import "AppDelegate.h"
#import "Constants.h"
#import "DataManagerModel.h"
#import "FDProductCatalogEntity.h"
#import "QuickOrderCompareViewController.h"
#import "QuickOrderDetailController.h"
#import "ModalAlert.h"
#import "UIImage+Until.h"

@implementation UIProductButton: UIButton 
#define ProTag 2300
@synthesize productEntiry;
- (void)dealloc
{
    [productEntiry release];
    
    [super dealloc];
}

@end

static NSString *titleStr ;
@implementation QuickOrderViewController
{
    BOOL usingShortcut;
}
@synthesize arrayAllProducts,curProductList;
@synthesize dictImages,backFlag;

// added by Alex @2012.4.27
- (id)init
{
    self = [super init];
    if (self) {
        //deal with refresh data after sync finished
        [[NSNotificationCenter defaultCenter] addObserverForName:NOTIFICATION_FD_FINISHED_SYNC object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note){
            [self.arrayAllProducts removeAllObjects];
            [self.dictImages removeAllObjects];
        }];
    }
    return self;
}
//

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    backFlag = NO;
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:detailView];
    [self addTopView];
    
    svContent = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 45, 1024, 658)];
    svContent.backgroundColor = [UIColor clearColor];
    [self.view addSubview:svContent];
    [svContent release];
    if(!vcLeftPart)
    {
        [self addLeftView];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    // added by Alex @ 2012-04-17
    [self hideProductDetailView];
    //

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    // added by Alex @ 2012.5.3
    if (backFlag) {
        backFlag = NO;
        return;
    }
    if (usingShortcut) return;
    //
    
    if(vcLeftPart)
    {
        //mod by august 2012-04-11
        [self leftPartViewWillAppear:vcLeftPart];
        //end
        //[self leftPartViewWillDisappear:vcLeftPart];
        [vcLeftPart reloadContent];
    }
    
    vcLeftPart.view.hidden = NO;

}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    vcLeftPart.view.hidden = YES;
    
    if (vcCompare) {
        [vcCompare btnHidenPressed];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
//    [self.curProductList release];
    [titleLabel release];
    [arrayAllProducts release];
    [dictImages release];
    [super dealloc];
}

#pragma mark ----
#pragma mark function
- (void)addTopView
{
    UIImageView *topbar = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 1024, 45)];
    [topbar setImage:[UIImage imageNamed:@"topbar.png"]];
    [self.view addSubview:topbar];
    [topbar release];
    
    titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 45)];
    titleLabel.font = [UIFont boldSystemFontOfSize:20];
    titleLabel.text = @"所有单品";
    [titleLabel setTextAlignment:UITextAlignmentCenter];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [titleLabel setCenter:topbar.center];
    [topbar addSubview:titleLabel];
   
    
    ivSearchBG = [[UIImageView alloc] initWithFrame:CGRectMake(titleLabel.center.x + 140, 8, 219, 29)];
    ivSearchBG.image = [UIImage imageNamed:@"search-input.png"];
    [self.view addSubview:ivSearchBG];
    [ivSearchBG release];
    
    ivSearchFlag = [[UIImageView alloc] initWithFrame:CGRectMake(ivSearchBG.frame.origin.x + 10, 16, 13, 14)];
    ivSearchFlag.image = [UIImage imageNamed:@"icon-search.png"];
    [self.view addSubview:ivSearchFlag];
    [ivSearchFlag release];
    
    tfInput = [[UITextField alloc] init];
    [tfInput addTarget:self action:@selector(btnSearchPressed) forControlEvents:UIControlEventEditingDidEndOnExit];
    tfInput.frame = CGRectMake(ivSearchFlag.frame.origin.x + ivSearchFlag.frame.size.width + 2, 12, 193, 23);
    tfInput.borderStyle = UITextBorderStyleNone;
    tfInput.textColor = [UIColor blackColor];
    tfInput.font = [UIFont boldSystemFontOfSize:11];
    tfInput.textAlignment = UITextAlignmentLeft;
    tfInput.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    tfInput.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    tfInput.placeholder = @"请输入查询家具名称或者产品编号";
    tfInput.returnKeyType = UIReturnKeySearch;
    tfInput.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.view addSubview:tfInput];
    [tfInput release];
    
    btnShort = [UIButton buttonWithType:UIButtonTypeCustom];
    btnShort.frame = CGRectMake(tfInput.frame.origin.x + tfInput.frame.size.width + 5, 6, 84, 33);
    [btnShort setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnShort setTitle:@"捷径" forState:UIControlStateNormal];
    [btnShort setBackgroundImage:[UIImage imageNamed:@"btn-search.png"] forState:UIControlStateNormal];
    [btnShort setBackgroundImage:[UIImage imageNamed:@"btn-search-on.png"] forState:UIControlStateHighlighted];
    [btnShort addTarget:self action:@selector(btnShortPressed) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnShort];
    
    UIButton *btnCompare = [UIButton buttonWithType:UIButtonTypeCustom];
    btnCompare.frame = CGRectMake(btnShort.frame.origin.x + btnShort.frame.size.width + 8, 6, 50, 33);
    NSLog(@"%lf", btnCompare.frame.origin.x);
    [btnCompare setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnCompare setTitle:@"对比" forState:UIControlStateNormal];
    [btnCompare setBackgroundImage:[UIImage imageNamed:@"btn-compare.png"] forState:UIControlStateNormal];
    [btnCompare setBackgroundImage:[UIImage imageNamed:@"btn-compare-on.png"] forState:UIControlStateHighlighted];
    [btnCompare addTarget:self action:@selector(btnComparePressed) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnCompare];
    
    btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    btnBack.frame = CGRectMake(20, 7, 61, 32);
    btnBack.hidden = YES;
    [btnBack setBackgroundImage:[UIImage imageNamed:@"btn-back.png"] forState:UIControlStateNormal];
    [btnBack setBackgroundImage:[UIImage imageNamed:@"btn-back-on.png"] forState:UIControlStateHighlighted];
    [btnBack setTitle:@" 返回" forState:UIControlStateNormal];
    
    [btnBack.titleLabel setFont:[UIFont systemFontOfSize:14]];
    [btnBack setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btnBack addTarget:self action:@selector(btnBackPressed) forControlEvents:UIControlEventTouchUpInside];;
    [self.view addSubview:btnBack];
}

- (void)addLeftView
{
    sharedWindow = ((AppDelegate *)[UIApplication sharedApplication].delegate).window;
    
    vcLeftPart = [[QuickOrderLeftPartViewController alloc] init];
    vcLeftPart.leftDelegate = self;
    vcLeftPart.view.backgroundColor = [UIColor clearColor];
    vcLeftPart.view.frame = CGRectMake(-260, 0, 290, 768);
    [sharedWindow.rootViewController.view addSubview:vcLeftPart.view];
    vcLeftPart.view.hidden = YES;

}

- (UIView *)getDeep0View
{
    if(!arrayDeep0Views)
        arrayDeep0Views = [[NSMutableArray alloc] init];
    
    for (UIView *vDeep0 in arrayDeep0Views)
    {
        if(vDeep0.superview == nil)
        {
            return vDeep0;
        }
    }
    
    UIView *vDeep0 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 251, 219)];
    vDeep0.backgroundColor = [UIColor clearColor];
    [arrayDeep0Views addObject:vDeep0];
    [vDeep0 release];
    
    //
    UIImageView *ivGoods = [[UIImageView alloc] initWithFrame:CGRectMake(10, 15, 198, 156)];
    [vDeep0 addSubview:ivGoods];
    [ivGoods release];
    
    UILabel *labelName = [[UILabel alloc] initWithFrame:CGRectMake(0, 180, 219, 21)];
    labelName.text = @"单品名称";
    labelName.textColor = [UIColor blackColor];
    labelName.backgroundColor = [UIColor clearColor];
    labelName.font = [UIFont boldSystemFontOfSize:16];
    labelName.textAlignment = UITextAlignmentCenter;
    [vDeep0 addSubview:labelName];
    [labelName release];
    
    UIButton *btnAction = [UIButton buttonWithType:UIButtonTypeCustom];
    btnAction.frame = CGRectMake(0, 0, 251, 219);
    [btnAction addTarget:self action:@selector(btnDeep0ProductPressed:) forControlEvents:UIControlEventTouchUpInside];
    [vDeep0 addSubview:btnAction];
    
    return vDeep0;
}

- (UIView *)getDeep1View:(NSUInteger)i
{
    if(!arrayDeep1Views)
        arrayDeep1Views = [[NSMutableArray alloc] init];
    
    for (UIView *vDeep1 in arrayDeep1Views)
    {
        if(vDeep1.superview == nil)
        {
            return vDeep1;
        }
    }
    
    UIView *vDeep1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 251, 164)];
    vDeep1.backgroundColor = [UIColor clearColor];
    [arrayDeep1Views addObject:vDeep1];
    [vDeep1 release];
    
    //
    UIImageView *ivGoods = [[UIImageView alloc] initWithFrame:CGRectMake(75, 15, 130, 100)];
    ivGoods.tag = 100;
    [vDeep1 addSubview:ivGoods];
    [ivGoods release];
    
    UIImageView *ivSeporter = [[UIImageView alloc] initWithFrame:CGRectMake(250, 7, 1, 150)];
    ivSeporter.image = [UIImage imageNamed:@"img-dividerline.png"];
    [vDeep1 addSubview:ivSeporter];
    [ivSeporter release];
    
    UILabel *labelName = [[UILabel alloc] initWithFrame:CGRectMake(20, 120, 200, 21)];
    labelName.tag = 101;
    labelName.text = @"单品名称";
    labelName.textColor = [UIColor blackColor];
    labelName.backgroundColor = [UIColor clearColor];
    labelName.font = [UIFont boldSystemFontOfSize:15];
    labelName.textAlignment = UITextAlignmentLeft;
    [vDeep1 addSubview:labelName];
    [labelName release];
    
    UILabel *labelCode = [[UILabel alloc] initWithFrame:CGRectMake(20, 138, 120, 21)];
    labelCode.tag = 102;
    labelCode.text = @"单品code";
    labelCode.textColor = [UIColor grayColor];
    labelCode.backgroundColor = [UIColor clearColor];
    labelCode.font = [UIFont boldSystemFontOfSize:14];
    labelCode.textAlignment = UITextAlignmentLeft;
    [vDeep1 addSubview:labelCode];
    [labelCode release];
    
    UILabel *labelPrice = [[UILabel alloc] initWithFrame:CGRectMake(145, 138, 90, 21)];
    labelPrice.tag = 103;
    labelPrice.text = @"单品价格";
    labelPrice.textColor = [UIColor colorWithRed:0.51 green:0.70 blue:0.39 alpha:1.0];
    labelPrice.backgroundColor = [UIColor clearColor];
    labelPrice.font = [UIFont boldSystemFontOfSize:16];
    labelPrice.textAlignment = UITextAlignmentRight;
    [vDeep1 addSubview:labelPrice];
    [labelPrice release];
    
    UIProductButton *btnAction = [UIProductButton buttonWithType:UIButtonTypeCustom];
    btnAction.frame = CGRectMake(0, 0, 251, 164);
    btnAction.tag = ProTag+i;
    [btnAction addTarget:self action:@selector(btnDeep1ProductPressed:) forControlEvents:UIControlEventTouchUpInside];
    [vDeep1 addSubview:btnAction];
    
    UIProductButton *btnAdd = [UIProductButton buttonWithType:UIButtonTypeCustom];
    btnAdd.frame = CGRectMake(180, 100, 60, 60);
    btnAdd.backgroundColor = [UIColor clearColor];
    btnAdd.contentMode = UIViewContentModeCenter;
    [btnAdd addTarget:self action:@selector(btnAddPressed:) forControlEvents:UIControlEventTouchUpInside];
    [btnAdd setImage:[UIImage imageNamed:@"icon-shopcart1-on.png"] forState:UIControlStateNormal];
    [vDeep1 addSubview:btnAdd];
    
    return vDeep1;
}

- (BOOL)existShortCut:(NSString *)shortCut in:(NSMutableArray *)arrayShort
{
    for(NSString *existShortCut in arrayShort)
    {
        if([existShortCut isEqualToString:shortCut])
            return YES;
    }
    
    return NO;
}

- (NSMutableArray *)arrayShortCut
{
    // modified by Alex @ 2012.5.3
//    NSMutableArray *arrayShortCut = [NSMutableArray array];
//    for (FDProductEntity *product in self.arrayAllProducts)
//    {
//        NSString *shortCut = product.shortcut;
//        if(![self existShortCut:shortCut in:arrayShortCut])
//            [arrayShortCut addObject:shortCut];
//    }
    NSMutableArray *arrayShortCut = [[DataManagerModel sharedDataModel] getProductShortcuts];
    //
    
    return arrayShortCut;
}

- (NSMutableArray *)getUserfulProducts:(NSMutableArray *)arrayProducts
{
    NSMutableArray *arraySearchResult = [NSMutableArray array];
    
    NSString *searchString = tfInput.text;
    for (FDProductEntity *loopProduct in arrayProducts) 
    {
        if([self existShortCut:loopProduct.shortcut in:arrayShortCuts])
        {
            if(searchString.length > 0)
            {
                if([loopProduct.name rangeOfString:searchString options:NSCaseInsensitiveSearch].location != NSNotFound)
                    [arraySearchResult addObject:loopProduct];
                else if([loopProduct.sku rangeOfString:searchString options:NSCaseInsensitiveSearch].location != NSNotFound)
                    [arraySearchResult addObject:loopProduct];
            }
            else
                [arraySearchResult addObject:loopProduct];
        }
    }
    
    return arraySearchResult;
}

- (void)showWaitingView
{
    [ModalAlert showBlockWait:@"正在读取信息,请稍等..."];
}

- (void)hideWaitingView
{
    [ModalAlert stopBlockWait];
}


- (void)rearrangeProductViews
{
    
}

- (void)reloadContent:(BOOL)animation deep:(int)deep products:(NSMutableArray *)arrayProducts
{    
    NSMutableArray *arraySearchResult = [self getUserfulProducts:arrayProducts];
        
//    if (self.curProductList) {
//        [self.curProductList release];
//        self.curProductList = nil;
//    }
    self.curProductList = arraySearchResult;
    svContent.contentSize = CGSizeMake(svContent.frame.size.width, svContent.frame.size.height);
    
    [arrayDeep0Views makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [arrayDeep1Views makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    if(deep == 0)
    {
        float leftPos = 20.0;
        float topPos = 0.0;
        int tag = 0;
        for (FDProductEntity *proEntity in arraySearchResult)
        {
            UIView *vDeep0 = [self getDeep0View];
            vDeep0.tag = ++tag;
            [svContent addSubview:vDeep0];
            
            UIImageView *ivGoods = nil;
            UILabel *labelName = nil;
            UIButton *btnAction = nil;
            for (UIView *subview in vDeep0.subviews) 
            {
                if([subview isKindOfClass:[UIImageView class]])
                    ivGoods = (UIImageView *)subview;
                else if([subview isKindOfClass:[UILabel class]])
                    labelName = (UILabel *)subview;
                else if([subview isKindOfClass:[UIButton class]])
                    btnAction = (UIButton *)subview;
            }
//            ivGoods.image = [UIImage productImageNamed:proEntity.fullImage];
            ivGoods.image = [dictImages objectForKey:[NSNumber numberWithInt:proEntity.productID]];
            NSString *styleCode = proEntity.styleCode;
            NSString *title = nil;
            if (!styleCode||[@"" isEqualToString:styleCode]) {
                title = [NSString stringWithFormat:@"%@系列",proEntity.styleName];
                         }else {
                title = [NSString stringWithFormat:@"%@系列",proEntity.styleCode];
            }
            labelName.text = title;
            btnAction.tag = proEntity.style;
            titleLabel.text = @"所有单品";
            CGSize size = CGSizeMake(vDeep0.frame.size.width, 175);
            UIImage *image = ivGoods.image;
            
            float scale = image.size.width/size.width>image.size.height/size.height?image.size.width/size.width:image.size.height/size.height;
            if (image) {
                ivGoods.frame = CGRectMake((size.width-image.size.width/scale)/2, 10+(size.height-image.size.height/scale)/2, image.size.width/scale, image.size.height/scale);
            }
            else {
                ivGoods.frame = CGRectMake(0, 0, 0, 0);
            }
            
            if(animation)
            {
                vDeep0.frame = CGRectMake(20, 0, vDeep0.frame.size.width, vDeep0.frame.size.height);
                
                [UIView animateWithDuration:0.15 animations:^{
                    vDeep0.frame = CGRectMake(leftPos, topPos, vDeep0.frame.size.width, vDeep0.frame.size.height);
                }];
            }
            else
                vDeep0.frame = CGRectMake(leftPos, topPos, vDeep0.frame.size.width, vDeep0.frame.size.height);
            
            leftPos+=vDeep0.frame.size.width;
            
            if(leftPos > svContent.frame.size.width - 10)
            {
                leftPos = 20.0;
                topPos += vDeep0.frame.size.height;
            }
        }
        
        svContent.contentSize = CGSizeMake(svContent.frame.size.width, topPos);
    }
    else if(deep == 1)
    {
        float leftPos = 21.0;
        float topPos = 0.0;
        int tag = 0;
        FDProductEntity *proEntity=nil;
        for (int i=0; i<[arraySearchResult count]; ++i)
        {
            proEntity = [arraySearchResult objectAtIndex:i];
            UIView *vDeep1 = [self getDeep1View:i];
            vDeep1.tag = ++tag;
            [svContent addSubview:vDeep1];
            
            UIImageView *ivGoods = (UIImageView *)[vDeep1 viewWithTag:100];
            UILabel *labelName = (UILabel *)[vDeep1 viewWithTag:101];
            UILabel *labelCode = (UILabel *)[vDeep1 viewWithTag:102];
            UILabel *labelPrice = (UILabel *)[vDeep1 viewWithTag:103];
            for (UIView *subview in vDeep1.subviews) 
            {
                if([subview isKindOfClass:[UIProductButton class]])
                {
                    UIProductButton *productBtn = (UIProductButton *)subview;;
                    productBtn.productEntiry = proEntity;
                }
            }
//            ivGoods.image = [UIImage productImageNamed:proEntity.fullImage];
            //mod by august 2012-04-19
//            ivGoods.image = [UIImage imageWithContentsOfFile:[PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:proEntity.fullImage]];
            ivGoods.image = [UIImage productImageName:proEntity.fullImage];
            //[dictImages objectForKey:[NSNumber numberWithInt:proEntity.productID]];
            //end
            labelName.text = proEntity.name;
            labelCode.text = proEntity.sku;
            labelPrice.text = [NSString stringWithFormat:@"￥%.2f", proEntity.price];
            //title
            NSString *styleCode = proEntity.styleCode;
            NSString *title = nil;
            if (!styleCode||[@"" isEqualToString:styleCode]) {
                title = [NSString stringWithFormat:@"%@-%@",proEntity.styleName,proEntity.roomName];
            }else {
                title = [NSString stringWithFormat:@"%@%@-%@",proEntity.styleName,proEntity.styleCode,proEntity.roomName];
            }
            titleLabel.text = title;
            //end
            CGSize size = CGSizeMake(vDeep1.frame.size.width, 100);
            UIImage *image = ivGoods.image;

            float scale = image.size.width/size.width>image.size.height/size.height?image.size.width/size.width:image.size.height/size.height;
            if (!image) {
                ivGoods.frame = CGRectMake(0, 0, 0, 0);
            }
            else {
                ivGoods.frame = CGRectMake((size.width-image.size.width/scale)/2, 10+(size.height-image.size.height/scale)/2, image.size.width/scale, image.size.height/scale);
            }
            
            if(animation)
            {
                vDeep1.frame = CGRectMake(21, 0, vDeep1.frame.size.width, vDeep1.frame.size.height);
                
                [UIView animateWithDuration:0.15 animations:^{
                    vDeep1.frame = CGRectMake(leftPos, topPos, vDeep1.frame.size.width, vDeep1.frame.size.height);
                }];
            }
            else
                vDeep1.frame = CGRectMake(leftPos, topPos, vDeep1.frame.size.width, vDeep1.frame.size.height);
            
            leftPos+=vDeep1.frame.size.width;
            
            if(leftPos > svContent.frame.size.width - 10)
            {
                leftPos = 21.0;
                topPos += vDeep1.frame.size.height;
            }
        }
        
        svContent.contentSize = CGSizeMake(svContent.frame.size.width, topPos+200);
        
        // added by Alex @ 2012.5.3
        if (usingShortcut) {
            NSString *shortcut = [arrayShortCuts lastObject];
            if ([@"" isEqualToString:shortcut]) titleLabel.text = @"其他";
            else titleLabel.text = shortcut;
        }
        // 
    }
}

- (void)loadProductImage:(NSNumber *)deep
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSMutableDictionary *dictImagesTemp = [NSMutableDictionary dictionary];
    
    for (FDProductEntity *product in self.arrayAllProducts)
    {
        //NSLog(@"---->%d",[arrayAllProducts count]);
        if (!product) {
            break;
        }
        //UIImage *imageProduct = [UIImage productImageName:product.fullImage];
        UIImage *imageProduct = [UIImage getQuickOrderProductThumbImage:product];
        if(imageProduct)
            [dictImagesTemp setObject:imageProduct forKey:[NSNumber numberWithInt:product.productID]];
    }
    
    self.dictImages = dictImagesTemp;
    
    [self reloadContent:YES deep:[deep intValue] products:self.arrayAllProducts];
    
    [self hideWaitingView];
    
    [pool drain];
}

- (void)reloadContent:(int)deep roomCategory:(int)roomCategoryID styleCategory:(int)styleCategoryID animation:(BOOL)animation
{
    theDeep = deep;
    theRoomCategoryID = roomCategoryID;
    theStyleCategoryID = styleCategoryID;
    
    self.arrayAllProducts = nil;
    //NSLog(@"%@",self.arrayAllProducts);
    [self reloadContent:NO deep:deep products:self.arrayAllProducts];
    
    if(deep == 0)
        self.arrayAllProducts = [[DataManagerModel sharedDataModel] getFirstProductOfRoomCategory:roomCategoryID];
    else
        self.arrayAllProducts = [[DataManagerModel sharedDataModel] getAllProductByType:SINGLE withRoom:roomCategoryID withStyle:styleCategoryID];
    
    if(!arrayShortCuts) {
        arrayShortCuts = [[NSMutableArray alloc] init];
    
    [arrayShortCuts removeAllObjects];
    [arrayShortCuts addObjectsFromArray:[self arrayShortCut]];
    }
    if(vcSearch)
        [vcSearch setShortCuts:[self arrayShortCut]];
    
    [ModalAlert showBlockWait:@"正在读取信息,请稍等..."];
    
    [self performSelectorInBackground:@selector(loadProductImage:) withObject:[NSNumber numberWithInt:deep]];
}


#pragma mark-------
#pragma TopButtonAction
- (void)btnSearchPressed
{
    [self reloadContent:NO deep:theDeep products:self.arrayAllProducts];
}

- (void)btnShortPressed
{
    if(!vcSearch)
    {
        vcSearch = [[QuickOrderSearchViewController alloc] initWithNibName:@"QuickOrderSearchViewController" bundle:nil];
        vcSearch.theDelegate = self;
        vcSearch.view.frame = CGRectMake(0, 0, 1024, 703);
        [self.view addSubview:vcSearch.view];
        
        [vcSearch setShortCuts:[self arrayShortCut]];
    }
    
    vcSearch.view.alpha = 0.0;
    [self.view bringSubviewToFront:vcSearch.view];
    [UIView animateWithDuration:0.3 animations:^{
        vcSearch.view.alpha = 1.0;
    }];
}

- (void)btnComparePressed
{
    if(!vcCompare)
    {
        vcCompare = [[QuickOrderCompareViewController alloc] initWithNibName:@"QuickOrderCompareViewController" bundle:nil];
        vcCompare.view.frame = CGRectMake(0, 0, 1024, 703);
        
        [self.view addSubview:vcCompare.view];
    }
    
    vcCompare.arrayData = [DataManagerModel sharedDataModel].arrayCompareProducts;
    [vcCompare reloadCompareList];
    
    vcCompare.view.alpha = 0.0;
    [self.view bringSubviewToFront:vcCompare.view];
    [UIView animateWithDuration:0.3 animations:^{
        vcCompare.view.alpha = 1.0;
    }];
}

- (void)btnAddPressed:(UIProductButton *)sender
{
    //这里加入购物车
    BOOL relust = [[DataManagerModel sharedDataModel] addToChart:sender.productEntiry];
    if (relust) {
        [ModalAlert showAlertView:@"" withMessage:@"成功添加至购物车" withCancelBtn:@"确定"];
    }else {
        [ModalAlert showAlertView:@"错误" withMessage:@"购物车已存在此产品" withCancelBtn:@"确定"];
    }
}

- (void)btnDeep0ProductPressed:(UIButton *)sender
{
    int styleCategoryID = sender.tag;
    
    [vcLeftPart selectStyle:styleCategoryID];
}

//- (void)showProductDetailView:(FDProductEntity *)productEntity
//{
//    
//    if(!vProductDetail)
//    {
//        detailView = [[UIView alloc] initWithFrame:CGRectMake(0, 44, 1024, 666)];
//        detailView.backgroundColor = [UIColor whiteColor];
//        [self.view addSubview:detailView];
//        [self addTopView];
//        vProductDetail = [[QuickOrderProductDetailView alloc] initWithFrame:CGRectMake(0, 0, 1024, 666)];
//        vProductDetail.theDelegate = self;
//        [detailView addSubview:vProductDetail];
//        [vProductDetail release];
//    }
//    detailView.hidden = NO;
//    vProductDetail.alpha = 0.0;
//    [detailView bringSubviewToFront:vProductDetail];
//    [vProductDetail initWithProduct:productEntity];
////    [vProductDetail ResetFrame];
//    [UIView animateWithDuration:0.2 animations:^{
//        
//        vProductDetail.alpha = 1.0;
//        if (titleStr) {
//            [titleStr release];
//        }
//        titleStr = [titleLabel.text retain];
//        titleLabel.text = productEntity.name;
//        btnBack.hidden = NO;
//        // added by Alex @ 2012.4.19
//        tfInput.hidden = YES;
//        btnShort.hidden = YES;
//        ivSearchBG.hidden = YES;
//        ivSearchFlag.hidden = YES;
//        //
//        vcLeftPart.view.hidden = YES;
//    }];
//}

- (void)hideProductDetailView
{    
    detailView.hidden = YES;
    [UIView animateWithDuration:0.2 animations:^{
        
        vProductDetail.alpha = 0.0;
        
        titleLabel.text = titleStr;
        // added by Alex @ 2012.5.3
        if (usingShortcut) {
            NSString *shortcut = [arrayShortCuts lastObject];
            if ([@"" isEqualToString:shortcut]) titleLabel.text = @"其他";
            else titleLabel.text = shortcut;
        }
        // 
        btnBack.hidden = YES;
        // added by Alex @ 2012.4.19
        tfInput.hidden = NO;
        btnShort.hidden = NO;
        ivSearchBG.hidden = NO;
        ivSearchFlag.hidden = NO;
        //
        vcLeftPart.view.hidden = NO;
    }];
}

- (void)btnDeep1ProductPressed:(UIProductButton *)sender
{
    //Show product detail view
    UIButton *btn = (UIButton *)sender;
    [self showProductDetailView:(btn.tag-ProTag)];
}

- (void)showProductDetailView:(NSUInteger)curIndex {
    QuickOrderDetailController *detail = [[QuickOrderDetailController alloc] initWithIndex:curIndex AllProduct:self.curProductList];
    //detail.hidesBottomBarWhenPushed = NO;
    detail.deltaY = 0;
    detail.theDelegate=self;
    [self.navigationController pushViewController:detail animated:YES];
    [detail release];
}

- (void)btnBackPressed
{
    [self hideProductDetailView];
}

#pragma mark------
#pragma QuickOrderLeftPartDelegate
- (void)leftPartViewWillDisappear:(QuickOrderLeftPartViewController *)theVCLeftPart
{
    if(vcCompare)
        [vcCompare btnHidenPressed];
    
    if(vcSearch)
        [vcSearch btnHidenPressed];
    
    [UIView animateWithDuration:0.4 animations:^{
        
        vcLeftPart.view.frame = CGRectMake(-260, 0, 290, 768);
        svContent.frame = CGRectMake(0, 45, 1024, 658);
    }];
    
    [self reloadContent:YES deep:theDeep products:self.arrayAllProducts];
}

- (void)leftPartViewWillAppear:(QuickOrderLeftPartViewController *)theVCLeftPart
{
    [UIView animateWithDuration:0.4 animations:^{
        
        vcLeftPart.view.frame = CGRectMake(0, 0, 290, 768);
        svContent.frame = CGRectMake(260, 45, 764, 658);
        
    }];
    
    [self reloadContent:YES deep:theDeep products:self.arrayAllProducts];
}

- (void)leftCategoryChanged:(int)roomCategoryID styleCategory:(int)styleCategoryID
{    
    // added by Alex @ 2012.5.3
    if (usingShortcut) {
        usingShortcut = NO;
        [tfInput setText:nil];
        [arrayShortCuts removeAllObjects];
        arrayShortCuts = nil;
        if(vcSearch) {
            [vcSearch setSelectedShortcut:nil];
            [vcSearch btnHidenPressed];
        }
    }
    // 
    if(styleCategoryID == 0)
        [self reloadContent:0 roomCategory:roomCategoryID styleCategory:styleCategoryID animation:YES];
    else
        [self reloadContent:1 roomCategory:roomCategoryID styleCategory:styleCategoryID animation:YES];
}

#pragma mark ------
#pragma mark QuickOrderProductDetailDelegate
- (void)detailView:(QuickOrderProductDetailView *)detailView productAddToChart:(FDProductEntity *)productEntity
{
  BOOL relust = [[DataManagerModel sharedDataModel] addToChart:productEntity];
    if (relust) {
        [ModalAlert showAlertView:@"" withMessage:@"成功添加至购物车" withCancelBtn:@"确定"];
    }else {
        [ModalAlert showAlertView:@"错误" withMessage:@"购物车已存在此产品" withCancelBtn:@"确定"];
    }
}

- (void)detailView:(QuickOrderProductDetailView *)detailView productAddToCompare:(FDProductEntity *)productEntity
{
    if ([[DataManagerModel sharedDataModel].arrayCompareProducts count] >= 4) {
        [ModalAlert showAlertView:@"错误" withMessage:@"对比列表同时最多只能有四个产品" withCancelBtn:@"确定"];
        return;
    }
    if ([[DataManagerModel sharedDataModel] addToCompare:productEntity])
        [ModalAlert showAlertView:@"" withMessage:@"成功加入对比列表" withCancelBtn:@"确定"];
    else 
        [ModalAlert showAlertView:@"错误" withMessage:@"对比列表已存在此产品" withCancelBtn:@"确定"];
}

#pragma mark-------
#pragma mark - QucikOrderSearchViewDelegate
- (void)shortCutAdded:(NSString *)shortCut
{
//    if(!arrayShortCuts)
//        arrayShortCuts = [[NSMutableArray alloc] init];
//    
//    [arrayShortCuts addObject:shortCut];
//    
//    [self reloadContent:NO deep:theDeep products:self.arrayAllProducts];
}

- (void)shortCutRemoved:(NSString *)shortCut
{
//    for (NSString *existShortCut in arrayShortCuts)
//    {
//        if([existShortCut isEqualToString:shortCut])
//        {
//            [arrayShortCuts removeObject:existShortCut];
//            break;
//        }
//    }
//    
//    [self reloadContent:NO deep:theDeep products:self.arrayAllProducts];
}

// added by Alex @ 2012.5.3
- (void)shortCutChanged:(NSString *)shortCut
{
    [vcLeftPart resetSelection];
    [tfInput setText:nil];
    if(arrayShortCuts) {        
        [arrayShortCuts removeAllObjects];
        arrayShortCuts = nil;
    }
    if (!shortCut) {
        [self reloadContent:0 roomCategory:0 styleCategory:0 animation:NO];
        usingShortcut = NO;
    } else {
        if (!arrayShortCuts) {
            arrayShortCuts = [[NSMutableArray alloc] init];
            [arrayShortCuts addObject:shortCut];
        }
        usingShortcut = YES;
        [self reloadContent:1 roomCategory:0 styleCategory:0 animation:NO];
    }
}
//

@end
