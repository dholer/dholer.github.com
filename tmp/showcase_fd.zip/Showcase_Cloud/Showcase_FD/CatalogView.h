//
//  CatalogView.h
//  Showcase_FD
//
//  Created by august on 12-3-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"
#define PI 3.1415
@class FDProductEntity;
@protocol CatalogViewDelegate <NSObject>
@optional
- (NSArray *)ArrayOfProductCatalogID:(NSString *)smallcatalogID;
-(void)didSelected:(id)sender;

@end

@interface CatalogView : UIView {
    BOOL isclick;
    CGPoint location;
    id<CatalogViewDelegate> delegate;
}
@property(nonatomic,retain) id<CatalogViewDelegate> delegate;
- (id)initWithFrame:(CGRect)frame productCatalogEntity:(id)catalog_object withPageType:(PAGETYPE)type delegate:(id<CatalogViewDelegate>) delegate_;
- (id)initWithFrame:(CGRect)frame productEntity:(FDProductEntity *)productEntity withType:(NSString *)type delegate:(id<CatalogViewDelegate>) delegate_;
@end