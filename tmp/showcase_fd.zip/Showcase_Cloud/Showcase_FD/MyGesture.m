//
//  MyGesture.m
//  Showcase_FD
//
//  Created by  on 12-4-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MyGesture.h"

@implementation MyGesture
@synthesize curScale,center,cFrame;
@synthesize flag;
@end
