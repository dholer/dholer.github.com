//
//  MyMoveGesture.m
//  Showcase_FD
//
//  Created by  on 12-5-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MyMoveGesture.h"

@implementation MyMoveGesture
@synthesize moveX,moveY,flag;
@synthesize cFrame;
@end
