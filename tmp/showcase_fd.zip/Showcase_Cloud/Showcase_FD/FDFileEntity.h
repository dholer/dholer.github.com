//
//  FDImage.h
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FDFileEntity : NSObject

@property (nonatomic) int fileID;
@property (nonatomic, retain) NSString *kind;
@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSDate *createdTime;
@property (nonatomic, retain) NSString *createdBy;
@property (nonatomic, retain) NSDate *updatedTime;
@property (nonatomic, retain) NSString *updatedBy;
@property (nonatomic) int deleted;
@property (nonatomic) int flag;

@end
