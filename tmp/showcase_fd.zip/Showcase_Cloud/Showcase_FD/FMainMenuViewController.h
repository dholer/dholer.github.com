//
//  FMainMenuViewController.h
//  Showcase_FD
//
//  Created by august on 12-3-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FMainMenuViewController;
@protocol FMainMenuViewControllerDelegate <NSObject>
@optional

//action
- (void)slideMenuAction:(BOOL)isShow;
- (void)didselectedMenu:(NSMutableDictionary *)dic;
//
- (void)leftPartViewWillDisappear:(FMainMenuViewController *)theVCLeftPart;
- (void)leftPartViewWillAppear:(FMainMenuViewController *)theVCLeftPart;
- (void)leftCategoryChanged:(int)roomCategoryID styleCategory:(int)styleCategoryID;
@end

@interface FMainMenuViewController : UIViewController{
    IBOutlet UITableView *groupTableView;
    IBOutlet UITableView *catagoryTableView;
    id<FMainMenuViewControllerDelegate> delegate;
    BOOL isShown;
    IBOutlet UIButton *sliderBtn;
    NSMutableDictionary *menu_Dic;
    //NSMutableDictionary *selected_Dic;
    int currentRoomCode;
    int currentSytleCode;
}
@property (nonatomic,assign) id<FMainMenuViewControllerDelegate> delegate;
@property (nonatomic,assign) BOOL isShown;
@property (nonatomic,retain) NSMutableDictionary *menu_Dic;
//@property (nonatomic,retain) NSMutableDictionary *selected_Dic;

+ (FMainMenuViewController *)shareInstance;
- (IBAction)sliderAction:(id)sender;
@end
