//
//  MainProductViewController.h
//  Showcase_FD
//
//  Created by august on 12-3-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FDProductEntity.h"
#import "CatalogView.h"
#import "QuickOrderProductDetailView.h"
#import "SingleProductView.h"
#import <QuartzCore/QuartzCore.h>
@interface ProductDetailViewController : UIViewController<CatalogViewDelegate,QuickOrderProductDetailDelegate,SingleProductViewDelegate,UIGestureRecognizerDelegate>{
   
    IBOutlet UIButton *backBtn;
    IBOutlet UIScrollView *detailImageScrollview;
    IBOutlet UILabel *titleLabel;
    IBOutlet UILabel *detailTitleLabel;
    IBOutlet UITextView *detailProductInfoView;
    IBOutlet UIView *detailView;
    IBOutlet UIButton *btn_productInfo;
    IBOutlet UIButton *btn_singleProduct;
    IBOutlet UIButton *btn_otherRoom;
    IBOutlet UIButton *btn_otherstyle;
    IBOutlet UIButton *btn_showcase;
    IBOutlet UIScrollView *product_scrollview;
    IBOutlet UIButton *prevButton;
    IBOutlet UIButton *nextButton;
    FDProductEntity *currentProduct;
    BOOL isShown;
    NSMutableArray *product_Array;//current product entity
    NSMutableArray *all_groupArray;//all combine product
    NSMutableArray *imageView_Array;//store all detail imageview
    int kNumberOfPages;
    int currentProductIndex;
    NSString *currentProductType;
    QuickOrderProductDetailView  *vProductDetail;
    UIView *pieceForReset;
    CGFloat totalScale;
    UIImageView *curSelectedImage;
    CGRect curFrame;
    NSMutableArray *pictureList;
    //UIView                              *_detailView;//存放detail界面的
    BOOL                                backFlag;
}
@property (nonatomic, retain) FDProductEntity *currentProduct;
@property (nonatomic, retain) NSMutableArray *product_Array;
@property (nonatomic, retain) NSMutableArray *all_groupArray;
@property (nonatomic, retain) NSMutableArray *imageView_Array;
@property (nonatomic) BOOL backFlag;
@property (nonatomic, retain) NSString *currentProductType;
- (id)initWithType:(NSString *)detailViewType;
- (IBAction)showProductInfo:(id)sender;
- (IBAction)showSingleProduct:(id)sender;
- (IBAction)showOtherRoom:(id)sender;
- (IBAction)showOtherStyle:(id)sender;
- (IBAction)showcase:(id)sender;
- (IBAction)showProductDetail:(id)sender;
- (IBAction)backAction:(id)sender;
- (void)refreshDataInUI;
- (void)hiddenDetailInfoView:(BOOL)isHidden;
- (IBAction)prevAction:(id)sender;
- (IBAction)nextAction:(id)sender;
- (void)addGestureRecognizersToPiece:(UIView *)piece;

@end
