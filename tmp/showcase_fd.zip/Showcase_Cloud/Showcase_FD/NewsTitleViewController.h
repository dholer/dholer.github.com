//
//  NewsTitleViewController.h
//  Showcase_FD
//
//  Created by Yue Gu on 12-3-23.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FDFileEntity;

@protocol NewsTitleViewControllerDelegate <NSObject>

@optional
- (void)sliderIsShownChanged:(BOOL)isShow;
- (void)didSelectFile:(FDFileEntity *)fileEntity;

@end

@interface NewsTitleViewController : UIViewController

@property (nonatomic, retain) NSArray *fileEntities;

@property (nonatomic,assign) id <NewsTitleViewControllerDelegate> delegate;

@end
