//
//  OrderDetailViewController.m
//  Showcase_FD
//
//  Created by Yue Gu on 4/3/12.
//  Copyright (c) 2012 Logic Solutions, Inc. All rights reserved.
//

#import "OrderDetailViewController.h"
#import "DataManagerModel.h"
#import "FDOrderEntity.h"
#import "ProvinceCityZoneViewController.h"
#import "FDOrderItemEntity.h"
#import <MessageUI/MessageUI.h>
#import "ModalAlert.h"
#import <QuartzCore/QuartzCore.h>
#import "Constants.h"
#import "FDWebservice.h"

@interface OrderDetailViewController () <UIAlertViewDelegate, ProvinceCityZoneViewControllerDelegate, UIActionSheetDelegate, UITextFieldDelegate, UITextViewDelegate,UIPrintInteractionControllerDelegate,MFMailComposeViewControllerDelegate,UIWebViewDelegate>{
    IBOutlet UIView *previewView;
    IBOutlet UIView *detailView;
    IBOutlet UIWebView *webView_;
}

@property (retain, nonatomic) IBOutlet UITextField *storeTextField;
@property (retain, nonatomic) IBOutlet UITextField *customerTextField;
@property (retain, nonatomic) IBOutlet UITextField *phoneTextField;
@property (retain, nonatomic) IBOutlet UITextField *cellPhoneTextField;
@property (retain, nonatomic) IBOutlet UITextField *shoppingGuideTextField;
@property (retain, nonatomic) IBOutlet UITextField *homePhoneTextField;
@property (retain, nonatomic) IBOutlet UITextField *provinceTextField;
@property (retain, nonatomic) IBOutlet UITextField *cityTextField;
@property (retain, nonatomic) IBOutlet UITextField *zoneTextField;
@property (retain, nonatomic) IBOutlet UITextField *addressTextField;
@property (retain, nonatomic) IBOutlet UITextField *detailProvinceTextField;
@property (retain, nonatomic) IBOutlet UITextField *detailCityTextField;
@property (retain, nonatomic) IBOutlet UITextField *detailZoneTextField;
@property (retain, nonatomic) IBOutlet UITextField *detailAddressTextField;
@property (retain, nonatomic) IBOutlet UITextField *orderingDateTextField;
@property (retain, nonatomic) IBOutlet UITextField *deliveringDateTextField;
@property (retain, nonatomic) IBOutlet UITextField *depositTextField;
@property (retain, nonatomic) IBOutlet UITextField *balanceTextField;
@property (retain, nonatomic) IBOutlet UITextView *requirementsTextView;
@property (retain, nonatomic) IBOutlet UIButton *saveButton;
@property (retain, nonatomic) IBOutlet UIButton *cancelButton;

@property (retain, nonatomic) UIPopoverController *pczPopoverController;
@property (retain, nonatomic) ProvinceEntity *selectedProvince;
@property (retain, nonatomic) CityEntity *selectedCity;
@property (retain, nonatomic) ZoneEntity *selectedZone;

@property (retain, nonatomic) UIDatePicker *datePicker;

@property (retain, nonatomic) NSMutableArray *currentOrderItems;

@end

@implementation OrderDetailViewController

@synthesize delegate = _delegate;

@synthesize order = _order;

@synthesize storeTextField;
@synthesize customerTextField;
@synthesize phoneTextField;
@synthesize cellPhoneTextField;
@synthesize shoppingGuideTextField;
@synthesize homePhoneTextField;
@synthesize provinceTextField;
@synthesize cityTextField;
@synthesize zoneTextField;
@synthesize addressTextField;
@synthesize detailProvinceTextField;
@synthesize detailCityTextField;
@synthesize detailZoneTextField;
@synthesize detailAddressTextField;
@synthesize orderingDateTextField;
@synthesize deliveringDateTextField;
@synthesize depositTextField;
@synthesize balanceTextField;
@synthesize requirementsTextView;
@synthesize saveButton;
@synthesize cancelButton;

@synthesize pczPopoverController = _pczPopoverController;
@synthesize selectedProvince = _selectedProvince;
@synthesize selectedCity = _selectedCity;
@synthesize selectedZone = _selectedZone;

@synthesize datePicker = _datePicker;

@synthesize currentOrderItems = _currentOrderItems;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark - GUI interactions
- (void)printAction:(FDOrderEntity *)currentOrder :(UIButton *)printButton{
    
    //load html content
    NSString *htmlStr = [[DataManagerModel sharedDataModel] generatePrintHtml:currentOrder];
    
    UIPrintInteractionController *controller = [UIPrintInteractionController sharedPrintController];
    controller.delegate = self;
    
    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
    printInfo.outputType = UIPrintInfoOutputGeneral;
    printInfo.jobName = @"我的订单";
    printInfo.duplex = UIPrintInfoDuplexLongEdge;
    controller.printInfo = printInfo;
    controller.showsPageRange = NO;
    
    //controller.printingItem = data;
    NSString *htmlString = htmlStr;
    UIMarkupTextPrintFormatter *htmlFormatter = [[UIMarkupTextPrintFormatter alloc] 
                                                 initWithMarkupText:htmlString];
    htmlFormatter.startPage = 0;
    htmlFormatter.contentInsets = UIEdgeInsetsMake(72.0, 72.0, 72.0, 72.0); // 1-inch margins on all sides
    htmlFormatter.maximumContentWidth = 6 * 72.0;   // printed content should be 6-inches wide within those margins
    controller.printFormatter = htmlFormatter;
    [htmlFormatter release];
    
    void (^completionHandler)(UIPrintInteractionController *, BOOL, NSError *) = ^(UIPrintInteractionController *pic, BOOL completed, NSError *error) {
        if (!completed && error)
            NSLog(@"FAILED! due to error in domain %@ with error code %u",error.domain, error.code);
    };
    
    [controller presentFromRect:printButton.frame inView:previewView animated:YES completionHandler:completionHandler];
}

- (void)refreshOrderByCurrentForm
{
    FDOrderEntity * orderEntity = [[FDOrderEntity alloc] init];
    // if it is a new order
    if (![[self order] serial]) {
        [orderEntity setSerial:[DataManagerModel autoGenerateId]];
        for (int i = 0; i < [[self currentOrderItems] count]; i++) {
            FDOrderItemEntity * temp = [[self currentOrderItems] objectAtIndex:i];
            [temp setOrderID:[orderEntity serial]];
        }
    }
    // if it is an old one
    else { 
        [orderEntity setSerial:[[self order] serial]];
    }
    [orderEntity setStore:[[self storeTextField] text]];
    [orderEntity setCustomer:[[self customerTextField] text]];
    [orderEntity setPhone:[[self phoneTextField] text]];
    [orderEntity setCellPhone:[[self cellPhoneTextField] text]];
    [orderEntity setShoppingGuide:[[self shoppingGuideTextField] text]];
    [orderEntity setHomePhone:[[self homePhoneTextField] text]];
    [orderEntity setProvince:[[self provinceTextField] text]];
    [orderEntity setCity:[[self cityTextField] text]];
    [orderEntity setZone:[[self zoneTextField] text]];
    [orderEntity setAddress:[[self addressTextField] text]];
    [orderEntity setDetailProvince:[[self detailProvinceTextField] text]];
    [orderEntity setDetailCity:[[self detailCityTextField] text]];
    [orderEntity setDetailZone:[[self detailZoneTextField] text]];
    [orderEntity setDetailAddress:[[self detailAddressTextField] text]];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *orderingDate = [dateFormatter dateFromString:[[self orderingDateTextField] text]];
    NSDate *deliveringDate = [dateFormatter dateFromString:[[self deliveringDateTextField] text]];
    [dateFormatter release];
    [orderEntity setOrderingDate:orderingDate];
    [orderEntity setDeliveringDate:deliveringDate];
    [orderEntity setDeposit:[[[self depositTextField] text] floatValue]];
    [orderEntity setBalance:[[[self balanceTextField] text] floatValue]];
    [orderEntity setRequirements:[[self requirementsTextView] text]];
    [orderEntity setTotal:[[self order] total]];
    [orderEntity setTotalDiscount:[[self order] totalDiscount]];
    [orderEntity setFinalTotal:[[self order] finalTotal]];
    [orderEntity setNote:[[self order] note]];
    [orderEntity setCreatedDate:[[self order] createdDate]];
    [orderEntity setOrderItems:[self currentOrderItems]];
    [self setOrder:orderEntity];
    [orderEntity release];
    // set items to cache
    [[FDWebservice sharedInstance] setStore:[[self order] store]];
    [[FDWebservice sharedInstance] setPhone:[[self order] phone]];
    [[FDWebservice sharedInstance] setShoppingGuide:[[self order] shoppingGuide]];
    [[FDWebservice sharedInstance] setProvince:[[self order] province]];
    [[FDWebservice sharedInstance] setCity:[[self order] city]];
    [[FDWebservice sharedInstance] setZone:[[self order] zone]];
    [[FDWebservice sharedInstance] setAddress:[[self order] address]];
    [[FDWebservice sharedInstance] setRequirements:[[self order] requirements]];
}

- (BOOL)saveCurrentOrder
{                
    return [[DataManagerModel sharedDataModel] saveOrderEntity:[self order]];
}


- (IBAction)previewButtonPressed:(id)sender 
{
    [self refreshOrderByCurrentForm];
    
    [UIView transitionFromView:detailView 
                        toView:previewView 
                      duration:0.8 
                       options:UIViewAnimationOptionTransitionCurlUp 
                    completion:^(BOOL reslust){
                        //load preview html data
                        
                        NSString *htmlStr = [[DataManagerModel sharedDataModel] generatePdfHtml:self.order];
                        [webView_ loadHTMLString:htmlStr baseURL:nil];             
                        webView_.delegate = self;
                    }];
    
}

- (IBAction)cancelPreviewAction:(id)sender{
    
    [UIView transitionFromView:previewView 
                        toView:detailView 
                      duration:0.8 
                       options:UIViewAnimationOptionTransitionCurlDown 
                    completion:^(BOOL reslust){
        
    }];
}

- (IBAction)saveOnlyAction:(id)sender
{
    if ([self saveCurrentOrder]) {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"消息" message:@"保存成功" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil] autorelease];
        [alert show];
    } else {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"消息" message:@"保存失败，请稍后再试" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil] autorelease];
        [alert show];
    }
}

- (IBAction)printAndSaveAction:(id)sender{
    [self printAction:self.order :(UIButton *)sender];
}

- (IBAction)emailAndSaveAction:(id)sender{
    [self showMailPicker:@""];
}

- (IBAction)cancelButtonPressed:(id)sender 
{
    [self dismissModalViewControllerAnimated:YES];
}

- (IBAction)closeButtonPressed:(id)sender 
{
    [self dismissModalViewControllerAnimated:YES];
}

- (void)showProvinceCityZonePopover:(UIButton *)sender withItems:(NSArray *)theItems andProvinceCityZoneTag:(int)tag
{
    ProvinceCityZoneViewController *pczViewController = [[ProvinceCityZoneViewController alloc] init];
    [pczViewController setItems:theItems];
    [pczViewController setDelegate:self];
    [pczViewController setTag:tag];
    UIPopoverController *aPopoverController = [[UIPopoverController alloc] initWithContentViewController:pczViewController];
    aPopoverController.popoverContentSize = CGSizeMake(200, 420);
    [self setPczPopoverController:aPopoverController];
    [aPopoverController release];
    [[self pczPopoverController] presentPopoverFromRect:[sender frame] inView:detailView permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    [pczViewController release];
}

- (IBAction)provinceButtonPressed:(id)sender 
{
    [self showProvinceCityZonePopover:sender withItems:[[DataManagerModel sharedDataModel] getProvinceEntities] andProvinceCityZoneTag:[sender tag]];
}
- (IBAction)cityButtonPressed:(id)sender 
{
    if (![self selectedProvince]) return;
    [self showProvinceCityZonePopover:sender withItems:[[DataManagerModel sharedDataModel]getCityEntitiesByProvinceEntity:[self selectedProvince]] andProvinceCityZoneTag:[sender tag]];
}
- (IBAction)zoneButtonPressed:(id)sender 
{
    if (![self selectedCity]) return;
    [self showProvinceCityZonePopover:sender withItems:[[DataManagerModel sharedDataModel] getZoneEntitiesByCityEntity:[self selectedCity]] andProvinceCityZoneTag:[sender tag]];
}

- (void)showDatePicker:(UIButton *)sender withActionSheetTag:(NSInteger)tag
{
    NSString *title = @"请选择日期\n\n\n\n\n\n\n\n\n\n\n\n\n";
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:title delegate:self cancelButtonTitle:nil destructiveButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [actionSheet setTag:tag];
    [actionSheet showFromRect:[sender frame] inView:detailView animated:YES];
    UIDatePicker *aDatePicker = [[UIDatePicker alloc] init];
    [aDatePicker setFrame:CGRectMake(0, 0, 270, 219)];
    [aDatePicker setDatePickerMode:UIDatePickerModeDate];
    [self setDatePicker:aDatePicker];
    [aDatePicker release];
    [actionSheet addSubview:[self datePicker]];
}
- (IBAction)orderingDateButtonPressed:(id)sender 
{
    [self showDatePicker:sender withActionSheetTag:910000001];
}
- (IBAction)deliveringDateButtonPressed:(id)sender 
{
    [self showDatePicker:sender withActionSheetTag:910000002];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self dismissModalViewControllerAnimated:YES];
    [[self delegate] orderDidSaved];
}

#pragma mark - ProvinceCityZoneViewControllerDelegate

- (void)provinceCityZoneViewController:(ProvinceCityZoneViewController *)provinceCityZoneViewController didSelectItem:(id)item
{
    if (910000003 == [provinceCityZoneViewController tag])
        if ([item isKindOfClass:[ProvinceEntity class]]) {
            [self setSelectedProvince:item];
            [[self provinceTextField] setText:[(ProvinceEntity *)item name]];
            [self setSelectedCity:nil];
            [[self cityTextField] setText:nil];
            [self setSelectedZone:nil];
            [[self zoneTextField] setText:nil];
        }
        else if ([item isKindOfClass:[CityEntity class]]) {
            [self setSelectedCity:item];
            [[self cityTextField] setText:[(CityEntity *)item name]];
            [self setSelectedZone:nil];
            [[self zoneTextField] setText:nil];
        }
        else if ([item isKindOfClass:[ZoneEntity class]]) {
            [self setSelectedZone:item];
            [[self zoneTextField] setText:[(ZoneEntity *)item name]];
        }
    if (910000004 == [provinceCityZoneViewController tag])
        if ([item isKindOfClass:[ProvinceEntity class]]) {
            [self setSelectedProvince:item];
            [[self detailProvinceTextField] setText:[(ProvinceEntity *)item name]];
            [self setSelectedCity:nil];
            [[self detailCityTextField] setText:nil];
            [self setSelectedZone:nil];
            [[self detailZoneTextField] setText:nil];
        }
        else if ([item isKindOfClass:[CityEntity class]]) {
            [self setSelectedCity:item];
            [[self detailCityTextField] setText:[(CityEntity *)item name]];
            [self setSelectedZone:nil];
            [[self detailZoneTextField] setText:nil];
        }
        else if ([item isKindOfClass:[ZoneEntity class]]) {
            [self setSelectedZone:item];
            [[self detailZoneTextField] setText:[(ZoneEntity *)item name]];
        } 
    
    [[self pczPopoverController] dismissPopoverAnimated:YES];
    [self setPczPopoverController:nil];
}

#pragma mark - UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (1 == buttonIndex) {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        NSString *dateString = [dateFormatter stringFromDate:[[self datePicker] date]];
        [dateFormatter release];
        if (910000001 == [actionSheet tag])
            [[self orderingDateTextField] setText:dateString];
        else if (910000002 == [actionSheet tag])
            [[self deliveringDateTextField] setText:dateString];
    }
    [self setDatePicker:nil];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{    
    [textField resignFirstResponder];
    return YES;        
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{        
    NSTimeInterval animationDuration = 0.30f;                
    [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];                
    [UIView setAnimationDuration:animationDuration];
    float width = self.view.frame.size.width;                
    float height = self.view.frame.size.height; 
    CGRect rect = CGRectMake(0.0f, -200,width,height);                
    self.view.frame = rect;        
    
    [UIView commitAnimations];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == [self depositTextField]) {
        float balance = [[self order] finalTotal] - [[[self depositTextField] text] floatValue];
        [[self balanceTextField] setText:(balance >= 0 ? [NSString stringWithFormat:@"%.2lf", balance] : @"")];
    }
    NSTimeInterval animationDuration = 0.30f;        
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];        
    [UIView setAnimationDuration:animationDuration];        
    CGRect rect = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height);        
    self.view.frame = rect;        
    [UIView commitAnimations];        
    [textField resignFirstResponder];
    return; 
}

#pragma mark - UITextViewDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{            
    NSTimeInterval animationDuration = 0.30f;                
    [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];                
    [UIView setAnimationDuration:animationDuration];
    float width = self.view.frame.size.width;                
    float height = self.view.frame.size.height; 
    CGRect rect = CGRectMake(0.0f, -200,width,height);                
    self.view.frame = rect;        
    
    [UIView commitAnimations];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    NSTimeInterval animationDuration = 0.30f;        
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];        
    [UIView setAnimationDuration:animationDuration];        
    CGRect rect = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height);        
    self.view.frame = rect;        
    [UIView commitAnimations];        
    [textView resignFirstResponder];
    return; 
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [[self view] setBackgroundColor:[UIColor clearColor]];
    
    [self.view insertSubview:previewView belowSubview:detailView];
    
    [self setCurrentOrderItems:[[[self order] orderItems] mutableCopy]];

    if ([[self order] serial]) {
        [[self storeTextField] setText:[[self order] store]];
        [[self customerTextField] setText:[[self order] customer]];
        [[self phoneTextField] setText:[[self order] phone]];
        [[self cellPhoneTextField] setText:[[self order] cellPhone]];
        [[self shoppingGuideTextField] setText:[[self order] shoppingGuide]];
        [[self homePhoneTextField] setText:[[self order] homePhone]];
        [[self provinceTextField] setText:[[self order] province]];
        [[self zoneTextField] setText:[[self order] zone]];
        [[self cityTextField] setText:[[self order] city]];
        [[self addressTextField] setText:[[self order] address]];
        [[self detailProvinceTextField] setText:[[self order] detailProvince]];
        [[self detailCityTextField] setText:[[self order] detailCity]];
        [[self detailZoneTextField] setText:[[self order] detailZone]];
        [[self detailAddressTextField] setText:[[self order] detailAddress]];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        [[self orderingDateTextField] setText:[dateFormatter stringFromDate:[[self order] orderingDate]]];
        [[self deliveringDateTextField] setText:[dateFormatter stringFromDate:[[self order] deliveringDate]]];
        [dateFormatter release];
        [[self depositTextField] setText:[NSString stringWithFormat:@"%.2lf", [[self order] deposit]]];
        [[self balanceTextField] setText:[NSString stringWithFormat:@"%.2lf", [[self order] finalTotal] - [[self order] deposit]]];
        [[self requirementsTextView] setText:[[self order] requirements]];
    } else {
        [[self storeTextField] setText:[[FDWebservice sharedInstance] store]];
        [[self phoneTextField] setText:[[FDWebservice sharedInstance] phone]];
        [[self shoppingGuideTextField] setText:[[FDWebservice sharedInstance] shoppingGuide]];
        [[self provinceTextField] setText:[[FDWebservice sharedInstance] province]];
        [[self zoneTextField] setText:[[FDWebservice sharedInstance] zone]];
        [[self cityTextField] setText:[[FDWebservice sharedInstance] city]];
        [[self addressTextField] setText:[[FDWebservice sharedInstance] address]];
        [[self requirementsTextView] setText:[[FDWebservice sharedInstance] requirements]];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        [[self orderingDateTextField] setText:[dateFormatter stringFromDate:[NSDate date]]];
        [[self deliveringDateTextField] setText:[dateFormatter stringFromDate:[NSDate date]]];
        [dateFormatter release];
    }
}

- (void)viewDidUnload
{
    [self setStoreTextField:nil];
    [self setCustomerTextField:nil];
    [self setPhoneTextField:nil];
    [self setCellPhoneTextField:nil];
    [self setShoppingGuideTextField:nil];
    [self setHomePhoneTextField:nil];
    [self setProvinceTextField:nil];
    [self setZoneTextField:nil];
    [self setCityTextField:nil];
    [self setAddressTextField:nil];
    [self setDetailProvinceTextField:nil];
    [self setDetailCityTextField:nil];
    [self setDetailZoneTextField:nil];
    [self setDetailAddressTextField:nil];
    [self setOrderingDateTextField:nil];
    [self setDeliveringDateTextField:nil];
    [self setDepositTextField:nil];
    [self setBalanceTextField:nil];
    [self setRequirementsTextView:nil];
    [self setSaveButton:nil];
    [self setCancelButton:nil];
    previewView = nil;
    detailView = nil;
    webView_ = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (void)dealloc 
{
    [_order release];
    
    [storeTextField release];
    [customerTextField release];
    [homePhoneTextField release];
    [cellPhoneTextField release];
    [shoppingGuideTextField release];
    [homePhoneTextField release];
    [provinceTextField release];
    [zoneTextField release];
    [cityTextField release];
    [addressTextField release];
    [detailProvinceTextField release];
    [detailCityTextField release];
    [detailZoneTextField release];
    [detailAddressTextField release];
    [orderingDateTextField release];
    [deliveringDateTextField release];
    [depositTextField release];
    [balanceTextField release];
    [requirementsTextView release];
    [saveButton release];
    [cancelButton release];
    
    [_pczPopoverController release];
    [_selectedProvince release];
    [_selectedCity release];
    [_selectedZone release];
    
    [_datePicker release];
    
    [_currentOrderItems release];
    
    [super dealloc];
}


#pragma mark -
#pragma mark Compose Mail
// Displays an email composition interface inside the application. Populates all the Mail fields. 
-(void)displayComposerSheet:(NSString *)customer_email
{
	MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
	picker.mailComposeDelegate = self;
	
    NSMutableArray *recipientsArray = [[NSMutableArray alloc] initWithCapacity:0];
    [recipientsArray addObject:customer_email];
    [picker setToRecipients:recipientsArray];
    [recipientsArray release];
	[picker setMessageBody:@"" isHTML:NO];
    NSString *pdfPath = [DOCUMENT_FOLDER_PATH stringByAppendingPathComponent:@"order.pdf"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:pdfPath]) {
        NSData *pdfData = [NSData dataWithContentsOfFile:pdfPath];
        [picker addAttachmentData:pdfData mimeType:@"application/pdf" fileName:@"order.pdf"];
    }
	[self presentModalViewController:picker animated:YES];
    [picker release];
}

// Launches the Mail application on the device.
-(void)launchMailAppOnDevice:(NSString *)customer_email
{
	NSString *recipients = [NSString stringWithFormat:@"mailto:%@?cc=,&subject=",customer_email];
	NSString *email = [NSString stringWithFormat:@"%@", recipients];
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

-(void)showMailPicker:(NSString *)email_{
	
	Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
	if (mailClass != nil)
    {
		// We must always check whether the current device is configured for sending emails
		if ([mailClass canSendMail])
        {
			[self displayComposerSheet:email_];
        }
		else
        {
			[self launchMailAppOnDevice:email_];
        }
    }
	else
    {
		[self launchMailAppOnDevice:email_];
    }
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{	
    if (result==MFMailComposeResultSent) {
        BOOL flag = [self saveCurrentOrder];
        if (flag) {
            // modified by Alex @ 2012.5.8
//            [ModalAlert showAlertView:@"" withMessage:@"订单保存并发送成功" withCancelBtn:@"确定"];   
            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"消息" message:@"订单保存并发送成功" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil] autorelease];
            [alert show];
            //
        }
    }
	[self dismissModalViewControllerAnimated:YES];
}

#pragma mark ---
#pragma mark uiprint delegate
- (void)printInteractionControllerDidFinishJob:(UIPrintInteractionController *)printInteractionController{
    BOOL reslut = [self saveCurrentOrder];
    if (reslut) {
        // modified by Alex @ 2012.5.8
//      [ModalAlert showAlertView:@"" withMessage:@"订单保存并打印成功" withCancelBtn:@"确定"]; 
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"消息" message:@"订单保存并打印成功" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil] autorelease];
        [alert show];
        //
    }
}

#pragma mark ----
#pragma webview delegate
int imageName = 0;
double webViewHeight = 0.0;

- (void)webViewDidFinishLoad:(UIWebView *)webView{

    [self performSelector:@selector(htmlfile:) withObject:nil afterDelay:0.1];
}

- (void)htmlfile:(id)sender 
{
    UIScrollView *scrollView = nil;
    for (id subview in webView_.subviews){
        if ([[subview class] isSubclassOfClass: [UIScrollView class]])  {
            UIScrollView * s = (UIScrollView*)subview;
            scrollView = s;
        }
    }
//    webViewHeight = [[webView_ stringByEvaluatingJavaScriptFromString:@"document.body.scrollHeight;"] integerValue];
    webViewHeight = [scrollView contentSize].height;
    NSLog(@"%f",webViewHeight);
    
    CGRect screenRect = webView_.frame;
    
    double currentWebViewHeight = webViewHeight;
    while (currentWebViewHeight > 0)
    {
        imageName ++;
        
        UIGraphicsBeginImageContext(screenRect.size);
        
        CGContextRef ctx = UIGraphicsGetCurrentContext();
        [[UIColor blackColor] set];
        CGContextFillRect(ctx, screenRect);
        
        [webView_.layer renderInContext:ctx];
        
        UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
        NSString *pngPath = [DOCUMENT_FOLDER_PATH stringByAppendingPathComponent:[NSString stringWithFormat:@"%d.png",imageName]];
    
        if(currentWebViewHeight < 475)
        {
            CGRect lastImageRect = CGRectMake(0, 475 - currentWebViewHeight, webView_.frame.size.width, currentWebViewHeight - 5);
            CGImageRef lastImageRef = CGImageCreateWithImageInRect([newImage CGImage], lastImageRect);                
            newImage = [UIImage imageWithCGImage:lastImageRef]; 
            CGImageRelease(lastImageRef);
        }
        
        [UIImagePNGRepresentation(newImage) writeToFile:pngPath atomically:YES];
        
//        [webView_ stringByEvaluatingJavaScriptFromString:@"window.scrollBy(0,475);"];
        [scrollView setContentOffset:CGPointMake(0, 475)];

        currentWebViewHeight -= 475;
        if(currentWebViewHeight < 475) {
            [scrollView setContentOffset:CGPointMake(0, currentWebViewHeight)];
        }
    }
    [self drawPdf];
    [scrollView setContentOffset:CGPointMake(0, 0)];
}

#pragma mark - Private Methods

- (void) drawPdf
{
    CGSize pageSize = CGSizeMake(844, webViewHeight);
    NSString *fileName = @"order.pdf";
    NSString *pdfFileName = [DOCUMENT_FOLDER_PATH stringByAppendingPathComponent:fileName];
    
    UIGraphicsBeginPDFContextToFile(pdfFileName, CGRectZero, nil);
    
    // Mark the beginning of a new page.
    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, pageSize.width, pageSize.height), nil);
    
    double currentHeight = 0.0;
    
    for (int index = 1; index <= imageName ; index++)
    {
        NSString *pngPath = [DOCUMENT_FOLDER_PATH stringByAppendingPathComponent:[NSString stringWithFormat:@"%d.png", index]];
        UIImage *pngImage = [UIImage imageWithContentsOfFile:pngPath];
        
        [pngImage drawInRect:CGRectMake(0, currentHeight, pageSize.width, pngImage.size.height)];        
        currentHeight += pngImage.size.height;
    }
    
    UIGraphicsEndPDFContext();
    imageName = 0;
}

@end
