//
//  FDProductCatalog.m
//  iPadSales
//
//  Created by Yue Gu on 12-3-13.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "FDProductCatalogEntity.h"

@implementation FDProductCatalogEntity

@synthesize productCatalogID = _productCatalogID;
@synthesize catalogID = _catalogID;
@synthesize code = _code;
@synthesize name = _name;
@synthesize type = _type;
@synthesize order = _order;
@synthesize createdTime = _createdTime;
@synthesize createdBy = _createdBy;
@synthesize updatedTime = _updatedTime;
@synthesize updatedBy = _updatedBy;

- (void) dealloc
{
    [_name release];
    [_code release];
    [_type release];
    [_createdTime release];
    [_createdBy release];
    [_updatedTime release];
    [_updatedBy release];
	
	[super dealloc];
}

@end
