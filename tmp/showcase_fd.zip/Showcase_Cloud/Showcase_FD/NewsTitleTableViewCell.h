//
//  TitleTableViewCell.h
//  Showcase_FD
//
//  Created by Yue Gu on 12-3-23.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FDFileEntity;

@interface NewsTitleTableViewCell : UITableViewCell

@property (retain, nonatomic) FDFileEntity *fileEntity;

@property (retain, nonatomic) IBOutlet UIImageView *flagImageView;
@property (retain, nonatomic) IBOutlet UILabel *titleLabel;
@property (retain, nonatomic) IBOutlet UILabel *dateLabel;

@end
