//
//  MainProductListViewController.h
//  Showcase_FD
//
//  Created by august on 12-3-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SingleProductView.h"
#import "MainProductScrollview.h"

@class MainProductListViewController;

@protocol MainProductListViewControllerDelegate <NSObject>

@required
- (CGSize)getSizeOfProdcutView;
- (NSUInteger)numberOfProdcutsInView;
- (id)productEntityForIndex:(NSUInteger)index;
- (NSUInteger)numberOfColumnsForProductListLandscape;
@optional
- (void)jrxProductListController:(MainProductListViewController *)jrxProductListController didProductSelect:(id)detailEntity_object;
- (void)jrxProductListController:(MainProductListViewController *)jrxProductListController doneProductSelect:(id)detailEntity_object;
@end


@interface MainProductListViewController : UIViewController<UIScrollViewDelegate> {
    
	CGPoint  openLocation;
	CGPoint  touchCenter;
	CGFloat  lastscale;
	NSDictionary *dictPoint;
	BOOL finished;
	BOOL multitouch;
	CGSize sizeOfProdcutCell;
	NSUInteger numberOfRows;
	NSUInteger numberOfProducts;
	NSUInteger numberOfColumns;
	id <MainProductListViewControllerDelegate> productlist_delegate;
	UIScrollView *productsScrollview;
	BOOL wideShow;
	
}
@property(nonatomic,retain) NSDictionary *dictPoint;
@property(nonatomic,retain) UIScrollView *productsScrollview;
@property(nonatomic,assign) id <MainProductListViewControllerDelegate> productlist_delegate;
@property(nonatomic) BOOL wideShow;

- (void)updateView:(NSString *)catalogID location:(CGPoint)location;
- (id)initWithFrame:(CGRect)frame;
- (void)modifySingleProductviewWidth;
@end
