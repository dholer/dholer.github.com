//
//  NewsViewController.m
//  Showcase_FD
//
//  Created by Yue Gu on 12-3-20.
//  Copyright (c) 2012年 Logic Solutions, Inc. All rights reserved.
//

#import "NewsViewController.h"
#import "NewsTitleViewController.h"
#import "DataManagerModel.h"
#import "Constants.h"

@interface NewsViewController () <NewsTitleViewControllerDelegate>

@property (retain, nonatomic) NewsTitleViewController *newsTitleViewController;
@property (retain, nonatomic) UIWebView *newsContentView;

@end

@implementation NewsViewController

@synthesize newsTitleViewController = _newsTitleViewController;
@synthesize newsContentView = _newsContentVieww;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - NewsTitleViewControllerDelegate

- (void)sliderIsShownChanged:(BOOL)isShow
{
    if (isShow) {
        [UIView animateWithDuration:0.25 delay:0.0 options:UIViewAnimationCurveEaseInOut animations:^(void) {
            [[[self newsTitleViewController] view] setFrame:CGRectMake(0, 0, 290, 768)];
        } completion:^(BOOL finished) {
            [[self newsContentView] setFrame:CGRectMake(253, 45, 771, 658)];
        }];
    } else {
        [UIView animateWithDuration:0.25 delay:0.0 options:UIViewAnimationCurveEaseInOut animations:^(void) {
            [[[self newsTitleViewController] view] setFrame:CGRectMake(-253, 0, 290, 768)];
        } completion:^(BOOL finished) {}];
        [[self newsContentView] setFrame:CGRectMake(0, 45, 1024, 658)];
    }
}

- (void)loadFile:(NSString *)fileName
{    
    NSString* pdfFileName = [FILE_SOURCE_PATH stringByAppendingPathComponent:fileName];
    NSURL *url = [NSURL fileURLWithPath:pdfFileName];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [[self newsContentView] loadRequest:request];
}

- (void)didSelectFile:(FDFileEntity *)fileEntity
{
    if (fileEntity) {
        [self loadFile:[fileEntity name]];
        [[DataManagerModel sharedDataModel] setFileRead:fileEntity];
    }
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor = [UIColor whiteColor];
    UIImageView *topbar = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 1024.0, 45.0)];
    [topbar setImage:[UIImage imageNamed:@"topbar.png"]];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200.0, 45)];
    titleLabel.text = @"新闻中心";
    [titleLabel setTextAlignment:UITextAlignmentCenter];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    titleLabel.font = [UIFont boldSystemFontOfSize:20];
    [titleLabel setCenter:topbar.center];
    [topbar addSubview:titleLabel];
    [titleLabel release];
    [self.view addSubview:topbar];
    [topbar release];        
    UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 45, 771, 658)];	
    [webView setBackgroundColor:[UIColor whiteColor]];
    [webView setScalesPageToFit:YES];
    [self setNewsContentView:webView];
    [webView release];  
    [[self view] addSubview:[self newsContentView]];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NewsTitleViewController *aNewsTitleViewController = [[NewsTitleViewController alloc] init];
    [[aNewsTitleViewController view] setBackgroundColor:[UIColor clearColor]];
    aNewsTitleViewController.view.frame = CGRectMake(0, 0, 290, 768);
    [self setNewsTitleViewController:aNewsTitleViewController];
    [[self newsTitleViewController] setDelegate:self];
    [[self newsTitleViewController] setFileEntities:[[DataManagerModel sharedDataModel] getFileEntities]];
    [aNewsTitleViewController release];
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    if (!window) window = [[UIApplication sharedApplication].windows objectAtIndex:0];
    [[[window subviews] objectAtIndex:0] addSubview:[[self newsTitleViewController] view]];
    [self sliderIsShownChanged:YES];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [self sliderIsShownChanged:NO];
    [[[self newsTitleViewController] view] removeFromSuperview];
    [super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
    [self setNewsTitleViewController:nil];
    [self setNewsContentView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (void)dealloc {
    [_newsContentVieww release];
//    [self setNewsContentVieww:nil];
    [_newsTitleViewController release];
//    [self setNewsTitleViewController:nil];
    [super dealloc];
}
@end
