//
//  OrdersViewController.h
//  Showcase_FD
//
//  Created by august on 12-3-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HistoryOrderViewController.h"
#import "OrderDetailViewController.h"

@interface OrdersViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, UITextViewDelegate, HistoryOrderViewControllerDelegate, OrderDetailViewControllerDelegate, UIAlertViewDelegate> 
{
    UIImageView *whiteBar;
    UIImageView *greenBar;
    UIImageView *blackbar;
    UIImageView *lastBar;
    
    UITextField *noteTextField;
    NSDate *orderCreatedDate; 
    
    UIView *totalDiscountView;
    
    UITableView *orderItemsTableView;
    
    CGPoint point;
        
    UILabel *totalMoney;
    UITextField *totalTextField;
    UITextField *totalDiscountTextField;
    
    NSMutableArray *currentOrderItems;
    
    float ruleHeight;
}

@property (nonatomic, retain) HistoryOrderViewController * historyOrderViewController;
@property (nonatomic, retain) NSMutableArray * currentOrderItems;
@property (nonatomic, retain) UITableView *orderItemsTableView;

@end
