//
//  MainProductViewController.m
//  Showcase_FD
//
//  Created by august on 12-3-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ProductDetailViewController.h"
#import "Constants.h"
#import "MainProductScrollview.h"
#import "ModalAlert.h"
#import "NSString+HTML.h"
#import "MyGesture.h"
#import "MyMoveGesture.h"
#import "QuickOrderDetailController.h"
#define BASETAG 10009
#define viewGap 20.0f
#define SCROLLVIEW_DETAILVIEW_TAG 15000

@implementation ProductDetailViewController
@synthesize currentProduct;
@synthesize product_Array;
@synthesize all_groupArray;
@synthesize imageView_Array;
@synthesize currentProductType,backFlag;
- (id)initWithType:(NSString *)detailViewType
{
    self = [super init];
    if (self) {
        self.currentProductType = detailViewType;
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)dealloc
{
    [vProductDetail release];
    [currentProductType release];
    [imageView_Array release];
    [all_groupArray release];
    [product_Array release];
    [currentProduct release];   
    [super dealloc];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
   
//    [self addGestureRecognizersToPiece:self.view];
    /*
     *   set detail image
     */
    self.all_groupArray = [[DataManagerModel sharedDataModel] getAllProductByType:self.currentProductType];
    kNumberOfPages = [all_groupArray count];
    
    //set current product index to 0
    for (FDProductEntity *productEntity in all_groupArray) {
        if (self.currentProduct.productID==productEntity.productID) {            
            [all_groupArray exchangeObjectAtIndex:0 withObjectAtIndex:[all_groupArray indexOfObject:productEntity]];
            self.currentProduct = productEntity;
            break;
        }
    }
    //end
    
    
    // a page is the width of the scroll view
    detailImageScrollview.pagingEnabled = YES;
    detailImageScrollview.contentSize = CGSizeMake(detailImageScrollview.frame.size.width * kNumberOfPages, 
												 detailImageScrollview.frame.size.height);
    detailImageScrollview.showsHorizontalScrollIndicator = NO;
    detailImageScrollview.showsVerticalScrollIndicator = NO;
    detailImageScrollview.scrollsToTop = NO;
    detailImageScrollview.scrollEnabled = NO;
    detailImageScrollview.backgroundColor = [UIColor clearColor];	
    
    [self initScrollview];
  
    /*
     *  add subview
     */
    detailView.frame = CGRectMake(0, 660, detailView.bounds.size.width, detailView.bounds.size.height);
    [self.view addSubview:detailView];
    detailView.alpha = 1.0;
    [self showProductInfo:nil];
    
    /*
     *  set content data
     */
    [self refreshDataInUI];
    

   
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //NSLog(@"%@", all_groupArray);
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    backBtn = nil;
    detailImageScrollview = nil;
    titleLabel = nil;
    detailTitleLabel = nil;
    detailProductInfoView = nil;
    detailView = nil;
    btn_productInfo = nil;
    btn_singleProduct = nil;
    btn_otherRoom = nil;
    btn_otherstyle = nil;
    btn_showcase = nil;
    [product_Array removeAllObjects];
    [all_groupArray removeAllObjects];
    [imageView_Array removeAllObjects];

}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

#pragma mark ---
#pragma mark function
- (void)reSetDetailViewFrame {
    detailImageScrollview.frame = CGRectMake(0, 45, 1024, 665);
}

- (void)initScrollview{
    for (UIView *v in [detailImageScrollview subviews]) {
        [v removeFromSuperview];
    }
    NSMutableArray *imageviews = [[NSMutableArray alloc] init];
    for (unsigned i = 0; i < kNumberOfPages; i++) {
		
        [imageviews addObject:[NSNull null]];
    }
    self.imageView_Array = imageviews;
    [imageviews release];
    // load the page on either side to avoid flashes when the user starts scrolling
    [self loadScrollViewWithPage:0];
    [self loadScrollViewWithPage:1];
}

//refresh UI data by current Product entity
- (void)refreshDataInUI{
    
    currentProductIndex = 0;
    
    NSString *styleCode = [self.currentProduct styleCode];
    NSString *title;
    
    if (!styleCode||[@"" isEqualToString:styleCode]) {
        title = [NSString stringWithFormat:@"%@-%@",self.currentProduct.styleName,self.currentProduct.roomName];
    }else {
        title = [NSString stringWithFormat:@"%@ %@-%@",self.currentProduct.styleName,self.currentProduct.styleCode,self.currentProduct.roomName];
    }
    titleLabel.text = title;
    //end
    
    detailTitleLabel.text = title;
}

//layout scrollview
- (void)layoutScrollview:(NSString *)type withProductType:(NSString *)prodcutType{
    //remove subview
    for (UIView *v in [product_scrollview subviews]) {
        [v removeFromSuperview];
    }
    //end
    
    if ([COMBINE isEqualToString:prodcutType]||[CASE isEqualToString:prodcutType]) {
        int count = [product_Array count];
        
        for (int i=0; i< count; i++) {
            
            FDProductEntity *productEntity = [product_Array objectAtIndex:i];
            CatalogView *productview = [[CatalogView alloc] initWithFrame:CGRectMake((188.0+viewGap)*i, 8.0, 188.0, 177.0) productEntity:productEntity withType:type delegate:self];
            //add gesture
            productview.tag = BASETAG+i;
            UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelSingleTap:)];
            [productview addGestureRecognizer:tapGesture];
            [tapGesture release];
            [product_scrollview addSubview:productview];
            [productview release];
            
        }
        float contentWidth = count*188+(count-1)*viewGap;
        [product_scrollview setContentSize:CGSizeMake(contentWidth, product_scrollview.frame.size.height)];
        return;
    }else if([SINGLE isEqualToString:prodcutType]){
        int count = [product_Array count];
        for (int i=0; i<count; i++) {
            
            FDProductEntity *productEntity = [product_Array objectAtIndex:i];
            
            SingleProductView *productview = [[SingleProductView alloc] initWithFrame:CGRectMake((188.0+viewGap)*i,5, 188.0, 184.0) withProductEntity:productEntity];
            productview.delegate = self;
            productview.tag = i+BASETAG;
            UIButton *shopCartBtn = (UIButton *)[productview viewWithTag:1000];
            [shopCartBtn addTarget:self action:@selector(didAddProduct:) forControlEvents:UIControlEventTouchUpInside];
            [product_scrollview addSubview:productview];
            [productview release];
        }
        float contentWidth = count*188+(count-1)*viewGap;
        
        if (contentWidth>product_scrollview.frame.size.width) {
            [nextButton setImage:[UIImage imageNamed:@"icon-next-visable.png"] forState:UIControlStateNormal];
            [nextButton setEnabled:YES];
        }
        [product_scrollview setContentSize:CGSizeMake(contentWidth, product_scrollview.frame.size.height)];
        
        return;
    }
}


- (void)handelSingleTap:(id)sender{
    UITapGestureRecognizer *gesture = (id)sender;
    UIView *tempView = gesture.view;
    FDProductEntity *productEntity = [self.product_Array objectAtIndex:tempView.tag-BASETAG];
    for (FDProductEntity *tempEntity in all_groupArray) {
        if (productEntity.productID==tempEntity.productID) {            
            [all_groupArray exchangeObjectAtIndex:0 withObjectAtIndex:[all_groupArray indexOfObject:tempEntity]];
            detailImageScrollview.contentOffset = CGPointMake(0, 0);
            self.currentProduct = tempEntity;
            [self initScrollview];
            /*
             *  refresh content data
             */
            [self refreshDataInUI];
            detailProductInfoView.text = self.currentProduct.desc;
            if (isShown) {
                [self showProductDetail:nil];
            }
            [self showProductInfo:nil];
            break;
        }
    }
    
}

- (IBAction)backAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}


- (IBAction)prevAction:(id)sender{
    currentProductIndex--;
    if (currentProductIndex<0) {
        [prevButton setEnabled:NO];
        return;
    }
    for (UIView *v in [product_scrollview subviews]) {
        if ([v isKindOfClass:[SingleProductView class]]) {
            
            SingleProductView *productView = [[product_scrollview subviews] objectAtIndex:currentProductIndex];
            [product_scrollview setContentOffset:CGPointMake(productView.frame.origin.x, 0) animated:YES];
            [nextButton setImage:[UIImage imageNamed:@"icon-next-visable.png"] forState:UIControlStateNormal];
            [nextButton setEnabled:YES];
            break;
        }
    }
}

- (IBAction)nextAction:(id)sender{
    
    currentProductIndex++;
    [prevButton setImage:[UIImage imageNamed:@"icon-prev-visable.png"] forState:UIControlStateNormal];
    [prevButton setEnabled:YES];
    if (currentProductIndex>[[product_scrollview subviews] count]-1) {
        [nextButton setEnabled:NO];
        return;
    }
    for (UIView *v in [product_scrollview subviews]) {
        if ([v isKindOfClass:[SingleProductView class]]) {
            
            SingleProductView *productView = [[product_scrollview subviews] objectAtIndex:currentProductIndex];
            [product_scrollview setContentOffset:CGPointMake(productView.frame.origin.x, 0) animated:YES];

            break;
        }
    }
    
}

- (void)didSelectedBtnProductInfo:(BOOL)flag{

    if (flag) {
        [btn_productInfo setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare-on.png"] forState:UIControlStateNormal];
        [btn_productInfo setTitle:@"产品介绍" forState:UIControlStateNormal];
        [btn_productInfo setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        detailProductInfoView.hidden = NO;
        product_scrollview.hidden = YES;
    }else {
        [btn_productInfo setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare.png"] forState:UIControlStateNormal];
        [btn_productInfo setTitle:@"产品介绍" forState:UIControlStateNormal];
        [btn_productInfo setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
}

- (void)didSelectedBtnSingleProduct:(BOOL)flag{
   
    if (flag) {
        [btn_singleProduct setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare-on.png"] forState:UIControlStateNormal];
        [btn_singleProduct setTitle:@"产品单品" forState:UIControlStateNormal];
        [btn_singleProduct setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        //init data
        detailProductInfoView.hidden = YES;
        product_scrollview.hidden = NO;
        [prevButton setHidden:NO];
        [nextButton setHidden:NO];
        currentProductIndex = 0;
        //get all single product
        // modified by Alex @ 2012.4.18
//        self.product_Array = [[DataManagerModel sharedDataModel] getAllProductByType:SINGLE withRoom:self.currentProduct.room withStyle:self.currentProduct.style];
        self.product_Array = [[DataManagerModel sharedDataModel] getRelatedProductEntities:self.currentProduct];
        
        [self layoutScrollview:nil withProductType:SINGLE];
        
    }else {
        
        [btn_singleProduct setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare.png"] forState:UIControlStateNormal];
        [btn_singleProduct setTitle:@"产品单品" forState:UIControlStateNormal];
        [btn_singleProduct setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        [prevButton setHidden:YES];
        [nextButton setHidden:YES];
    }
}

- (void)didSelectedBtnOtherRoom:(BOOL)flag{
    if (flag) {
        
        [btn_otherRoom setTitle:@"其他房间" forState:UIControlStateNormal];
        [btn_otherRoom setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn_otherRoom setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare-on.png"] forState:UIControlStateNormal];
        detailProductInfoView.hidden = YES;
        product_scrollview.hidden = NO;
        //
         self.product_Array = [[DataManagerModel sharedDataModel] getAllProductByType:COMBINE withRoom:0 withStyle:self.currentProduct.style];
        //remove current product
        for (FDProductEntity *tempEntity in product_Array) {
            if (currentProduct.productID == tempEntity.productID) {
                [self.product_Array removeObject:tempEntity];
                break;
            }
        }
        //end
        [self layoutScrollview:ROOM withProductType:COMBINE];
    }else {
        [btn_otherRoom setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare.png"] forState:UIControlStateNormal];
        [btn_otherRoom setTitle:@"其他房间" forState:UIControlStateNormal];
        [btn_otherRoom setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
      
}

- (void)didSelectedBtnOtherStyle:(BOOL)flag{
    if (flag) {
        [btn_otherstyle setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare-on.png"] forState:UIControlStateNormal];
        [btn_otherstyle setTitle:@"其他系列" forState:UIControlStateNormal];
        [btn_otherstyle setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        detailProductInfoView.hidden = YES;
        product_scrollview.hidden = NO;
        self.product_Array = [[DataManagerModel sharedDataModel] getAllProductByType:COMBINE withRoom:self.currentProduct.room withStyle:0];
        for (FDProductEntity *tempEntity in product_Array) {
            if (currentProduct.productID == tempEntity.productID) {
                [self.product_Array removeObject:tempEntity];
                break;
            }
        }
        [self layoutScrollview:STYLE withProductType:COMBINE];
    
    }else {
        [btn_otherstyle setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare.png"] forState:UIControlStateNormal];
        [btn_otherstyle setTitle:@"其他系列" forState:UIControlStateNormal];
        [btn_otherstyle setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
}

- (void)didSelectedBtnShowcase:(BOOL)flag{
    if (flag) {
        [btn_showcase setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare-on.png"] forState:UIControlStateNormal];
        [btn_showcase setTitle:@"案例展示" forState:UIControlStateNormal];
        [btn_showcase setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        detailProductInfoView.hidden = YES;
        product_scrollview.hidden = NO;
        //get all case
        self.product_Array = [[DataManagerModel sharedDataModel] getAllProductByType:CASE withRoom:self.currentProduct.room withStyle:self.currentProduct.style];
        
        [self layoutScrollview:CASE withProductType:CASE];
        
    }else {
        [btn_showcase setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare.png"] forState:UIControlStateNormal];
        [btn_showcase setTitle:@"案例展示" forState:UIControlStateNormal];
        [btn_showcase setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
}

- (IBAction)showProductInfo:(id)sender{
    [self didSelectedBtnProductInfo:YES];
    [self didSelectedBtnSingleProduct:NO];
    [self didSelectedBtnOtherRoom:NO];
    [self didSelectedBtnOtherStyle:NO];
    [self didSelectedBtnShowcase:NO];
}

- (IBAction)showSingleProduct:(id)sender{
    [self didSelectedBtnProductInfo:NO];
    [self didSelectedBtnSingleProduct:YES];
    [self didSelectedBtnOtherRoom:NO];
    [self didSelectedBtnOtherStyle:NO];
    [self didSelectedBtnShowcase:NO];
}

- (IBAction)showOtherRoom:(id)sender{
    [self didSelectedBtnOtherRoom:YES];
    [self didSelectedBtnProductInfo:NO];
    [self didSelectedBtnSingleProduct:NO];
    [self didSelectedBtnOtherStyle:NO];
    [self didSelectedBtnShowcase:NO];
}

- (IBAction)showOtherStyle:(id)sender{
    [self didSelectedBtnOtherStyle:YES];
    [self didSelectedBtnProductInfo:NO];
    [self didSelectedBtnSingleProduct:NO];
    [self didSelectedBtnOtherRoom:NO];
    [self didSelectedBtnShowcase:NO];
}

- (IBAction)showcase:(id)sender{
    [self didSelectedBtnProductInfo:NO];
    [self didSelectedBtnSingleProduct:NO];
    [self didSelectedBtnOtherRoom:NO];
    [self didSelectedBtnOtherStyle:NO];
    [self didSelectedBtnShowcase:YES];
}

- (IBAction)showProductDetail:(id)sender{
    if ((isShown=!isShown)) {
        [UIView animateWithDuration:0.3f animations:^(void){
            detailView.frame = CGRectMake(0, 400, detailView.bounds.size.width, detailView.bounds.size.height);
            detailProductInfoView.text = [NSString stringFromHTMLString:self.currentProduct.desc];
        }]; 
    }else {
        
        [UIView animateWithDuration:0.3f animations:^(void){
        detailView.frame = CGRectMake(0, 660, detailView.bounds.size.width, detailView.bounds.size.height);    
        }];
        
    }
}

- (void)hiddenDetailInfoView:(BOOL)isHidden{
    [detailView setHidden:isHidden];
}

- (void)didAddProduct:(id)sender{
    UIButton *shopcartBtn = (UIButton *)sender;
    SingleProductView *superView_ = (SingleProductView*)shopcartBtn.superview.superview;
    if (superView_&&[superView_ isKindOfClass:[SingleProductView class]]) {
        int tag = superView_.tag - BASETAG;
        BOOL relust = [[DataManagerModel sharedDataModel] addToChart:[self.product_Array objectAtIndex:tag]];
        if (relust) {
            [ModalAlert showAlertView:@"" withMessage:@"成功添加至购物车" withCancelBtn:@"确定"];
        }else {
            [ModalAlert showAlertView:@"错误" withMessage:@"购物车已存在此产品" withCancelBtn:@"确定"];
        }

    }

}


#pragma mark ---
#pragma mark scrollview delegate
- (void)loadScrollViewWithPage:(int)page {
	
    if (page < 0) return;
    if (page >= kNumberOfPages) return;
	
    // replace the placeholder if necessary
	UIImageView *imageView = [self.imageView_Array objectAtIndex:page];
	if ((NSNull *)imageView == [NSNull null]) {
		UIImageView *temp_imageView  = [[UIImageView alloc] initWithFrame:CGRectMake(0, 10, 1024.0, detailImageScrollview.bounds.size.height-20)];
       
        FDProductEntity *productEntity = [self.all_groupArray objectAtIndex:page];
		NSString *imagePath = [PRODUCT_IMAGE_SOURCE_PATH stringByAppendingPathComponent:productEntity.fullImage];
        UIImage *image = [[UIImage alloc] initWithContentsOfFile:imagePath];
        [temp_imageView setImage:image];
        
        
		CGRect frame = CGRectMake(detailImageScrollview.frame.origin.x, detailImageScrollview.frame.origin.y, detailImageScrollview.frame.size.width, detailImageScrollview.frame.size.height);
		frame.origin.x = frame.size.width * page;
        float scale = image.size.width/frame.size.width>image.size.height/frame.size.height?image.size.width/frame.size.width:image.size.height/frame.size.height;
        if (image) {
            temp_imageView.frame = CGRectMake(frame.origin.x+(frame.size.width-image.size.width/scale)/2, (frame.size.height-image.size.height/scale)/2, image.size.width/scale, image.size.height/scale);
            detailImageScrollview.scrollEnabled = NO;
        }
        else {
            temp_imageView.frame = CGRectMake(0, 0, 0, 0);
            detailImageScrollview.scrollEnabled = NO;
        }
		
        //////////////////////////////////////
//        UIView *view = [[UIView alloc] initWithFrame:temp_imageView.frame];
//        [detailImageScrollview addSubview:view];
//        temp_imageView.frame = CGRectMake(0, 0, temp_imageView.frame.size.width, temp_imageView.frame.size.height);
//        [view addSubview:temp_imageView];
        ///////////////////////////////////////
        [self addGestureRecognizersToPiece:temp_imageView];
        [temp_imageView setUserInteractionEnabled:YES];
        [temp_imageView setExclusiveTouch:YES];
        // added by Alex @ 2012.5.8
        [temp_imageView setTag:SCROLLVIEW_DETAILVIEW_TAG + page];
        //
        //temp_imageView.center = detailImageScrollview.center;
		[detailImageScrollview addSubview:temp_imageView];
        [self.imageView_Array replaceObjectAtIndex:page withObject:temp_imageView];
		[temp_imageView release];
        [image release];
	}
	
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
	
    
//    for (int i = 0; i < []; ++i) {
//        
//    }
//    curSelectedImage.frame = curFrame;
//    if (curSelectedImage.center) {
//        curSelectedImage.frame = curFrame;
//    }
    // Switch the indicator when more than 50% of the previous/next page is visible
    CGFloat pageWidth = detailImageScrollview.frame.size.width;
    int page = floor((detailImageScrollview.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    // load the visible page and the page on either side of it (to avoid flashes when the user starts scrolling)
    [self loadScrollViewWithPage:page - 1];
    [self loadScrollViewWithPage:page];
    [self loadScrollViewWithPage:page + 1];
	
    // added by Alex @ 2012.5.8
    for ( int i = 0; i < kNumberOfPages; i++ ) {  
        
        if ( (i < (page-1) || i > (page+1)) && [scrollView viewWithTag:(SCROLLVIEW_DETAILVIEW_TAG + i)] ) {  
            [[scrollView viewWithTag:(SCROLLVIEW_DETAILVIEW_TAG +i)] removeFromSuperview];
            [self.imageView_Array replaceObjectAtIndex:i withObject:[NSNull null]];
        }  
    } 
    //
}

// At the end of scroll animation, reset the boolean used when scrolls originate from the UIPageControl
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    

    [self reSetDetailViewFrame];
    CGFloat pageWidth = detailImageScrollview.frame.size.width;
    int current_page = floor((detailImageScrollview.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
	//[currentProduct release];
    //if (currentProduct) currentProduct = nil;
    FDProductEntity *fd = [self.all_groupArray objectAtIndex:current_page];
    if (fd.productID != self.currentProduct.productID) {
        curSelectedImage.frame = curFrame;
    }
    [currentProduct release];
    if (currentProduct) currentProduct = nil;
    self.currentProduct = fd;
    /*
     *  refresh content data
     */
    [self refreshDataInUI];
    if (isShown) {
        [self showProductDetail:nil];
    }
    [self showProductInfo:nil];
}

//remove productdetail view
- (void)removeProductDetailView{
    
    [UIView animateWithDuration:0.2 animations:^{
        
        vProductDetail.alpha = 0.0;
        
        [backBtn removeTarget:self action:@selector(removeProductDetailView:) forControlEvents:UIControlEventTouchUpInside];
        [backBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    }];
}

#pragma mark ----
#pragma mark catalog view delegate
-(void)didSelected:(id)sender{
    //NSLog(@"%@",sender);
}

#pragma mark ----
#pragma mark catalog view delegate
- (void)didSelectedSingleProduct:(FDProductEntity *)selectedProduct{
    NSMutableArray *array = [[[NSMutableArray alloc] initWithObjects:selectedProduct, nil] autorelease];
    QuickOrderDetailController *detail = [[QuickOrderDetailController alloc] initWithIndex:0 AllProduct:array];
    detail.deltaY = 58.0;
    detail.theDelegate=self;
    [self.navigationController pushViewController:detail animated:YES];
    [detail release]; 
    
//    vProductDetail = [[QuickOrderProductDetailView alloc] initWithFrame:CGRectMake(0, 42, 1024, 658)];
//    vProductDetail.theDelegate = self;
//    [self.view addSubview:vProductDetail];
//    vProductDetail.alpha = 0.0;
//    [self.view bringSubviewToFront:vProductDetail];
//    [vProductDetail initWithProduct:selectedProduct];
//    
//    [backBtn removeTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
//    [backBtn addTarget:self action:@selector(removeProductDetailView) forControlEvents:UIControlEventTouchUpInside];
//    [UIView animateWithDuration:0.2 animations:^{
//        
//        vProductDetail.alpha = 1.0;
//    }];

}


#pragma mark ------
#pragma mark QuickOrderProductDetailDelegate
- (void)detailView:(QuickOrderProductDetailView *)detailView productAddToChart:(FDProductEntity *)productEntity
{
    BOOL relust = [[DataManagerModel sharedDataModel] addToChart:productEntity];
    if (relust) {
        [ModalAlert showAlertView:@"" withMessage:@"成功添加至购物车" withCancelBtn:@"确定"];
    }else {
        [ModalAlert showAlertView:@"错误" withMessage:@"购物车已存在此产品" withCancelBtn:@"确定"];
    }
}

- (void)detailView:(QuickOrderProductDetailView *)detailView productAddToCompare:(FDProductEntity *)productEntity
{
    if ([[DataManagerModel sharedDataModel].arrayCompareProducts count] >= 4) {
        [ModalAlert showAlertView:@"错误" withMessage:@"对比列表同时最多只能有四个产品" withCancelBtn:@"确定"];
        return;
    }
    if ([[DataManagerModel sharedDataModel] addToCompare:productEntity])
        [ModalAlert showAlertView:@"" withMessage:@"成功加入对比列表" withCancelBtn:@"确定"];
    else 
        [ModalAlert showAlertView:@"错误" withMessage:@"对比列表已存在此产品" withCancelBtn:@"确定"];
}


//////////////////////////////////////////////////////////////////
#pragma mark gesture
- (void)addGestureRecognizersToPiece:(UIView *)piece
{
	
//	//旋转
//    UIRotationGestureRecognizer *rotationGesture = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotatePiece:)];
//    [piece addGestureRecognizer:rotationGesture];
//    [rotationGesture release];
    
	
	//放缩
    MyGesture *pinchGesture = [[MyGesture alloc] initWithTarget:self action:@selector(scalePiece:)];
    pinchGesture.curScale = 1.0;
    pinchGesture.flag = NO;
    pinchGesture.center = piece.center;
    pinchGesture.cFrame = piece.frame;
    [pinchGesture setDelegate:self];
    [piece addGestureRecognizer:pinchGesture];
    [pinchGesture release];
    
	
	//平移
    MyMoveGesture *panGesture = [[MyMoveGesture alloc] initWithTarget:self action:@selector(panPiece:)];
    //[panGesture setMaximumNumberOfTouches:10];
    panGesture.moveX = panGesture.moveY = 0.f;
    panGesture.flag = NO;
    panGesture.cFrame = piece.frame;
    [panGesture setDelegate:self];
    [piece addGestureRecognizer:panGesture];
    [panGesture release];
    
    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(showResetMenu:)];
    [piece addGestureRecognizer:longPressGesture];
    [longPressGesture release];
}

- (void)awakeFromNib
{
    //    [self addGestureRecognizersToPiece:firstPieceView];
    //    [self addGestureRecognizersToPiece:secondPieceView];
    //    [self addGestureRecognizersToPiece:thirdPieceView];
}

// scale and rotation transforms are applied relative to the layer's anchor point
// this method moves a gesture recognizer's view's anchor point between the user's fingers
- (void)adjustAnchorPointForGestureRecognizer:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
        UIView *piece = gestureRecognizer.view;
        CGPoint locationInView = [gestureRecognizer locationInView:piece];
        CGPoint locationInSuperview = [gestureRecognizer locationInView:piece.superview];
        
        piece.layer.anchorPoint = CGPointMake(locationInView.x / piece.bounds.size.width, locationInView.y / piece.bounds.size.height);
        piece.center = locationInSuperview;
    }
    
}

// display a menu with a single item to allow the piece's transform to be reset
- (void)showResetMenu:(UILongPressGestureRecognizer *)gestureRecognizer
{
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        UIMenuController *menuController = [UIMenuController sharedMenuController];
        UIMenuItem *resetMenuItem = [[UIMenuItem alloc] initWithTitle:@"Reset" action:@selector(resetPiece:)];
        CGPoint location = [gestureRecognizer locationInView:[gestureRecognizer view]];
        
        [self becomeFirstResponder];
        [menuController setMenuItems:[NSArray arrayWithObject:resetMenuItem]];
        [menuController setTargetRect:CGRectMake(location.x, location.y, 0, 0) inView:[gestureRecognizer view]];
        [menuController setMenuVisible:YES animated:YES];
        
        pieceForReset = [gestureRecognizer view];
        
        [resetMenuItem release];
    }
}

// animate back to the default anchor point and transform
- (void)resetPiece:(UIMenuController *)controller
{
    CGPoint locationInSuperview = [pieceForReset convertPoint:CGPointMake(CGRectGetMidX(pieceForReset.bounds), CGRectGetMidY(pieceForReset.bounds)) toView:[pieceForReset superview]];
    
    [[pieceForReset layer] setAnchorPoint:CGPointMake(0.5, 0.5)];
    [pieceForReset setCenter:locationInSuperview];
    
    [UIView beginAnimations:nil context:nil];
    [pieceForReset setTransform:CGAffineTransformIdentity];
    [UIView commitAnimations];
}

// UIMenuController requires that we can become first responder or it won't display
- (BOOL)canBecomeFirstResponder
{
    return YES;
}

#pragma mark -
#pragma mark === Touch handling  ===
#pragma mark

// shift the piece's center by the pan amount
// reset the gesture recognizer's translation to {0, 0} after applying so the next callback is a delta from the current position
- (void)panPiece:(MyMoveGesture *)gestureRecognizer
{
    UIView *piece = [gestureRecognizer view];
    
    [self adjustAnchorPointForGestureRecognizer:gestureRecognizer];
    curSelectedImage = (UIImageView *)gestureRecognizer.view;
    curFrame = gestureRecognizer.cFrame;
    if (gestureRecognizer.state == UIGestureRecognizerStateEnded) {
        CGPoint translation = [gestureRecognizer translationInView:[piece superview]];
        if (gestureRecognizer.view.frame.size.width>1028 && !gestureRecognizer.flag) {
            if (gestureRecognizer.view.frame.size.width+gestureRecognizer.view.frame.origin.x < detailImageScrollview.contentOffset.x+824) {
                if (detailImageScrollview.contentOffset.x >= (1024.0*(kNumberOfPages-1)-10.0))
                {
                    gestureRecognizer.moveX = 0;
                    gestureRecognizer.moveY = 0;
                    return;
                }
                gestureRecognizer.moveX = 0;
                gestureRecognizer.moveY = 0;
                [UIView animateWithDuration:0.2 animations:^{
                    detailImageScrollview.contentOffset = CGPointMake(detailImageScrollview.contentOffset.x + 1024, 0) ;
                }];
                gestureRecognizer.view.frame = gestureRecognizer.cFrame;
                [self scrollViewDidEndDecelerating:detailImageScrollview];
                
            }
            else if (gestureRecognizer.view.frame.origin.x > detailImageScrollview.contentOffset.x-100) {
                if (detailImageScrollview.contentOffset.x <= 10.0)
                {
                    gestureRecognizer.moveX = 0;
                    gestureRecognizer.moveY = 0;
                    return;
                }
                
                gestureRecognizer.moveX = 0;
                gestureRecognizer.moveY = 0;
                [UIView animateWithDuration:0.2 animations:^{
                    detailImageScrollview.contentOffset = CGPointMake(detailImageScrollview.contentOffset.x - 1024, 0) ;
                }];
                CGFloat scale = gestureRecognizer.cFrame.size.width/gestureRecognizer.view.frame.size.width;
                [gestureRecognizer view].transform = CGAffineTransformScale([[gestureRecognizer view] transform], scale, scale);
                
                gestureRecognizer.view.frame = gestureRecognizer.cFrame;
                [self scrollViewDidEndDecelerating:detailImageScrollview];
                
            }
            
            
            
            
            return;
        }

        if (gestureRecognizer.moveX > 100.f && !gestureRecognizer.flag) {
            if (detailImageScrollview.contentOffset.x <= 10.0)
            {
                gestureRecognizer.moveX = 0;
                gestureRecognizer.moveY = 0;
                return;
            }
                
            gestureRecognizer.moveX = 0;
            gestureRecognizer.moveY = 0;
            [UIView animateWithDuration:0.2 animations:^{
                detailImageScrollview.contentOffset = CGPointMake(detailImageScrollview.contentOffset.x - 1024, 0) ;
            }];
            CGFloat scale = gestureRecognizer.cFrame.size.width/gestureRecognizer.view.frame.size.width;
            [gestureRecognizer view].transform = CGAffineTransformScale([[gestureRecognizer view] transform], scale, scale);
            
            gestureRecognizer.view.frame = gestureRecognizer.cFrame;
            
        }
        else if (gestureRecognizer.moveX < -100.f && !gestureRecognizer.flag) {
            if (detailImageScrollview.contentOffset.x >= (1024.0*(kNumberOfPages-1)-10.0))
            {
                gestureRecognizer.moveX = 0;
                gestureRecognizer.moveY = 0;
                return;
            }
                
            gestureRecognizer.moveX = 0;
            gestureRecognizer.moveY = 0;
            [UIView animateWithDuration:0.2 animations:^{
                detailImageScrollview.contentOffset = CGPointMake(detailImageScrollview.contentOffset.x + 1024, 0) ;
            }];
            gestureRecognizer.view.frame = gestureRecognizer.cFrame;
            
        }
        [self scrollViewDidEndDecelerating:detailImageScrollview];
//        if (gestureRecognizer.view.center.x+1024 <= detailImageScrollview.contentOffset.x || gestureRecognizer.view.center.x >= detailImageScrollview.contentOffset.x) {
//            curSelectedImage.frame = curFrame;
//        }
        gestureRecognizer.flag = NO;
        translation.x = translation.y = 0;
        gestureRecognizer.moveX = 0;
        gestureRecognizer.moveY = 0;

    }
    
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        CGPoint translation = [gestureRecognizer translationInView:[piece superview]];
        
        gestureRecognizer.moveX = translation.x;
        gestureRecognizer.moveY = translation.y;
        NSLog(@"%lf", gestureRecognizer.moveX);
        if (gestureRecognizer.view.frame.size.width>1028 || gestureRecognizer.view.frame.size.height>669) {
            
            [piece setCenter:CGPointMake([piece center].x + translation.x, [piece center].y + translation.y)];
            //        [piece setCenter:CGPointMake([piece center].x, [piece center].y + translation.y)];
            [gestureRecognizer setTranslation:CGPointZero inView:[piece superview]]; 
            if (gestureRecognizer.view.frame.origin.x + gestureRecognizer.view.frame.size.width <=gestureRecognizer.cFrame.origin.x+gestureRecognizer.cFrame.size.width)
            {
                gestureRecognizer.flag = NO;
            }
            else {
                gestureRecognizer.flag = YES;
            }

            
        }
        else {
            gestureRecognizer.flag = NO;
        }

        
    }
}

// rotate the piece by the current rotation
// reset the gesture recognizer's rotation to 0 after applying so the next callback is a delta from the current rotation
- (void)rotatePiece:(UIRotationGestureRecognizer *)gestureRecognizer
{
    [self adjustAnchorPointForGestureRecognizer:gestureRecognizer];
    
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        [gestureRecognizer view].transform = CGAffineTransformRotate([[gestureRecognizer view] transform], [gestureRecognizer rotation]);
        [gestureRecognizer setRotation:0];
    }
}


// scale the piece by the current scale
// reset the gesture recognizer's rotation to 0 after applying so the next callback is a delta from the current scale
- (void)scalePiece:(MyGesture *)gestureRecognizer
{
    [self adjustAnchorPointForGestureRecognizer:gestureRecognizer];
    curSelectedImage = (UIImageView *)gestureRecognizer.view;
    curFrame = gestureRecognizer.cFrame;
    gestureRecognizer.curScale = gestureRecognizer.view.frame.size.width/gestureRecognizer.cFrame.size.width;
//    if (!gestureRecognizer.flag) {
//        gestureRecognizer.flag = YES;
//        //平移
//        UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panPiece:)];
//        [panGesture setMaximumNumberOfTouches:2];
//        [panGesture setDelegate:self];
//        [gestureRecognizer.view addGestureRecognizer:panGesture];
//        [panGesture release];
//
//    }
    if ([gestureRecognizer state] == UIGestureRecognizerStateEnded && gestureRecognizer.curScale < 1.f) {
        NSLog(@"Ended...");
        gestureRecognizer.curScale = 1.0;
        [UIView animateWithDuration:0.2 animations:^{
            gestureRecognizer.view.frame = gestureRecognizer.cFrame;
        }];
        //detailImageScrollview.frame = CGRectMake(gestureRecognizer.cFrame.origin.x, gestureRecognizer.cFrame.origin.y-10, gestureRecognizer.cFrame.size.width, gestureRecognizer.cFrame.size.height+20);
    }
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        if (gestureRecognizer.curScale>2.f && gestureRecognizer.scale>1.f){
            return;
        }
        [gestureRecognizer view].transform = CGAffineTransformScale([[gestureRecognizer view] transform], [gestureRecognizer scale], [gestureRecognizer scale]);
        
        gestureRecognizer.curScale *= gestureRecognizer.scale;
        [gestureRecognizer setScale:1];
        CGRect rect = CGRectMake(gestureRecognizer.center.x-gestureRecognizer.view.frame.size.width/2, gestureRecognizer.center.y-gestureRecognizer.view.frame.size.height/2, gestureRecognizer.view.frame.size.width, gestureRecognizer.view.frame.size.height);
        gestureRecognizer.view.frame = rect;
        //detailImageScrollview.frame = CGRectMake(detailImageScrollview.frame.origin.x,detailImageScrollview.frame.origin.y, gestureRecognizer.view.frame.size.width, detailImageScrollview.frame.size.height);
        NSLog(@"centre:(%lf, %lf), frame:(%lf, %lf, %lf, %lf)", gestureRecognizer.center.x, gestureRecognizer.center.y , gestureRecognizer.view.frame.origin.x, gestureRecognizer.view.frame.origin.y,
              gestureRecognizer.view.frame.size.width, gestureRecognizer.view.frame.size.height);
    }
}

// ensure that the pinch, pan and rotate gesture recognizers on a particular view can all recognize simultaneously
// prevent other gesture recognizers from recognizing simultaneously
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    // if the gesture recognizers's view isn't one of our pieces, don't allow simultaneous recognition
    //if (gestureRecognizer.view != firstPieceView && gestureRecognizer.view != secondPieceView && gestureRecognizer.view != thirdPieceView)
    //        return NO;
    
    // if the gesture recognizers are on different views, don't allow simultaneous recognition
    if (gestureRecognizer.view != otherGestureRecognizer.view)
        return NO;
    
    // if either of the gesture recognizers is the long press, don't allow simultaneous recognition
    if ([gestureRecognizer isKindOfClass:[UILongPressGestureRecognizer class]] || [otherGestureRecognizer isKindOfClass:[UILongPressGestureRecognizer class]])
        return NO;
    
    return YES;
}


@end
