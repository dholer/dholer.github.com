//
//  QuickOrderDetailController.h
//  Showcase_FD
//
//  Created by  on 12-5-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"
#import "FDProductEntity.h"
#import "QuickOrderCompareViewController.h"
#import <QuartzCore/QuartzCore.h>
@protocol QuickOrderDetailControllerDelegate;
@interface QuickOrderDetailController : UIViewController
{
    NSUInteger currentIndex;
    NSMutableArray *allProductList;
    id<QuickOrderDetailControllerDelegate> theDelegate;
    UIImageView         *ivProduct;
    
    UIScrollView        *scrollview;
    
    FDProductEntity     *product;
    QuickOrderCompareViewController     *vcCompare;
    UIButton            *btnAction;
    UIButton                            *btnBack;
    UIView              *vBottom;
    
    UILabel             *labelPrice;
    UILabel             *labelName;
    UILabel             *labelSKUValue;
    UILabel             *labelLwhValue;
    UITextView             *tvMaterialValue;
    UITextView          *tvDesc;
    UIView *pieceForReset;
    CGRect              backFrame;
    CGRect              imageFrame;
    CGFloat             totalScale;
    
    CGRect              orginalFrame;
    CGPoint             center;
    
    UILabel                             *titleLabel;
    CGFloat             deltaY;
    
    UIImageView *curSelectedImage;
    CGRect curFrame;
    
    NSMutableArray      *existList;
    BOOL                isShown;
}

@property (nonatomic, retain) NSMutableArray *allProductList;
@property (nonatomic, retain) NSMutableArray *existList;
@property (nonatomic, assign) id<QuickOrderDetailControllerDelegate> theDelegate;
@property (nonatomic, assign) CGFloat deltaY;

- (BOOL)HasExisted:(FDProductEntity *)fd;
- (id)initWithIndex:(NSUInteger)index AllProduct:(NSMutableArray *)array;

@end

