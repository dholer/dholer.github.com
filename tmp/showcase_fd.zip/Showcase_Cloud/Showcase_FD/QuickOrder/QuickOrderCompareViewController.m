//
//  QuickOrderCompareViewController.m
//  Showcase_FD
//
//  Created by leo on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "QuickOrderCompareViewController.h"
#import "Constants.h"
#import "UIImage+Until.h"
#define SUBVIEWTAGBASE 11999

@implementation QuickOrderCompareViewController
@synthesize arrayData;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    [arrayData release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)btnHidenPressed
{
    [UIView animateWithDuration:0.3 animations:^{
        
        [self.view.superview sendSubviewToBack:self.view];  
        self.view.alpha = 0.0;
        [editBtn setTitle:@"编辑" forState:UIControlStateNormal];
        [self showOrHiddenDelBtn:YES];
        isEdit = NO;
        
    }];
}

- (IBAction)btnEditPressed:(id)sender
{
    if ((isEdit=!isEdit)) {
        [editBtn setTitle:@"完成" forState:UIControlStateNormal];
        [self showOrHiddenDelBtn:NO];
    }else {
        [editBtn setTitle:@"编辑" forState:UIControlStateNormal];
        [self showOrHiddenDelBtn:YES];
    }
}

- (UIView *)createProductCompareView
{
    if(!arrayCompareProductViews)
        arrayCompareProductViews = [[NSMutableArray alloc] init];
    
    for (UIView *subView in arrayCompareProductViews)
    {
        if(subView.superview == nil) {
            // added by Alex @ 2012.4.19
            [[subView viewWithTag:105] setHidden:!isEdit];
            //
            return subView;
        }
    }
    
    UIView *viewProductParent = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 292, 238)];
    viewProductParent.backgroundColor = [UIColor clearColor];
    [arrayCompareProductViews addObject:viewProductParent];
    [viewProductParent release];
    
    UILabel *labelName = [[UILabel alloc] initWithFrame:CGRectMake(13, 4, 134, 21)];
    labelName.tag = 100;
    labelName.text = @"";
    labelName.textColor = [UIColor blackColor];
    labelName.backgroundColor = [UIColor clearColor];
    labelName.font = [UIFont systemFontOfSize:12];
    labelName.textAlignment = UITextAlignmentLeft;
    [viewProductParent addSubview:labelName];
    [labelName release];
    
    UILabel *labelPrice = [[UILabel alloc] initWithFrame:CGRectMake(145, 8, 134, 21)];
    labelPrice.tag = 102;
    labelPrice.text = @"";
    labelPrice.textColor = RGBCOLOR(102, 190, 47, 255);
    labelPrice.backgroundColor = [UIColor clearColor];
    labelPrice.font = [UIFont boldSystemFontOfSize:12];
    labelPrice.textAlignment = UITextAlignmentRight;
    [viewProductParent addSubview:labelPrice];
    [labelPrice release];
    
    UILabel *labelCode = [[UILabel alloc] initWithFrame:CGRectMake(13, 25, 134, 21)];
    labelCode.tag = 103;
    labelCode.text = @"";
    labelCode.textColor = [UIColor grayColor];
    labelCode.backgroundColor = [UIColor clearColor];
    labelCode.font = [UIFont systemFontOfSize:11];
    labelCode.textAlignment = UITextAlignmentLeft;
    [viewProductParent addSubview:labelCode];
    [labelCode release];
    
    UIImageView *ivProduct = [[UIImageView alloc] initWithFrame:CGRectMake(18, 54, 257, 177)];
    ivProduct.tag = 104;
    [viewProductParent addSubview:ivProduct];
    [ivProduct release];
    
    UIButton *delBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    delBtn.tag = 105;
    delBtn.frame = CGRectMake(3.0, 5.0, 20, 21.0);
    [delBtn setImage:[UIImage imageNamed:@"icon-delet.png"] forState:UIControlStateNormal];
    [delBtn addTarget:self action:@selector(deleteProduct:) forControlEvents:UIControlEventTouchUpInside];
    [viewProductParent addSubview:delBtn];
//    delBtn.hidden = YES;
    // modified by Alex @ 2012.4.19
    delBtn.hidden = !isEdit;
    //
    
    return viewProductParent;
}

- (void)showOrHiddenDelBtn:(BOOL)flag{
    
    
    for (int i=0; i<[arrayData count]; i++) {
        
        UIView *vProductParent = [self.view viewWithTag:i+SUBVIEWTAGBASE];
        UIButton *delBtn = (UIButton *)[vProductParent viewWithTag:105];
        [delBtn setHidden:flag];
    }

}

- (void)reloadCompareList
{
    [arrayCompareProductViews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    int leftPos = 0.0;
    int topPos = 0.0;
    
    for (int i=0; i<[arrayData count]; i++) {
        
        FDProductEntity *productEntiry = [arrayData objectAtIndex:i];
        UIView *vProductParent = [self createProductCompareView];
        vProductParent.frame = CGRectMake(leftPos, topPos, vProductParent.frame.size.width, vProductParent.frame.size.height);
        vProductParent.tag  = i+SUBVIEWTAGBASE;
        [vContent addSubview:vProductParent];
        
        UILabel *labelName = (UILabel *)[vProductParent viewWithTag:100];
        UILabel *labelPrice = (UILabel *)[vProductParent viewWithTag:102];
        UILabel *labelCode = (UILabel *)[vProductParent viewWithTag:103];
        UIImageView *ivProduct = (UIImageView *)[vProductParent viewWithTag:104];
        labelName.text = productEntiry.name;
        labelPrice.text = [NSString stringWithFormat:@"%@ %.2f",[DataManagerModel currentPriceCurrency:productEntiry],productEntiry.price];
        labelCode.text = productEntiry.sku;
        ivProduct.image = [UIImage productImageName:productEntiry.fullImage];
        CGSize size = CGSizeMake(257, 177);
        //UIImage *image = ivProduct.image;
        float scale = ivProduct.image.size.width/size.width>ivProduct.image.size.height/size.height?ivProduct.image.size.width/size.width:ivProduct.image.size.height/size.height;
        if (ivProduct.image) {
            ivProduct.frame = CGRectMake(18+(size.width-ivProduct.image.size.width/scale)/2, 54+(size.height-ivProduct.image.size.height/scale)/2, ivProduct.image.size.width/scale, ivProduct.image.size.height/scale); 
        }
        else {
            ivProduct.frame = CGRectMake(0, 0 ,0 ,0); 
        }
        leftPos += vProductParent.frame.size.width;
        
        if(leftPos > vProductParent.frame.size.width + 10)
        {
            leftPos = 0.0;
            topPos += vProductParent.frame.size.height;
        }
    }
}

- (void)addProductToList:(FDProductEntity *)product
{
    if(!arrayData)
        arrayData = [[NSMutableArray alloc] init];
    
    [arrayData addObject:product];
}

- (void)deleteProduct:(id)sender{
    UIButton *delBtn = (UIButton *)sender;
    UIView *parentView = delBtn.superview;
    if (parentView) {
        int tag = parentView.tag - SUBVIEWTAGBASE;
        [arrayData removeObjectAtIndex:tag];
        [UIView animateWithDuration:0.3 animations:^{
            [self reloadCompareList];
        }];
    }
}

@end
