//
//  QuickOrderSearchViewController.h
//  Showcase_FD
//
//  Created by leo on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//


@protocol QucikOrderSearchViewDelegate;
@interface QuickOrderSearchViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    id<QucikOrderSearchViewDelegate>    theDelegate;
    NSMutableArray          *arrayData;
    
    IBOutlet UITableView    *theTableView;
}

@property (nonatomic, assign) id<QucikOrderSearchViewDelegate>    theDelegate;
@property (nonatomic, retain) NSMutableArray          *arrayData;
// added by Alex @ 2012.5.3
@property (nonatomic, retain) NSString *selectedShortcut;
//
- (IBAction)btnHidenPressed;
- (void)setShortCuts:(NSMutableArray *)arrayShortCuts;
@end


@protocol QucikOrderSearchViewDelegate <NSObject>

- (void)shortCutAdded:(NSString *)shortCut;
- (void)shortCutRemoved:(NSString *)shortCut;

// added by Alex @ 2012.5.3
- (void)shortCutChanged:(NSString *)shortCut;
//

@end