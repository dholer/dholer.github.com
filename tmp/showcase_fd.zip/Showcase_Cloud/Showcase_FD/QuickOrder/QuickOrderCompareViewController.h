//
//  QuickOrderCompareViewController.h
//  Showcase_FD
//
//  Created by leo on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FDProductEntity.h"

@interface QuickOrderCompareViewController : UIViewController
{
    NSMutableArray              *arrayData;
    
    IBOutlet UIView             *vContent;
    NSMutableArray              *arrayCompareProductViews;
    
    BOOL                        isEdit;
    IBOutlet UIButton           *editBtn;
}
@property (nonatomic, retain) NSMutableArray        *arrayData;

- (IBAction)btnHidenPressed;
- (IBAction)btnEditPressed:(id)sender;

- (void)addProductToList:(FDProductEntity *)product;
- (void)reloadCompareList;

@end
