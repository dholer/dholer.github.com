//
//  QuickOrderProductDetailView.h
//  Showcase_FD
//
//  Created by leo on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "FDProductEntity.h"

@protocol QuickOrderProductDetailDelegate;
@interface QuickOrderProductDetailView : UIView <UIGestureRecognizerDelegate>
{
    id<QuickOrderProductDetailDelegate> theDelegate;
    UIImageView         *ivProduct;
    
    FDProductEntity     *product;
    
    UIButton            *btnAction;
    
    UIView              *vBottom;
    
    UILabel             *labelPrice;
    UILabel             *labelName;
    UILabel             *labelSKUValue;
    UILabel             *labelLwhValue;
    UITextView             *tvMaterialValue;
    UITextView          *tvDesc;
    UIView *pieceForReset;
    CGRect              backFrame;
    CGRect              imageFrame;
    CGFloat             totalScale;
    
    CGRect              orginalFrame;
    CGPoint             center;
    
}
@property (nonatomic, assign) id<QuickOrderProductDetailDelegate> theDelegate;
@property (nonatomic, retain) FDProductEntity     *product;
- (void)addGestureRecognizersToPiece:(UIView *)piece;

- (void)initWithProduct:(FDProductEntity *)productEntiry;
- (void)ResetFrame;

@end

@protocol QuickOrderProductDetailDelegate <NSObject>

- (void)detailView:(QuickOrderProductDetailView *)detailView productAddToChart:(FDProductEntity *)productEntity;
- (void)detailView:(QuickOrderProductDetailView *)detailView productAddToCompare:(FDProductEntity *)productEntity;

@end;