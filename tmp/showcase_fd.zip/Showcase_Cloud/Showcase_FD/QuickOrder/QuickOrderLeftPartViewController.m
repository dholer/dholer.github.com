//
//  QuickOrderLeftPartViewController.m
//  Showcase_FD
//
//  Created by leo on 3/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "QuickOrderLeftPartViewController.h"
#import "Constants.h"

@implementation UICategoryButton:UIButton
@synthesize categoryEntiry;

- (void)dealloc
{
    [super dealloc];
    
    [categoryEntiry release];
}

@end

@implementation QuickOrderLeftPartViewController
@synthesize leftDelegate;
@synthesize dictData;
// added by Alex @2012.4.27
- (id)init
{
    self = [super init];
    if (self) {
        //deal with refresh data after sync finished
        [[NSNotificationCenter defaultCenter] addObserverForName:NOTIFICATION_FD_FINISHED_SYNC object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note){
            [self.dictData removeAllObjects];
            roowCategoryID = 0;
            styleCategoryID = 0;
            [tvIndex reloadData];
        }];
    }
    return self;
}
//
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

// added by Alex @ 2012.5.3
- (void)resetSelection
{
    [tvIndex selectRowAtIndexPath:nil animated:NO scrollPosition:UITableViewScrollPositionNone];
    styleCategoryID = 0;
    roowCategoryID = 0;
    UIScrollView *svLeftIndex = (UIScrollView *)[self.view viewWithTag:100];
    UIImageView *ivHighlight = (UIImageView *)[svLeftIndex viewWithTag:101];
    
    for (UIView *subView in svLeftIndex.subviews)
    {
        if([subView isKindOfClass:[UIButton class]])
        {
            UIButton *btnOther = (UIButton *)subView;
            if ([btnOther.titleLabel.text isEqualToString:@"全\n部\n房\n型"]) {
                ivHighlight.center = btnOther.center;
                btnOther.selected = YES;
            }
            else 
                btnOther.selected = NO;
        }
    }
}
//

- (void)addBGImageView
{
    UIImageView *ivBG = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    ivBG.image = [UIImage imageNamed:@"sidemenu-bg.png"];
    [self.view addSubview:ivBG];
    [ivBG release];
}

- (void)addLeftView
{
    UIScrollView *svLeftIndex = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 44, 71, 590)];
    svLeftIndex.tag = 100;
    svLeftIndex.backgroundColor = [UIColor clearColor];
    [self.view addSubview:svLeftIndex];
    [svLeftIndex release];
    
    UIImageView *ivHighlight = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"navon-bg.png"]];
    ivHighlight.tag = 101;
    ivHighlight.frame = CGRectMake(0, 0, 71, 100);
    [svLeftIndex addSubview:ivHighlight];
    ivHighlight.hidden = YES;
    [ivHighlight release];
    
    UIImageView *ivLogo = [[UIImageView alloc] initWithFrame:CGRectMake(22, 634, 27, 98)];
    ivLogo.image = [UIImage imageNamed:@"small-logo.png"];
    [self.view addSubview:ivLogo];
    [ivLogo release];
}

- (void)addRightView
{
    UILabel *labelTitle = [[UILabel alloc] initWithFrame:CGRectMake(71, 10, 180, 21)]; 
    labelTitle.text = @"所有系列";
    labelTitle.textColor = [UIColor blackColor];
    labelTitle.backgroundColor = [UIColor clearColor];
    labelTitle.font = [UIFont boldSystemFontOfSize:24];
    labelTitle.textAlignment = UITextAlignmentCenter;
    [self.view addSubview:labelTitle];
    [labelTitle release];
    
    tvIndex = [[UITableView alloc] initWithFrame:CGRectMake(71, 44, 183, 724) style:UITableViewStylePlain];
    tvIndex.tag = 200;
    tvIndex.delegate = self;
    tvIndex.dataSource = self;
    [tvIndex setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    tvIndex.rowHeight = 70.f;
    tvIndex.backgroundColor = [UIColor clearColor];
    [self.view addSubview:tvIndex];
    [tvIndex release];
    
    UIButton *btnMoving = [UIButton buttonWithType:UIButtonTypeCustom];
    btnMoving.frame = CGRectMake(249, 346, 40, 75);
    btnMoving.showsTouchWhenHighlighted = YES;
    [btnMoving addTarget:self action:@selector(btnArrowPressed:) forControlEvents:UIControlEventTouchUpInside];
    [btnMoving setImage:[UIImage imageNamed:@"arrow-rgt.png"] forState:UIControlStateNormal];
    [btnMoving setImage:[UIImage imageNamed:@"arrow-lft.png"] forState:UIControlStateSelected];
    // modified by Alex @ 2012.4.17
    [btnMoving setSelected:YES];
    //
    [self.view addSubview:btnMoving];
   
}

- (void)reloadName
{
    UIScrollView *svLeftIndex = (UIScrollView *)[self.view viewWithTag:100];
    for (UIView *subView in svLeftIndex.subviews)
    {
        if([subView isKindOfClass:[UIButton class]])
            [subView removeFromSuperview];
    }
    
    if(dictData)
    {
        NSMutableArray *arrayRoom = [dictData objectForKey:ROOM];
        
        UIImageView *ivHighlight = (UIImageView *)[svLeftIndex viewWithTag:101];
        if(arrayRoom && [arrayRoom count] > 0)
        {
            FDProductCatalogEntity *tempcatalog = [[FDProductCatalogEntity alloc] init];
            tempcatalog.catalogID = 0;
            tempcatalog.name = @"全部房型";
            tempcatalog.type = ROOM;
            tempcatalog.order = 0;
            [arrayRoom insertObject:tempcatalog atIndex:0];
            [tempcatalog release];  
            
            float topPos = 0.0;
            int tag = 0;
            UIButton *firstSelected = nil;
            UIScrollView *svLeftIndex = (UIScrollView *)[self.view viewWithTag:100];
            
            [svLeftIndex setContentSize:CGSizeMake(71, [arrayRoom count]*120)];
            for (FDProductCatalogEntity *proEntiry in arrayRoom)
            {
                UICategoryButton *btnRoom = [UICategoryButton buttonWithType:UIButtonTypeCustom];
                btnRoom.tag = ++tag;
                btnRoom.frame = CGRectMake(0, topPos, 71, 120);
                btnRoom.titleLabel.textAlignment = UITextAlignmentCenter;
                [btnRoom.titleLabel setAdjustsFontSizeToFitWidth:YES];
                btnRoom.titleLabel.numberOfLines = 0;
                btnRoom.titleLabel.lineBreakMode = UILineBreakModeWordWrap;
                btnRoom.titleLabel.font = [UIFont boldSystemFontOfSize:20];
                [btnRoom setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
                [btnRoom setTitleColor:RGBCOLOR(132,187,59,1) forState:UIControlStateSelected];
                [btnRoom addTarget:self action:@selector(btnRoomPressed:) forControlEvents:UIControlEventTouchUpInside];
                [svLeftIndex addSubview:btnRoom];
                btnRoom.categoryEntiry = proEntiry;
                
                if(proEntiry.name.length > 0)
                {
                    NSString *newName = [proEntiry.name substringToIndex:1];
                    for (int i = 1; i < proEntiry.name.length; i++)
                    {
                        newName = [newName stringByAppendingFormat:@"\n%@", [proEntiry.name substringWithRange:NSMakeRange(i, 1)]];
                    }
                    [btnRoom setTitle:newName forState:UIControlStateNormal];
                    [btnRoom setTitle:newName forState:UIControlStateSelected];
                }
                
                topPos += 100;
                
                if(!firstSelected)
                    firstSelected = btnRoom;
            }
            
            [self btnRoomPressed:firstSelected];
            
            ivHighlight.hidden = NO;
        }
        else
            ivHighlight.hidden = YES;
    }
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
    self.view.frame = CGRectMake(0, 0, 290, 768);
    
    [self addBGImageView];
    
    [self addLeftView];
    
    [self addRightView];
    
    roowCategoryID = 0;
    styleCategoryID = 0;
    
    [self reloadName];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (void)reloadContent
{
    self.dictData = [[DataManagerModel sharedDataModel] getAllCatagoriesToDictionary];
    
    [self reloadName];
}

#pragma mark
#pragma UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(dictData)
    {
        NSMutableArray *arrayStyle = [dictData objectForKey:STYLE];
        return [arrayStyle count];
    }

    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *const identify = @"QuickOrderLeftPartViewControllerCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if(!cell)
    {
        
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identify] autorelease];

        [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        cell.textLabel.textColor = [UIColor grayColor];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.textLabel.font = [UIFont systemFontOfSize:18];
        UIImageView *lineView = [[UIImageView alloc] initWithFrame:CGRectMake(2, tableView.rowHeight-1, tableView.frame.size.width-5, 2)];
        lineView.image = [UIImage imageNamed:@"dividerline.png"];
        [cell.contentView addSubview:lineView];
        [lineView release];
        
        UIImageView *ivSelected = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 220, 70)];
        ivSelected.image = [UIImage imageNamed:@"news-selectbg.png"];
        cell.selectedBackgroundView = ivSelected;
        [ivSelected release];
    }
    
    NSMutableArray *arrayStyle = [dictData objectForKey:STYLE];
    FDProductCatalogEntity *proEntiry = [arrayStyle objectAtIndex:indexPath.row];
    NSString *txName = proEntiry.name;
    if(proEntiry.code && proEntiry.code.length > 0)
        txName = [txName stringByAppendingFormat:@"-%@", proEntiry.code];
    
    cell.textLabel.text = txName;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

#pragma mark
#pragma UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray *arrayStyle = [dictData objectForKey:STYLE];
    FDProductCatalogEntity *proEntiry = [arrayStyle objectAtIndex:indexPath.row];
    
    if (styleCategoryID!=proEntiry.catalogID) {
        
         styleCategoryID = proEntiry.catalogID;
        
        if(leftDelegate && [leftDelegate respondsToSelector:@selector(leftCategoryChanged:styleCategory:)])
            [leftDelegate leftCategoryChanged:roowCategoryID styleCategory:styleCategoryID];
    }

}

- (void)btnRoomPressed:(UICategoryButton *)sender
{
    if(sender.selected)
        return ;
    
    sender.selected = !sender.selected;
    UIScrollView *svLeftIndex = (UIScrollView *)[self.view viewWithTag:100];
    
    UIImageView *ivHighlight = (UIImageView *)[svLeftIndex viewWithTag:101];
    ivHighlight.center = sender.center;
//    [UIView animateWithDuration:0.3 animations:^{
//        
//        ivHighlight.center = sender.center;
//    }];
    for (UIView *subView in svLeftIndex.subviews)
    {
        if([subView isKindOfClass:[UIButton class]])
        {
            if(subView.tag != sender.tag)
            {
                UIButton *btnOther = (UIButton *)subView;
                btnOther.selected = NO;
            }
        }
    }
    
    UITableView *tvIndex = (UITableView *)[self.view viewWithTag:200];
    [tvIndex reloadData];
    styleCategoryID = 0;
    
    
    roowCategoryID = sender.categoryEntiry.catalogID;
    
    if(leftDelegate && [leftDelegate respondsToSelector:@selector(leftCategoryChanged:styleCategory:)])
        [leftDelegate leftCategoryChanged:roowCategoryID styleCategory:styleCategoryID];
}

- (void)selectStyle:(int)styleID
{
    UITableView *tvIndex = (UITableView *)[self.view viewWithTag:200];
    [tvIndex reloadData];
    
    styleCategoryID = styleID;
    
    NSMutableArray *arrayStyle = [dictData objectForKey:STYLE];
    int row = 0;
    for (FDProductCatalogEntity *proEntiry in arrayStyle) 
    {
        if(proEntiry.catalogID == styleID)
        {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
            [tvIndex selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
            
            break;
        }
        
        row++;
    }
    
    if(leftDelegate && [leftDelegate respondsToSelector:@selector(leftCategoryChanged:styleCategory:)])
        [leftDelegate leftCategoryChanged:roowCategoryID styleCategory:styleCategoryID];
}

#pragma mark
- (void)btnArrowPressed:(UIButton *)sender
{
    if(leftDelegate)
    {
        if(sender.isSelected)
        {
            if([leftDelegate respondsToSelector:@selector(leftPartViewWillDisappear:)])
                [leftDelegate leftPartViewWillDisappear:self];
        }
        else
        {
            if([leftDelegate respondsToSelector:@selector(leftPartViewWillAppear:)])
                [leftDelegate leftPartViewWillAppear:self];
        }
    }
    
    sender.selected = !sender.isSelected;
}

@end
