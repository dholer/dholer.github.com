//
//  QuickOrderSearchViewController.m
//  Showcase_FD
//
//  Created by leo on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "QuickOrderSearchViewController.h"

// added by Alex @ 2012.5.3
@interface QuickOrderSearchViewController ()


@end
// 

@implementation QuickOrderSearchViewController
@synthesize arrayData;
@synthesize theDelegate;

// added by Alex @ 2012.5.3
@synthesize selectedShortcut = _selectedShortcut;

- (void)dealloc
{
    [_selectedShortcut release];
    [super dealloc];
}
// 

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (IBAction)btnHidenPressed
{
    [UIView animateWithDuration:0.3 animations:^{
        self.view.alpha = 0.0;
    }];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    static NSString *const identiry = @"QucikOrderSearchViewCell";
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identiry];
//    
//    if(!cell)
//    {
        UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
//    }
    NSString *str = [arrayData objectAtIndex:indexPath.row];
    if ([str isEqualToString:@""]||!str||[str isEqualToString:nil]) {
        cell.textLabel.text = @"其他";
    }
    else {
        cell.textLabel.text = str;
    }
    
    // modified by Alex @ 2012.5.3
//    NSLog(@"%@", str);
//    cell.accessoryType = UITableViewCellAccessoryCheckmark;
    if ([str isEqualToString:[self selectedShortcut]])
        [cell setAccessoryType:UITableViewCellAccessoryCheckmark];
    //
    return cell;
}

#pragma mark
#pragma UITableViewDataSource
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if(cell.accessoryType == UITableViewCellAccessoryCheckmark)
    {
        cell.accessoryType =  UITableViewCellAccessoryNone;
        
        // modified by Alex @ 2012.5.3
//        if(theDelegate && [theDelegate respondsToSelector:@selector(shortCutRemoved:)])
//            [theDelegate shortCutRemoved:[arrayData objectAtIndex:indexPath.row]];
        [self setSelectedShortcut:nil];
        [theDelegate shortCutChanged:nil];
        //
    }
    else
    {
        for (int i = 0; i < self.arrayData.count; i++) {
            UITableViewCell *cell = [theTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
            if (cell.accessoryType == UITableViewCellAccessoryCheckmark)
                cell.accessoryType = UITableViewCellAccessoryNone;
        }
        cell.accessoryType =  UITableViewCellAccessoryCheckmark;
        
        // modified by Alex @ 2012.5.3
        NSString *shortcut = [arrayData objectAtIndex:[indexPath row]];
        [self setSelectedShortcut:shortcut];
//        if(theDelegate && [theDelegate respondsToSelector:@selector(shortCutAdded:)])
//            [theDelegate shortCutAdded:[arrayData objectAtIndex:indexPath.row]];
        [theDelegate shortCutChanged:[self selectedShortcut]];
        //
    }
}

- (void)setShortCuts:(NSMutableArray *)arrayShortCuts
{
    self.arrayData = arrayShortCuts;
    [theTableView reloadData];
}

@end
