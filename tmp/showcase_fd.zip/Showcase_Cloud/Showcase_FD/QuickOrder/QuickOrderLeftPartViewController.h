//
//  QuickOrderLeftPartViewController.h
//  Showcase_FD
//
//  Created by leo on 3/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FDProductCatalogEntity.h"

@protocol QuickOrderLeftPartDelegate;
@interface QuickOrderLeftPartViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    id<QuickOrderLeftPartDelegate>  leftDelegate;
    
    NSMutableDictionary             *dictData;
    
    int                             roowCategoryID;
    int                             styleCategoryID;
    UITableView *tvIndex;
}

@property (nonatomic, assign) id<QuickOrderLeftPartDelegate>  leftDelegate;
@property (nonatomic, retain) NSMutableDictionary         *dictData;

- (void)reloadContent;
- (void)btnRoomPressed:(UIButton *)sender;
- (void)selectStyle:(int)styleID;

// added by Alex @ 2012.5.3
- (void)resetSelection;
//

@end

@protocol QuickOrderLeftPartDelegate <NSObject>

- (void)leftPartViewWillDisappear:(QuickOrderLeftPartViewController *)theVCLeftPart;
- (void)leftPartViewWillAppear:(QuickOrderLeftPartViewController *)theVCLeftPart;

- (void)leftCategoryChanged:(int)roomCategoryID styleCategory:(int)styleCategoryID;

@end

@interface UICategoryButton : UIButton
{
    FDProductCatalogEntity      *categoryEntiry;
}
@property (nonatomic, retain) FDProductCatalogEntity      *categoryEntiry;

@end