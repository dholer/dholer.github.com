//
//  QuickOrderProductDetailView.m
//  Showcase_FD
//
//  Created by leo on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "QuickOrderProductDetailView.h"
#import "Constants.h"
#import "UIImage+Until.h"
#import "NSString+HTML.h"

@implementation QuickOrderProductDetailView
@synthesize theDelegate;
@synthesize product;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        backFrame = frame;
        self.backgroundColor = [UIColor whiteColor];
        
        ivProduct = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        ivProduct.image = [UIImage imageNamed:@"img-18.png"];
        [ivProduct setUserInteractionEnabled:YES];
        [ivProduct setExclusiveTouch:YES];
        [self addGestureRecognizersToPiece:ivProduct];
        [self addSubview:ivProduct];
        [ivProduct release];
        
        //Add bottom View
        vBottom = [[UIView alloc] initWithFrame:CGRectMake(0, frame.size.height - 307, frame.size.width, 307)];
        vBottom.backgroundColor = [UIColor clearColor];
        [self addSubview:vBottom];
        [vBottom release];
        
        UIImageView *ivBottomTop = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, 47)];
        ivBottomTop.image = [UIImage imageNamed:@"tab-productinfo.png"];
        [vBottom addSubview:ivBottomTop];
        [ivBottomTop release];
        
        btnAction = [UIButton buttonWithType:UIButtonTypeCustom];
        btnAction.frame = CGRectMake(870, 0, 141, 47);
        [btnAction addTarget:self action:@selector(btnMovingPressed:) forControlEvents:UIControlEventTouchUpInside];
        [vBottom addSubview:btnAction];
        
        UIView *vBottomBottom = [[UIView alloc] initWithFrame:CGRectMake(0, 47, 1024, 460)];
        vBottomBottom.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"pop-bg.png"]];
        vBottomBottom.alpha = 0.6;
        [vBottom addSubview:vBottomBottom];
        [vBottomBottom release];
        
        UIButton *btnCompare = [UIButton buttonWithType:UIButtonTypeCustom];
        btnCompare.frame = CGRectMake(805, 55, 82, 40);
        btnCompare.titleLabel.font = [UIFont systemFontOfSize:15];
        btnCompare.titleLabel.textColor = [UIColor blackColor];
        [btnCompare setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnCompare setTitle:@"加入对比" forState:UIControlStateNormal];
        [btnCompare setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare.png"] forState:UIControlStateNormal];
        [btnCompare setBackgroundImage:[UIImage imageNamed:@"btn-addtocompare-on.png"] forState:UIControlStateHighlighted];
        [btnCompare addTarget:self action:@selector(btnComparePressed) forControlEvents:UIControlEventTouchUpInside];
        [vBottom addSubview:btnCompare];
        
        UIButton *btnAdd = [UIButton buttonWithType:UIButtonTypeCustom];
        btnAdd.frame = CGRectMake(890, 55, 90, 40);
        btnAdd.titleLabel.font = [UIFont systemFontOfSize:15];
        [btnAdd setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnAdd setTitle:@"加入购物车" forState:UIControlStateNormal];
        [btnAdd setBackgroundImage:[UIImage imageNamed:@"btn-addtoshopcart.png"] forState:UIControlStateNormal];
        [btnAdd setBackgroundImage:[UIImage imageNamed:@"btn-addtoshopcart-on.png"] forState:UIControlStateHighlighted];
        [btnAdd addTarget:self action:@selector(btnAddPressed) forControlEvents:UIControlEventTouchUpInside];
        [vBottom addSubview:btnAdd];
        
        UILabel *labelPriceLabel = [[UILabel alloc] initWithFrame:CGRectMake(840, 110, 40, 21)];
        labelPriceLabel.text = @"价格:";
        labelPriceLabel.textColor = [UIColor blackColor];
        labelPriceLabel.backgroundColor = [UIColor clearColor];
        labelPriceLabel.font = [UIFont systemFontOfSize:15];
        labelPriceLabel.textAlignment = UITextAlignmentLeft;
        [vBottom addSubview:labelPriceLabel];
        [labelPriceLabel release];
        
        labelPrice = [[UILabel alloc] initWithFrame:CGRectMake(878, 108, 150, 21)];
        labelPrice.text = @"￥30,000";
        labelPrice.textColor = RGBCOLOR(132,187,59,1);
        labelPrice.backgroundColor = [UIColor clearColor];
        labelPrice.font = [UIFont boldSystemFontOfSize:22];
        labelPrice.textAlignment = UITextAlignmentLeft;
        [vBottom addSubview:labelPrice];
        [labelPrice release];
        
        labelName = [[UILabel alloc] initWithFrame:CGRectMake(90, 102, 600, 30)];
        labelName.text = @"三人沙发";
        labelName.textColor = [UIColor blackColor];
        labelName.backgroundColor = [UIColor clearColor];
        labelName.font = [UIFont systemFontOfSize:25];
        labelName.textAlignment = UITextAlignmentLeft;
        [vBottom addSubview:labelName];
        [labelName release];
        
        UIView *vSeporter = [[UIView alloc] initWithFrame:CGRectMake(90, 143, 885, 1)];
        vSeporter.backgroundColor = [UIColor grayColor];
        [vBottom addSubview:vSeporter];
        [vSeporter release];
        
        UILabel *labelSKU = [[UILabel alloc] initWithFrame:CGRectMake(90, 158, 60, 21)];
        labelSKU.text = @"编号:";
        labelSKU.textColor = [UIColor darkGrayColor];
        labelSKU.backgroundColor = [UIColor clearColor];
        labelSKU.font = [UIFont systemFontOfSize:17];
        labelSKU.textAlignment = UITextAlignmentLeft;
        [vBottom addSubview:labelSKU];
        [labelSKU release];
        
        labelSKUValue = [[UILabel alloc] initWithFrame:CGRectMake(150, 158, 200, 21)];
        labelSKUValue.text = @"ACL09-353";
        labelSKUValue.textColor = [UIColor darkGrayColor];
        labelSKUValue.backgroundColor = [UIColor clearColor];
        labelSKUValue.font = [UIFont systemFontOfSize:17];
        labelSKUValue.textAlignment = UITextAlignmentLeft;
        [vBottom addSubview:labelSKUValue];
        [labelSKUValue release];
        
        UILabel *labelCode = [[UILabel alloc] initWithFrame:CGRectMake(90, 188, 200, 21)];
        labelCode.text = @"规格:";
        labelCode.textColor = [UIColor darkGrayColor];
        labelCode.backgroundColor = [UIColor clearColor];
        labelCode.font = [UIFont systemFontOfSize:17];
        labelCode.textAlignment = UITextAlignmentLeft;
        [vBottom addSubview:labelCode];
        [labelCode release];
        
        labelLwhValue = [[UILabel alloc] initWithFrame:CGRectMake(150, 188, 200, 21)];
        labelLwhValue.text = @"2000*970*980mm";
        labelLwhValue.textColor = [UIColor darkGrayColor];
        labelLwhValue.backgroundColor = [UIColor clearColor];
        labelLwhValue.font = [UIFont systemFontOfSize:17];
        labelLwhValue.textAlignment = UITextAlignmentLeft;
        [vBottom addSubview:labelLwhValue];
        [labelLwhValue release];
        
        UILabel *labelLwh = [[UILabel alloc] initWithFrame:CGRectMake(90, 218, 200, 21)];
        labelLwh.text = @"材质:";
        labelLwh.textColor = [UIColor darkGrayColor];
        labelLwh.backgroundColor = [UIColor clearColor];
        labelLwh.font = [UIFont systemFontOfSize:17];
        labelLwh.textAlignment = UITextAlignmentLeft;
        [vBottom addSubview:labelLwh];
        [labelLwh release];
        
        tvMaterialValue = [[UITextView alloc] initWithFrame:CGRectMake(143, 211, 170, 63)];
        tvMaterialValue.text = @"香楠木，桃花心薄片";
        tvMaterialValue.textColor = [UIColor darkGrayColor];
        tvMaterialValue.backgroundColor = [UIColor clearColor];
        tvMaterialValue.font = [UIFont systemFontOfSize:17];
        tvMaterialValue.textAlignment = UITextAlignmentLeft;
        tvMaterialValue.contentMode = UIControlContentVerticalAlignmentTop;
        [vBottom addSubview:tvMaterialValue];
        [tvMaterialValue release];
        
        UILabel *labelDesc = [[UILabel alloc] initWithFrame:CGRectMake(337, 158, 637, 21)];
        labelDesc.text = @"设计方案:";
        labelDesc.textColor = [UIColor darkGrayColor];
        labelDesc.backgroundColor = [UIColor clearColor];
        labelDesc.font = [UIFont systemFontOfSize:17];
        labelDesc.textAlignment = UITextAlignmentLeft;
        [vBottom addSubview:labelDesc];
        [labelDesc release];
        
        tvDesc = [[UITextView alloc] initWithFrame:CGRectMake(337, 185, 625, 100)];
        tvDesc.editable = NO;
        tvDesc.backgroundColor = [UIColor clearColor];
        tvDesc.textColor = [UIColor darkGrayColor];
        tvDesc.textAlignment = UITextAlignmentLeft;
        tvDesc.contentMode = UIViewContentModeTopLeft;
        tvDesc.font = [UIFont systemFontOfSize:17];
        [vBottom addSubview:tvDesc];
        [tvDesc release];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)initWithProduct:(FDProductEntity *)productEntiry
{
    self.product = productEntiry;
    
    //
    //CGRect frame = self.frame;
    CGRect frame = CGRectMake(self.frame.origin.x+20, self.frame.origin.y+20, self.frame.size.width-40, self.frame.size.height-40);
    center = CGPointMake(self.frame.origin.x+20+(self.frame.size.width-40)/2, self.frame.origin.y+20+(self.frame.size.height-40)/2);
    NSLog(@"大图的frame:(%lf, %lf, %lf, %lf)", self.frame.origin.x+20, self.frame.origin.y+20, self.frame.size.width-40, self.frame.size.height-40);
    vBottom.frame = CGRectMake(0, self.frame.size.height - 47, self.frame.size.width, 307);
    btnAction.selected = NO;

    ivProduct.image = nil;
    ivProduct.contentMode = UIViewContentModeScaleToFill;
    labelName.text = @"";
    labelPrice.text = @"";
    labelSKUValue.text = @"";
    labelLwhValue.text = @"";
    tvMaterialValue.text = @"";
    tvDesc.text = @"";
    
    if(product)
    {
        ivProduct.image = [UIImage productImageName:product.fullImage];
        totalScale = 1.0;
        //ivProduct.center = CGPointMake(512, 333);
        float scale = ivProduct.image.size.width/frame.size.width>ivProduct.image.size.height/frame.size.height?ivProduct.image.size.width/frame.size.width:ivProduct.image.size.height/frame.size.height;
        if (ivProduct.image) {
            ivProduct.frame = CGRectMake((backFrame.size.width-ivProduct.image.size.width/scale)/2, (backFrame.size.height-ivProduct.image.size.height/scale)/2, ivProduct.image.size.width/scale, ivProduct.image.size.height/scale); 
        }
        else {
            ivProduct.frame = CGRectMake(0, 0 ,0 ,0); 
        }
		orginalFrame = ivProduct.frame;
        
        labelName.text = product.name;
        labelPrice.text = [NSString stringWithFormat:@"￥%.2f", product.price];
        labelSKUValue.text = product.sku;
        labelLwhValue.text = product.lwh;
        tvMaterialValue.text = product.material;
        tvDesc.text = [NSString stringFromHTMLString:product.desc];

    }
}

- (void)btnMovingPressed:(UIButton *)sender
{    
    CGRect frame = self.frame;
    if(sender.selected)
    {
        [UIView animateWithDuration:0.3 animations:^{
            vBottom.frame = CGRectMake(0, frame.size.height - 47, frame.size.width, 307);
        }];
    }
    else
    {
        [UIView animateWithDuration:0.3 animations:^{
            vBottom.frame = CGRectMake(0, frame.size.height - 307, frame.size.width, 307);
        }];
    }
    //scroll textview display longtext
    tvDesc.contentOffset = CGPointMake(0, 1);
    tvMaterialValue.contentOffset = CGPointMake(0, 1);
    //end
    sender.selected = !sender.selected;
}

- (void)btnComparePressed
{
    if(theDelegate && [theDelegate respondsToSelector:@selector(detailView:productAddToCompare:)])
    {
        [theDelegate detailView:self productAddToCompare:product];
    }
}

- (void)btnAddPressed
{
    if(theDelegate && [theDelegate respondsToSelector:@selector(detailView:productAddToChart:)])
    {
        [theDelegate detailView:self productAddToChart:product];
    }
}


//////////////////////////////////////////////////////////////////
#pragma mark gesture
- (void)addGestureRecognizersToPiece:(UIView *)piece
{
	
    //	//旋转
    //    UIRotationGestureRecognizer *rotationGesture = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotatePiece:)];
    //    [piece addGestureRecognizer:rotationGesture];
    //    [rotationGesture release];
    
	
	//放缩
    UIPinchGestureRecognizer *pinchGesture = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(scalePiece:)];
    [pinchGesture setDelegate:self];
    [piece addGestureRecognizer:pinchGesture];
    [pinchGesture release];
    
	
//	//平移
//    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panPiece:)];
//    [panGesture setMaximumNumberOfTouches:2];
//    [panGesture setDelegate:self];
//    [piece addGestureRecognizer:panGesture];
//    [panGesture release];
    
    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(showResetMenu:)];
    [piece addGestureRecognizer:longPressGesture];
    [longPressGesture release];
}

- (void)awakeFromNib
{
    //    [self addGestureRecognizersToPiece:firstPieceView];
    //    [self addGestureRecognizersToPiece:secondPieceView];
    //    [self addGestureRecognizersToPiece:thirdPieceView];
}

// scale and rotation transforms are applied relative to the layer's anchor point
// this method moves a gesture recognizer's view's anchor point between the user's fingers
- (void)adjustAnchorPointForGestureRecognizer:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
        UIView *piece = gestureRecognizer.view;
        CGPoint locationInView = [gestureRecognizer locationInView:piece];
        CGPoint locationInSuperview = [gestureRecognizer locationInView:piece.superview];
        
        piece.layer.anchorPoint = CGPointMake(locationInView.x / piece.bounds.size.width, locationInView.y / piece.bounds.size.height);
        piece.center = locationInSuperview;
    }
}

// display a menu with a single item to allow the piece's transform to be reset
- (void)showResetMenu:(UILongPressGestureRecognizer *)gestureRecognizer
{
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        UIMenuController *menuController = [UIMenuController sharedMenuController];
        UIMenuItem *resetMenuItem = [[UIMenuItem alloc] initWithTitle:@"Reset" action:@selector(resetPiece:)];
        CGPoint location = [gestureRecognizer locationInView:[gestureRecognizer view]];
        
        [self becomeFirstResponder];
        [menuController setMenuItems:[NSArray arrayWithObject:resetMenuItem]];
        [menuController setTargetRect:CGRectMake(location.x, location.y, 0, 0) inView:[gestureRecognizer view]];
        [menuController setMenuVisible:YES animated:YES];
        
        pieceForReset = [gestureRecognizer view];
        
        [resetMenuItem release];
    }
}

// animate back to the default anchor point and transform
- (void)resetPiece:(UIMenuController *)controller
{
    CGPoint locationInSuperview = [pieceForReset convertPoint:CGPointMake(CGRectGetMidX(pieceForReset.bounds), CGRectGetMidY(pieceForReset.bounds)) toView:[pieceForReset superview]];
    
    [[pieceForReset layer] setAnchorPoint:CGPointMake(0.5, 0.5)];
    [pieceForReset setCenter:locationInSuperview];
    
    [UIView beginAnimations:nil context:nil];
    [pieceForReset setTransform:CGAffineTransformIdentity];
    [UIView commitAnimations];
}

// UIMenuController requires that we can become first responder or it won't display
- (BOOL)canBecomeFirstResponder
{
    return YES;
}

#pragma mark -
#pragma mark === Touch handling  ===
#pragma mark

// shift the piece's center by the pan amount
// reset the gesture recognizer's translation to {0, 0} after applying so the next callback is a delta from the current position
- (void)panPiece:(UIPanGestureRecognizer *)gestureRecognizer
{
    UIView *piece = [gestureRecognizer view];
    
    [self adjustAnchorPointForGestureRecognizer:gestureRecognizer];
    
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        CGPoint translation = [gestureRecognizer translationInView:[piece superview]];
        
        [piece setCenter:CGPointMake([piece center].x + translation.x, [piece center].y + translation.y)];
        [gestureRecognizer setTranslation:CGPointZero inView:[piece superview]];
    }
}

// rotate the piece by the current rotation
// reset the gesture recognizer's rotation to 0 after applying so the next callback is a delta from the current rotation
- (void)rotatePiece:(UIRotationGestureRecognizer *)gestureRecognizer
{
    [self adjustAnchorPointForGestureRecognizer:gestureRecognizer];
    
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        [gestureRecognizer view].transform = CGAffineTransformRotate([[gestureRecognizer view] transform], [gestureRecognizer rotation]);
        [gestureRecognizer setRotation:0];
    }
}

// scale the piece by the current scale
// reset the gesture recognizer's rotation to 0 after applying so the next callback is a delta from the current scale
- (void)scalePiece:(UIPinchGestureRecognizer *)gestureRecognizer
{
    [self adjustAnchorPointForGestureRecognizer:gestureRecognizer];
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        
        if (totalScale>1.5 && gestureRecognizer.scale>1)
            return;
        if (gestureRecognizer.scale<1) {
            //return;
            [gestureRecognizer view].transform = CGAffineTransformScale([[gestureRecognizer view] transform], 1.0/totalScale, 1.0/totalScale);
            totalScale = 1;
            [gestureRecognizer setScale:1];
            //[UIView animateWithDuration:0.1 animations:^{
                gestureRecognizer.view.frame = orginalFrame;
            //}];
            gestureRecognizer.view.frame = orginalFrame;
            //gestureRecognizer.view.center = center;
            NSLog(@"centre:(%lf, %lf), frame:(%lf, %lf, %lf, %lf)", center.x, center.y , gestureRecognizer.view.frame.origin.x, gestureRecognizer.view.frame.origin.y,
                  gestureRecognizer.view.frame.size.width, gestureRecognizer.view.frame.size.height);
            return;
        }
            
        totalScale *= gestureRecognizer.scale;
        [gestureRecognizer view].transform = CGAffineTransformScale([[gestureRecognizer view] transform], [gestureRecognizer scale], [gestureRecognizer scale]);
        [gestureRecognizer setScale:1];
        //gestureRecognizer.view.frame = orginalFrame;
        gestureRecognizer.view.center = center;
        CGRect rect = CGRectMake(center.x-gestureRecognizer.view.frame.size.width/2, center.y-gestureRecognizer.view.frame.size.height/2, gestureRecognizer.view.frame.size.width, gestureRecognizer.view.frame.size.height);
        gestureRecognizer.view.frame = rect;
        NSLog(@"centre:(%lf, %lf), frame:(%lf, %lf, %lf, %lf)", center.x, center.y , gestureRecognizer.view.frame.origin.x, gestureRecognizer.view.frame.origin.y,
              gestureRecognizer.view.frame.size.width, gestureRecognizer.view.frame.size.height);
        
    }
}

// ensure that the pinch, pan and rotate gesture recognizers on a particular view can all recognize simultaneously
// prevent other gesture recognizers from recognizing simultaneously
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    // if the gesture recognizers's view isn't one of our pieces, don't allow simultaneous recognition
    //if (gestureRecognizer.view != firstPieceView && gestureRecognizer.view != secondPieceView && gestureRecognizer.view != thirdPieceView)
    //        return NO;
    
    // if the gesture recognizers are on different views, don't allow simultaneous recognition
    if (gestureRecognizer.view != otherGestureRecognizer.view)
        return NO;
    
    // if either of the gesture recognizers is the long press, don't allow simultaneous recognition
    if ([gestureRecognizer isKindOfClass:[UILongPressGestureRecognizer class]] || [otherGestureRecognizer isKindOfClass:[UILongPressGestureRecognizer class]])
        return NO;
    
    return YES;
}


@end
