//
//  SyncDataMngController.h
//  iPadSales
//
//  Created by Yue Gu on 12-3-4.
//  Copyright 2012 Logic Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SyncViewController : UIViewController 

@end
