//
//  FormatHelper.m
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FormatHelper.h"

@implementation FormatHelper

+(NSString*) initFormatHHMMSS:(NSInteger)value{
    NSString* strTime=[[NSString alloc] initWithFormat:@"%d",value]; //the way to format
    if (value<10) {
        strTime=[[NSString alloc] initWithFormat:@"0%d",value];    
    }
    
    return strTime;
}
@end
