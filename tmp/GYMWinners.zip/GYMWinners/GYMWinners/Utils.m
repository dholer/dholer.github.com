//
//  Utils.m
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Utils.h"

@implementation Utils

static bool afterAddingGym=NO;

+(void) setAfterAddingGym:(BOOL)after{
    afterAddingGym=after;
}
+(BOOL) getAfterAddingGym{
    return afterAddingGym;
}
@end
