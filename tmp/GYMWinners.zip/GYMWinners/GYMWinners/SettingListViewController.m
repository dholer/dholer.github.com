//
//  SettingListViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 4/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SettingListViewController.h"

@interface SettingListViewController ()

@end

@implementation SettingListViewController
@synthesize settingTypes;
@synthesize tableView;

#pragma mark - tableView delegate
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [settingTypes count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return @"设置";
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"didSelectRowAtIndexPath:%d",indexPath.row);
    
    //    if(indexPath.row==0 || indexPath.row==1 || indexPath.row==2 || indexPath.row==3 ){
    //        TopboardSummaryViewController* summaryViewController=[[TopboardSummaryViewController alloc] init];
    //                
    //        [self.navigationController pushViewController:summaryViewController animated:YES];
    //    }else if(indexPath.row==4){
    //        TopboardEveryDayViewController* everyDayViewController=[[TopboardEveryDayViewController alloc] init];
    //        [self.navigationController pushViewController:everyDayViewController animated:YES];
    //    }
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * showTopBoardCellIdentifier = @"ShowSpaceCell"; 
    UITableViewCell* cell=[tableView dequeueReusableCellWithIdentifier:showTopBoardCellIdentifier];
    if(cell==nil){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:showTopBoardCellIdentifier];        
    }
    cell.textLabel.text=[settingTypes objectAtIndex:indexPath.row];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    settingTypes= [[NSArray alloc] initWithObjects:@"登出",@"修改密码",@"修改信用卡",@"法律条款",@"联系我们", nil];
//    tableView = [[UITableView alloc] initWithFrame:CGRectMake(22, 240, 280, 130)];
    tableView = [[UITableView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]
                                     style:UITableViewStylePlain];  
    tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
    
    tableView.delegate=self;
    tableView.dataSource=self;
    tableView.allowsSelection=YES;
    [tableView reloadData];
    
    [self.view addSubview:tableView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
