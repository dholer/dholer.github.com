//
//  RegisterRuleViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 4/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterRuleViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource>

@property(nonatomic,retain) IBOutlet UIPickerView* daysPickerView;
@property(nonatomic,retain) NSArray* daysToGymPerWeekArr;
//@property(nonatomic,retain) NSArray* penaltyPerTime;

-(IBAction) nextStep;
@end
