//
//  FindGymAnnotion.h
//  GYMWinners
//
//  Created by Logic Solutions on 3/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MapKit/MapKit.h"

@interface FindGymAnnotion : NSObject<MKAnnotation>{
    NSString *title;  
    NSString *subtitle;  
}
@property (nonatomic,readwrite) CLLocationCoordinate2D coordinate;  
@property (nonatomic, copy) NSString *title;  
@property (nonatomic, copy) NSString *subtitle;  

-(id)initWithCoordinate:(CLLocationCoordinate2D)aCoordinate;

@end
