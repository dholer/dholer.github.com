//
//  Utils.h
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Utils : NSObject

+(void) setAfterAddingGym:(BOOL)after;
+(BOOL) getAfterAddingGym;

@end
