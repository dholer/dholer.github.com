//
//  RegisterGetCardViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 4/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterGetCardViewController : UIViewController

@property(nonatomic,retain) IBOutlet UISegmentedControl* getCardSegment;

@property (retain, nonatomic) UITabBarController* tabBarController;
@property (retain, nonatomic) UINavigationController* spaceNavController;
@property (retain, nonatomic) UINavigationController* signNavController;
@property (retain, nonatomic) UINavigationController* nearbyNavController;
@property (retain, nonatomic) UINavigationController* topNavController;

-(IBAction)finishRegister;

@end
