//
//  FindGymViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapKit/MapKit.h"

@interface FindGymViewController : UIViewController<CLLocationManagerDelegate,MKMapViewDelegate>

@property (retain,nonatomic)  CLLocationManager* locationManager;
@property (retain,nonatomic) IBOutlet MKMapView* mapView;
@property (retain,nonatomic) IBOutlet UITextField* gymNameTextField;
@property (retain,nonatomic) IBOutlet UITextField* gymAddressTextField;
-(void) submit;

@end
