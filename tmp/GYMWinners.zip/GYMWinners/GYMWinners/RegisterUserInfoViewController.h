//
//  RegisterUserInfoViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 4/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterUserInfoViewController : UIViewController

@property(nonatomic,retain) IBOutlet UITextField* userNameTxt;
@property(nonatomic,retain) IBOutlet UITextField* emailAddressTxt;
@property(nonatomic,retain) IBOutlet UITextField* passwordTxt;

-(IBAction)nextStep;

@end
