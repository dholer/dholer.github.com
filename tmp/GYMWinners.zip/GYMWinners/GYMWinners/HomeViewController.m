//
//  HomeViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 4/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "HomeViewController.h"
#import "RegisterUserInfoViewController.h"
#import "LoginViewController.h"
@implementation HomeViewController

-(IBAction) performRegister{
    NSLog(@"=>performRegister");
    RegisterUserInfoViewController* registerUser= [[RegisterUserInfoViewController alloc] init];
    [self.navigationController pushViewController:registerUser animated:YES];
    

}
 
-(IBAction) performLogin{
    NSLog(@"=>performLogin");
    LoginViewController* login=[[LoginViewController alloc] init];
    [self.navigationController pushViewController:login animated:YES];
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
