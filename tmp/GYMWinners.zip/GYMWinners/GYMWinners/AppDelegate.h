//
//  AppDelegate.h
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (retain, nonatomic) UITabBarController* tabBarController;
@property (retain, nonatomic) UINavigationController* spaceNavController;
@property (retain, nonatomic) UINavigationController* signNavController;
@property (retain, nonatomic) UINavigationController* nearbyNavController;
@property (retain, nonatomic) UINavigationController* topNavController;

@property (retain, nonatomic) UINavigationController* homeNavController;


- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

@end
