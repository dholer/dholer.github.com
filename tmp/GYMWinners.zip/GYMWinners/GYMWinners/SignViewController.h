//
//  SignViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignViewController : UIViewController<UIAlertViewDelegate>

//@property(nonatomic,retain) IBOutlet UILabel* countdownLabel;

-(IBAction)checkInNow;
-(void)findGym;
@end
