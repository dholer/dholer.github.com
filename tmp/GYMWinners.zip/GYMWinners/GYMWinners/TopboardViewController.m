//
//  TopboardViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TopboardViewController.h"
#import "TopboardSummaryViewController.h"
#import "TopboardEveryDayViewController.h"

@implementation TopboardViewController

@synthesize boardTypes;
@synthesize tableView;

#pragma mark - tableView delegate
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [boardTypes count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return @"排行榜";
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"didSelectRowAtIndexPath:%d",indexPath.row);
    
    if(indexPath.row==0 || indexPath.row==1 || indexPath.row==2 || indexPath.row==3 ){
        TopboardSummaryViewController* summaryViewController=[[TopboardSummaryViewController alloc] init];
        switch (indexPath.row) {
            case 0:
                //TODO call webservice to get datum 
                break;
            case 1:
                //TODO
                break;
            case 2:
                //TODO
                break;
            case 3:
                //TODO
                break;
            default:
                break;
        }
        
        [self.navigationController pushViewController:summaryViewController animated:YES];
    }else if(indexPath.row==4){
        TopboardEveryDayViewController* everyDayViewController=[[TopboardEveryDayViewController alloc] init];
        [self.navigationController pushViewController:everyDayViewController animated:YES];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath{
        
    static NSString * showTopBoardCellIdentifier = @"ShowUserInfoCell"; 
    UITableViewCell* cell=[tableView dequeueReusableCellWithIdentifier:showTopBoardCellIdentifier];
    if(cell==nil){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:showTopBoardCellIdentifier];        
    }
    cell.textLabel.text=[boardTypes objectAtIndex:indexPath.row];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        
    return cell;
}

#pragma mark - about nib
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    boardTypes= [[NSArray alloc] initWithObjects:@"完成率总排行",@"完成率上周排行",
                 @"奖金总排行",@"奖金上周排行",@"每日统计", nil];
    
    tableView = [[UITableView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]
                                     style:UITableViewStylePlain]; 
    tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
    
    tableView.delegate=self;
    tableView.dataSource=self;
    tableView.allowsSelection=YES;
    [tableView reloadData];
    
    self.view=tableView;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
