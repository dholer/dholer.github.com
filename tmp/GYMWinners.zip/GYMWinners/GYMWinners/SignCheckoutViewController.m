//
//  SignCheckoutViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 3/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SignCheckoutViewController.h"
#import "FormatHelper.h"

@implementation SignCheckoutViewController
@synthesize countdownLabel;
@synthesize timer;
@synthesize timeConsumed;

static NSInteger oneMinute=60; //one minute= 60 seconds 
static NSInteger oneHour=3600; //one hour= 3600 seconds

-(void)checkInNow{
    if (timeConsumed!=0) {
        timeConsumed=0;
    }
    self.timer=[NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(onTimer) userInfo:nil repeats:YES];
}

-(IBAction)checkOutNow{
    [self.timer invalidate];
    NSLog(@"-----timeConsumed=%d",timeConsumed);
}

-(void) onTimer{
    timeConsumed++;    
    
    NSInteger hourPart=timeConsumed/oneHour;
    NSInteger minLeft=timeConsumed%oneHour;
    
    NSInteger minPart=minLeft/oneMinute;
    NSInteger secPart=minLeft%oneMinute;
    
    if (timeConsumed>0) {
        NSString* strHour=[FormatHelper initFormatHHMMSS:hourPart];
        NSString* strMin=[FormatHelper initFormatHHMMSS:minPart];
        NSString* strSec=[FormatHelper initFormatHHMMSS:secPart];       
        
        countdownLabel.text=[NSString stringWithFormat:@"%@:%@:%@",strHour,strMin,strSec];    
    }
//    else{
//        countdownLabel.text=@"Completed";
//    }
    
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSLog(@"-----timeConsumed=%d",timeConsumed);
    
    timeConsumed=0;
    [self checkInNow];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
