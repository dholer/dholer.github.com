//
//  SpaceViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SpaceViewController.h"
#import "SettingListViewController.h"
#import "PractiseCardViewController.h"
#import "CheckOutHistoryViewController.h"

@implementation SpaceViewController
@synthesize imageView;
@synthesize spaceTypes;
@synthesize tableView;

#pragma mark - tableView delegate
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [spaceTypes count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return @""; //no header
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"didSelectRowAtIndexPath:%d",indexPath.row);
    
    if(indexPath.row==0){
        PractiseCardViewController* cardView=[[PractiseCardViewController alloc] init];
        [self.navigationController pushViewController:cardView animated:YES];
    }else if(indexPath.row==1){
        CheckOutHistoryViewController* history=[[CheckOutHistoryViewController alloc] init];
        [self.navigationController pushViewController:history animated:YES];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * showTopBoardCellIdentifier = @"ShowSpaceCell"; 
    UITableViewCell* cell=[tableView dequeueReusableCellWithIdentifier:showTopBoardCellIdentifier];
    if(cell==nil){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:showTopBoardCellIdentifier];        
    }
    cell.textLabel.text=[spaceTypes objectAtIndex:indexPath.row];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)setting{
    SettingListViewController* settingList=[[SettingListViewController alloc]init];
    [self.navigationController pushViewController:settingList animated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //1. add setting button
    UIBarButtonItem* settingButtonItem=[[UIBarButtonItem alloc] 
                                       initWithTitle:@"设置" 
                                       style:UIBarButtonItemStyleBordered
                                       target:self 
                                       action:@selector(setting)];//TODO finish setting function
    self.navigationItem.rightBarButtonItem= settingButtonItem;
    
    //2. set image
    imageView=[[UIImageView alloc] init];
//    [self.view addSubview:imageView];
    
    
    //3. init
    spaceTypes= [[NSArray alloc] initWithObjects:@"我的体验卡",@"最近出勤纪录", nil];
    tableView = [[UITableView alloc] initWithFrame:CGRectMake(22, 240, 280, 130)];
//    tableView = [[UITableView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]
//                                             style:UITableViewStylePlain];  
//    tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
    
    tableView.delegate=self;
    tableView.dataSource=self;
    tableView.allowsSelection=YES;
    [tableView reloadData];
    
    [self.view addSubview:tableView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
