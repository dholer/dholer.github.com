//
//  RegisterUserInfoViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 4/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RegisterUserInfoViewController.h"
#import "RegisterRuleViewController.h"
@interface RegisterUserInfoViewController ()

@end


@implementation RegisterUserInfoViewController

@synthesize userNameTxt;
@synthesize emailAddressTxt;
@synthesize passwordTxt;

-(IBAction)nextStep{
    NSLog(@"==TO RULE VIEW==>");
    RegisterRuleViewController* registerRule=[[RegisterRuleViewController alloc] init];
    [self.navigationController pushViewController:registerRule animated:YES];
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
