//
//  FindGymAnnotion.m
//  GYMWinners
//
//  Created by Logic Solutions on 3/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FindGymAnnotion.h"

@implementation FindGymAnnotion
@synthesize coordinate,title,subtitle; 

-(id)initWithCoordinate:(CLLocationCoordinate2D)aCoordinate{
    self=[super init];
    if(self){
        coordinate=aCoordinate;
    }
    return self;
}

@end
