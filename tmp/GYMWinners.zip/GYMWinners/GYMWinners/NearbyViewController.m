//
//  NearbyViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "NearbyViewController.h"

@implementation NearbyViewController
@synthesize locationManager;
@synthesize mapView;
@synthesize toolbar;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //1. add map view    
    mapView.delegate=self;
    
    [mapView setZoomEnabled:YES];
    [mapView setScrollEnabled:YES];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate=self; 
    locationManager.desiredAccuracy=kCLLocationAccuracyBest;
    locationManager.distanceFilter=100.0f;
    [locationManager startUpdatingLocation];
    
    MKCoordinateSpan theSpan;  
    theSpan.latitudeDelta=0.02; 
    theSpan.longitudeDelta=0.02;
    
    MKCoordinateRegion theRegion; 
    theRegion.center=[[locationManager location] coordinate]; 
    theRegion.span=theSpan; 
    
    [mapView setRegion:theRegion]; 
    
    if([CLLocationManager locationServicesEnabled]){
        mapView.showsUserLocation=YES;
        [mapView setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
    }
    
    MKUserTrackingBarButtonItem* trackingBarButton=[[MKUserTrackingBarButtonItem alloc] 
                                                    initWithMapView:self.mapView];
    UIBarButtonItem* refreshButton=[[UIBarButtonItem alloc] 
                                       initWithTitle:@"Refresh" 
                                       style:UIBarButtonItemStyleBordered
                                       target:self 
                                       action:@selector(refresh)];//TODO implement refresh function
    UIBarButtonItem* addGymButton=[[UIBarButtonItem alloc] 
                                       initWithTitle:@"+GYM" 
                                       style:UIBarButtonItemStyleBordered
                                       target:self 
                                       action:@selector(addGym)];//TODO implement addGym function
    
    [self.toolbar setItems: [NSArray arrayWithObjects:trackingBarButton,refreshButton,addGymButton,nil] animated:YES ];
}

- (void)viewDidUnload
{
    [self setMapView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation{
    
    NSString* lat=[[NSString alloc] initWithFormat:@"%g",newLocation.coordinate.latitude];
    NSString* lng=[[NSString alloc] initWithFormat:@"%g",newLocation.coordinate.longitude];
    NSString* acc=[[NSString alloc] initWithFormat:@"%g",newLocation.horizontalAccuracy];
    NSLog(@"%@__%@__%@",lat,lng,acc);
    
    MKCoordinateSpan span;
    span.latitudeDelta=0.02;
    span.longitudeDelta=0.02;
    
    MKCoordinateRegion region;
    region.center=newLocation.coordinate;
    region.span=span;
    
    [mapView setRegion:region animated:YES];
    
}

#pragma mark - User-Defined Method
-(void) refresh{
    NSLog(@"refresh");
    [mapView setRegion:mapView.region animated:TRUE];    
}

-(void) addGym{
    NSLog(@"addGym");
}
@end
