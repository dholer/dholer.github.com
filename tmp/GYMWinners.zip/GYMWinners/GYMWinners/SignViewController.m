//
//  SignViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SignViewController.h"
#import "FindGymViewController.h"
#import "SignCheckoutViewController.h"

#import "FormatHelper.h"
#import "Utils.h"

#import "AppDelegate.h"


@implementation SignViewController

-(IBAction)checkInNow{
    
    BOOL canCheckNow=NO;
    //1. find position(X,Y) by GPS
    //2. checked (X,Y) by server, and return result
    if (canCheckNow) {

        SignCheckoutViewController* signCheckoutViewController=[[SignCheckoutViewController alloc] init];
        [[self navigationController]pushViewController:signCheckoutViewController animated:NO];
        
    }else{ //alert with options

            UIAlertView* alert=[[UIAlertView alloc]
                            initWithTitle:@"未知的健身中心" 
                            message:@"添加健身中心或者重试. 本次健身时间会在健身中心得到验证后生效." 
                            delegate:self 
                            cancelButtonTitle:nil 
                            otherButtonTitles:@"重试",@"添加健身中心", nil];
            [alert show];       
    }
    
}


-(void)findGym{
    FindGymViewController* findGymViewController=[[FindGymViewController alloc] init];
    [[self navigationController]pushViewController:findGymViewController animated:YES];
}   



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark -- UIAlertViewDelegate --

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {  
    NSLog(@"clickedButtonAtIndex:%d",buttonIndex); 
    if (buttonIndex==0) { //try again
        [self checkInNow];
    }else if(buttonIndex==1){
        [self findGym];
    }
        
}  

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {  
//    NSLog(@"didDismissWithButtonIndex");  
}  

- (void)alertView:(UIAlertView *)alertView willDismissWithButtonIndex:(NSInteger)buttonIndex {  
//    NSLog(@"willDismissWithButtonIndex");  
}  

- (void)alertViewCancel:(UIAlertView *)alertView {  
//    NSLog(@"alertViewCancel");  
}  

- (void)didPresentAlertView:(UIAlertView *)alertView {  
//    NSLog(@"didPresentAlertView");  
}  

- (void)willPresentAlertView:(UIAlertView *)alertView {  
//    NSLog(@"willPresentAlertView");  
}  

@end
