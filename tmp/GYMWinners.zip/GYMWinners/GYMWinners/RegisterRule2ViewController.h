//
//  RegisterRule2ViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 4/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
 
@interface RegisterRule2ViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource>

@property(nonatomic,retain) IBOutlet UIPickerView* daysPickerView;
@property(nonatomic,retain) NSArray* penaltyPerTimeArr;

-(IBAction)nextStep;

@end
