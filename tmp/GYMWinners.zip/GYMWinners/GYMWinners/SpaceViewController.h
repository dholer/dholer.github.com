//
//  SpaceViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SpaceViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,retain) NSArray* spaceTypes;

@property(strong,nonatomic) IBOutlet UITableView* tableView;
@property(nonatomic,retain)IBOutlet UIImageView* imageView;

@end
