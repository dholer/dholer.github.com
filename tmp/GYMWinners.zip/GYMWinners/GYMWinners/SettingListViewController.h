//
//  SettingListViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 4/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingListViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,retain) NSArray* settingTypes;

@property(strong,nonatomic) IBOutlet UITableView* tableView;

@end
