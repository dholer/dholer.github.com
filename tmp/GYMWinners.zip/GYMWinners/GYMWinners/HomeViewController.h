//
//  HomeViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 4/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController

-(IBAction) performRegister;
-(IBAction) performLogin;

@end
