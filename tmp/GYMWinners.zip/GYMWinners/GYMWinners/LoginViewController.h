//
//  LoginViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 4/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@property (retain, nonatomic) UITabBarController* tabBarController;
@property (retain, nonatomic) UINavigationController* spaceNavController;
@property (retain, nonatomic) UINavigationController* signNavController;
@property (retain, nonatomic) UINavigationController* nearbyNavController;
@property (retain, nonatomic) UINavigationController* topNavController;

-(IBAction)finishLogin;

@end
