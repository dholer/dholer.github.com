//
//  SignCheckoutViewController.h
//  GYMWinners
//
//  Created by Logic Solutions on 3/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignCheckoutViewController : UIViewController

@property(nonatomic,retain) IBOutlet UILabel* countdownLabel;
@property(nonatomic,retain) NSTimer* timer;
@property(atomic) NSInteger timeConsumed;

-(void)checkInNow;
-(IBAction)checkOutNow;

@end
