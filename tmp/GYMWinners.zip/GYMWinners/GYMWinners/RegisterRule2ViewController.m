//
//  RegisterRule2ViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 4/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RegisterRule2ViewController.h"
#import "RegisterPayInfoViewController.h"
@interface RegisterRule2ViewController ()

@end

@implementation RegisterRule2ViewController
@synthesize daysPickerView;
@synthesize penaltyPerTimeArr;

-(IBAction)nextStep{
    RegisterPayInfoViewController* payInfo = [[RegisterPayInfoViewController alloc] init];
    [self.navigationController pushViewController:payInfo animated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    penaltyPerTimeArr= [[NSArray alloc]initWithObjects:@"5¥",@"10¥",@"15¥",@"20¥",@"30¥",@"40¥",@"60¥",@"80¥",@"100¥", nil];
    
    daysPickerView= [[UIPickerView alloc] initWithFrame:CGRectMake(0,110, 320, 240)];    
    daysPickerView.delegate=self;
    daysPickerView.showsSelectionIndicator=YES;
    [daysPickerView selectRow:3 inComponent:0 animated:YES]; //default selection
    
    [self.view addSubview:daysPickerView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - delegate

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{ //返回列数
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{ //返回每列的最大行数
    return [penaltyPerTimeArr count];
}

//每一列中每一行的具体内容
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{ 
    
    return [penaltyPerTimeArr objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{ //选中哪一列哪一行
    NSLog(@"selectec=>%@",[penaltyPerTimeArr objectAtIndex:row]);}

@end
