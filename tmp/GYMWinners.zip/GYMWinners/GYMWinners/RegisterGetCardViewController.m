//
//  RegisterGetCardViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 4/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RegisterGetCardViewController.h"
#import "SignViewController.h"
#import "SpaceViewController.h"
#import "NearbyViewController.h"
#import "TopboardViewController.h"

@interface RegisterGetCardViewController ()

@end

@implementation RegisterGetCardViewController
@synthesize getCardSegment;
@synthesize tabBarController;
@synthesize spaceNavController;
@synthesize signNavController;
@synthesize nearbyNavController;
@synthesize topNavController;

-(IBAction)finishRegister{
    spaceNavController=[[UINavigationController alloc] init];
    signNavController=[[UINavigationController alloc] init];
    nearbyNavController=[[UINavigationController alloc] init];
    topNavController=[[UINavigationController alloc] init];
    
    
    SpaceViewController* spaceViewController=[[SpaceViewController alloc] init];
    [spaceNavController pushViewController:spaceViewController animated:NO];
    spaceNavController.tabBarItem=[[UITabBarItem alloc] initWithTitle:@"空间" image:nil tag:0];
    
    SignViewController* signViewController=[[SignViewController alloc] init];
    [signNavController pushViewController:signViewController animated:NO];
    signNavController.tabBarItem=[[UITabBarItem alloc] initWithTitle:@"签到" image:nil tag:0];
    
    
    NearbyViewController* nearbyViewController=[[NearbyViewController alloc] init];
    [nearbyNavController pushViewController:nearbyViewController animated:NO];
    nearbyNavController.tabBarItem=[[UITabBarItem alloc] initWithTitle:@"周边" image:nil tag:0];
    
    TopboardViewController* topboardViewController=[[TopboardViewController alloc] init];
    [topNavController pushViewController:topboardViewController animated:NO];
    topNavController.tabBarItem=[[UITabBarItem alloc] initWithTitle:@"排行" image:nil tag:0];
    
    tabBarController=[[UITabBarController alloc] init];
    tabBarController.viewControllers=[NSArray arrayWithObjects:spaceNavController,signNavController,nearbyNavController,topNavController, nil];

    [self.view.window addSubview:tabBarController.view];
}

-(void)segmentAction:(UISegmentedControl *)Seg{
    NSInteger Index = Seg.selectedSegmentIndex;
    NSLog(@"Seg.selectedSegmentIndex:%d",Index);
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSArray* getCardArr=[[NSArray alloc] initWithObjects:@"获取",@"不获取",nil];
    getCardSegment=[[UISegmentedControl alloc] initWithItems:getCardArr];
    [getCardSegment setFrame:CGRectMake(80, 260, 150, 40)];
    getCardSegment.selectedSegmentIndex=0;
    [getCardSegment addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:getCardSegment];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
