//
//  FindGymViewController.m
//  GYMWinners
//
//  Created by Logic Solutions on 3/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FindGymViewController.h"
#import "SignCheckoutViewController.h"
#import "FindGymAnnotion.h"

#import "MapKit/MapKit.h"
#import "Utils.h"

@implementation FindGymViewController

@synthesize locationManager;
@synthesize  mapView;
@synthesize gymNameTextField;
@synthesize gymAddressTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
-(void) submit{
    NSString* gymName=gymNameTextField.text;
    NSString* gymAddress=gymAddressTextField.text;
    
    NSLog(@"%@__%@",gymName,gymAddress); //TODO save to server
//    [self.navigationController popViewControllerAnimated:YES];
//    [Utils setAfterAddingGym:YES];
    SignCheckoutViewController* signCheckoutViewController=[[SignCheckoutViewController alloc] init];
    [[self navigationController]pushViewController:signCheckoutViewController animated:YES];
}

- (void)viewDidLoad { 
    [super viewDidLoad]; 
    //1. add submit button
    UIBarButtonItem* submitButtonItem=[[UIBarButtonItem alloc] 
                                       initWithTitle:@"Submit" 
                                       style:UIBarButtonItemStyleBordered
                                       target:self 
                                       action:@selector(submit)];//TODO finish submit function
    self.navigationItem.rightBarButtonItem=submitButtonItem;
    
    //2. add map view    
    mapView.delegate=self;
    mapView.showsUserLocation=YES;
    [mapView setZoomEnabled:YES];
    [mapView setScrollEnabled:YES];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate=self; 
    locationManager.desiredAccuracy=kCLLocationAccuracyBest;
    locationManager.distanceFilter=100.0f;
    [locationManager startUpdatingLocation];
    
    MKCoordinateSpan theSpan;  
    theSpan.latitudeDelta=0.005; 
    theSpan.longitudeDelta=0.005;
    
    MKCoordinateRegion theRegion; 
    theRegion.center=[[locationManager location] coordinate]; 
    theRegion.span=theSpan; 
    
    [mapView setRegion:theRegion]; 
    
    if([CLLocationManager locationServicesEnabled]){
        [mapView setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
    }
    
//    MKUserTrackingBarButtonItem* trackingBarButton=[[MKUserTrackingBarButtonItem alloc] initWithMapView:self.mapView];
        
    //3. add annotation
    FindGymAnnotion* gymAnno=[[FindGymAnnotion alloc] init];
    gymAnno.title=@"拖拽到健身管位置";
    gymAnno.coordinate=theRegion.center;    
    [mapView addAnnotation:gymAnno];
    
//    NSMutableArray *annotations = [[NSMutableArray alloc] initWithCapacity:2]; 
//    FindGymAnnotion *ann1 = [[FindGymAnnotion alloc] initWithCoordinate:CLLocationCoordinate2DMake(25.802, -80.132)]; 
//    ann1.title = @"Miami";
//    ann1.subtitle = @"Annotation1";    
//    FindGymAnnotion *ann2 = [[FindGymAnnotion alloc]initWithCoordinate:CLLocationCoordinate2DMake(39.733, -105.018)]; 
//    ann2.title = @"Denver";
//    ann2.subtitle = @"Annotation2";    
//    [annotations addObject:ann1];
//    [annotations addObject:ann2];
//    [self.mapView addAnnotations:annotations];
    
}

- (void)viewDidUnload
{
    self.mapView.delegate=nil;
    [self setMapView:nil];
    
    
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation{
    
    NSString* lat=[[NSString alloc] initWithFormat:@"%g",newLocation.coordinate.latitude];
    NSString* lng=[[NSString alloc] initWithFormat:@"%g",newLocation.coordinate.longitude];
    NSString* acc=[[NSString alloc] initWithFormat:@"%g",newLocation.horizontalAccuracy];
    NSLog(@"%@__%@__%@",lat,lng,acc);
    
    MKCoordinateSpan span;
    span.latitudeDelta=0.005;
    span.longitudeDelta=0.005;
    
    MKCoordinateRegion region;
    region.center=newLocation.coordinate;
    region.span=span;
    
    [mapView setRegion:region animated:YES];
    
}

-(MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{
    NSLog(@"==viewForAnnotation==>");
    if([annotation isKindOfClass:[FindGymAnnotion class]]){
         static NSString* defaultPinID=@"com.findGym.pin";
        MKPinAnnotationView* pinView=(MKPinAnnotationView *)[self.mapView dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
        if(!pinView){
            pinView=[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:defaultPinID];
        }
        pinView.annotation=annotation;
        pinView.pinColor=MKPinAnnotationColorPurple;
        pinView.canShowCallout=YES;
        pinView.draggable=YES;
        [pinView setSelected:YES animated:YES];
//        pinView.rightCalloutAccessoryView=[UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        return pinView;        
    }
    return nil;    
}

-(void) mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view didChangeDragState:(MKAnnotationViewDragState)newState fromOldState:(MKAnnotationViewDragState)oldState{
    if(oldState==MKAnnotationViewDragStateDragging){
       //TODO
    }
    if(newState==MKAnnotationViewDragStateEnding){
        CLLocationCoordinate2D droppedAt=view.annotation.coordinate;
        NSLog(@"==dropped at %f,%f", droppedAt.latitude, droppedAt.longitude);        
    }
}

@end
